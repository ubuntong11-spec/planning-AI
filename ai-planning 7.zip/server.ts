import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = process.env.PORT || 3000;

app.use(express.json({ limit: '20mb' }));
app.use(express.urlencoded({ extended: true, limit: '20mb' }));

// Server-side initialization of Gemini client
function getAiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured on the server.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const KHMER_PLAN_SYSTEM_INSTRUCTION = `អ្នកជាអ្នកជំនាញជាន់ខ្ពស់ផ្នែករៀបចំផែនការយុទ្ធសាស្ត្រ និងផែនការប្រតិបត្តិសាលារៀន/អង្គភាព (School Operational Plan / Action Plan Expert) នៃព្រះរាជាណាចក្រកម្ពុជា។
ច្បាប់នៃការសរសេរ៖
១. ប្រើប្រាស់ភាសាខ្មែររដ្ឋបាលផ្លូវការ (Formal Administrative Khmer) មានលក្ខណៈគរុកោសល្យ និងស្តង់ដារក្រសួងអប់រំ យុវជន និងកីឡា។
២. ខ្លឹមសារត្រូវជាក់ស្តែង មានតួលេខ សូចនាករវាស់វែងបាន (SMART: Specific, Measurable, Achievable, Relevant, Time-bound)។
៣. រចនាសម្ព័ន្ធអត្ថបទត្រូវរៀបរៀបមានកថាខណ្ឌច្បាស់លាស់ ប្រើប្រាស់លេខរៀង ឬចំណុចផ្ដើម (Bullet points) ដើម្បីងាយស្រួលអាន។
៤. ហាមប្រើពាក្យសាមញ្ញទូទៅដែលគ្មានខ្លឹមសារ។
៥. ផ្តល់នូវទិន្នន័យ ការវិភាគ ដំណោះស្រាយ និងសកម្មភាពជាក់ស្ដែងសមស្របទៅនឹងបរិបទកម្ពុជា។`;

// Resilient Gemini generator with automatic fallback across supported models
async function generateContentWithFallback(params: {
  contents: any;
  systemInstruction?: string;
  responseMimeType?: string;
  responseSchema?: any;
}) {
  const ai = getAiClient();
  const candidates = ['gemini-4-hydrogen', 'gemini-3.1-flash-lite'];
  let lastError: any = null;

  for (const model of candidates) {
    try {
      const config: any = {};
      if (params.systemInstruction) config.systemInstruction = params.systemInstruction;
      if (params.responseMimeType) config.responseMimeType = params.responseMimeType;
      if (params.responseSchema) config.responseSchema = params.responseSchema;

      const response = await ai.models.generateContent({
        model,
        contents: params.contents,
        config,
      });

      if (response && response.text) {
        return response;
      }
    } catch (err: any) {
      lastError = err;
      console.warn(`Model candidate ${model} failed, attempting next available model:`, err?.message || err);
    }
  }

  throw lastError || new Error('All AI model attempts failed. Please try again.');
}

// Endpoint: Analyze Uploaded School Summary / Strengths & Challenges Document
app.post('/api/plan/analyze-school-context', async (req: Request, res: Response) => {
  try {
    const { rawText, fileName } = req.body;

    if (!rawText || !rawText.trim()) {
      return res.status(400).json({ success: false, error: 'សូមផ្តល់អត្ថបទ ឬឯកសារសង្ខេបអំពីសាលារៀន' });
    }

    const prompt = `អ្នកជាអ្នកជំនាញវិភាគទិន្នន័យអប់រំ និងរៀបចំផែនការប្រតិបត្តិសាលារៀន (School Development & Operational Plan Specialist)។
សូមធ្វើការវិភាគលើខ្លឹមសារសង្ខេប/ឯកសារស្ដីពីស្ថានភាពសាលារៀនខាងក្រោម (ប្រភពឯកសារ៖ ${fileName || 'ឯកសារផ្ទុកឡើង'})៖

ខ្លឹមសារឯកសារ៖
"""
${rawText}
"""

សូមស្រង់ និងចម្រាញ់ចេញជាទម្រង់ JSON ដែលមាន Object ដូចខាងក្រោម៖
{
  "summary": "សេចក្តីសង្ខេបជារួមអំពីសាលារៀន ទីតាំង បរិបទ និងស្ថានភាពបច្ចុប្បន្ន (៣-៤ បន្ទាត់)",
  "strengths": "បញ្ជីចំណុចខ្លាំង និងឧត្តមភាពជាក់ស្តែងរបស់សាលារៀន (ជាទម្រង់ចំណុចៗ • យ៉ាងតិច ៣-៥ ចំណុច)",
  "challenges": "បញ្ជីបញ្ហាប្រឈម ឧបសគ្គ និងចំណុចខ្វះខាតជាក់ស្តែងដែលសាលាត្រូវដោះស្រាយ (ជាទម្រង់ចំណុចៗ • យ៉ាងតិច ៣-៥ ចំណុច)",
  "uniqueEnvironment": "លក្ខណៈពិសេសនៃបរិស្ថានអប់រំ សហគមន៍ ស្ថានភាពគ្រួសារសិស្ស និងធនធាន (២-៣ បន្ទាត់)",
  "opportunities": "ឱកាស ទិសដៅយុទ្ធសាស្ត្រ ឬចំណុចអាទិភាពគន្លឹះដែលគួរផ្ដោតក្នុងការអភិវឌ្ឍ (ជាចំណុចៗ)"
}

សូមឆ្លើយតបតែ JSON សុទ្ធ ដោយគ្មានកូដ Markdown backticks ឬអត្ថបទបន្ថែមក្រៅពី JSON ឡើយ។`;

    const response = await generateContentWithFallback({
      contents: prompt,
      systemInstruction: KHMER_PLAN_SYSTEM_INSTRUCTION,
      responseMimeType: 'application/json',
    });

    const text = response.text || '{}';
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      const cleaned = text.replace(/```json/gi, '').replace(/```/gi, '').trim();
      data = JSON.parse(cleaned);
    }

    res.json({ success: true, profile: data });
  } catch (error: any) {
    console.error('Error analyzing school context:', error);
    res.status(500).json({ success: false, error: error.message || 'បរាជ័យក្នុងការវិភាគបរិបទសាលា' });
  }
});

// Endpoint: Generate Full Operational Plan
app.post('/api/plan/generate-all', async (req: Request, res: Response) => {
  try {
    const { schoolName, academicYear, location, schoolType, priorities, challenges, targetGoals, schoolContextProfile } = req.body;

    const schoolContextSection = schoolContextProfile ? `
*** បរិបទ និងទិន្នន័យជាក់ស្តែងផ្ទាល់របស់សាលា (School Unique Strengths & Challenges Context) ***
- សេចក្តីសង្ខេបស្ថានភាពសាលា៖ ${schoolContextProfile.summary || ''}
- ចំណុចខ្លាំង និងឧត្តមភាពជាក់ស្តែងរបស់សាលា៖
${schoolContextProfile.strengths || ''}
- បញ្ហាប្រឈម និងឧបសគ្គជាក់ស្តែងរបស់សាលា៖
${schoolContextProfile.challenges || challenges || ''}
- បរិស្ថានអប់រំ និងលក្ខខណ្ឌពិសេស៖ ${schoolContextProfile.uniqueEnvironment || ''}
- ឱកាស និងទិសដៅកែលម្អ៖ ${schoolContextProfile.opportunities || ''}

លក្ខខណ្ឌពិសេសបំផុត៖ ផែនការប្រតិបត្តិទាំង ៦ ជំពូក និងតារាងម៉ាទ្រីសសកម្មភាព ត្រូវតែឆ្លុះបញ្ចាំងស៊ីជម្រៅ និងដោះស្រាយចំៗទៅលើ 'បញ្ហាប្រឈមជាក់ស្តែង' ព្រមទាំងទាញយក 'ចំណុចខ្លាំង' របស់សាលាខាងលើមកធ្វើជាកម្លាំងចលករ មិនត្រូវសរសេរជារួមៗទូទៅឡើយ!
` : '';

    const prompt = `សូមជួយរៀបចំខ្លឹមសារពេញលេញនៃ "ផែនការប្រតិបត្តិ" (School / Institutional Operational Plan) សម្រាប់៖
- ឈ្មោះសាលា/ស្ថាប័ន៖ ${schoolName || 'សាលារៀនគំរូ'}
- កម្រិត/ប្រភេទ៖ ${schoolType || 'សាលាបឋមសិក្សា'}
- ឆ្នាំសិក្សា/អនុវត្ត៖ ${academicYear || '២០២៤-២០២៥'}
- ទីតាំង៖ ${location || 'រាជធានីភ្នំពេញ'}
- ទិសដៅអាទិភាព៖ ${priorities || 'លើកកម្ពស់លទ្ធផលសិក្សាសិស្ស បំណិនអាន និងគណិតវិទ្យា ព្រមទាំងការពង្រឹងវិន័យ'}
- បញ្ហាប្រឈមចម្បង៖ ${challenges || 'កង្វះសម្ភារឧបទេស និងការចូលរួមរបស់មាតាបិតានៅមានកម្រិត'}
- គោលដៅជាក់លាក់៖ ${targetGoals || 'បង្កើនអត្រាសិស្សជាប់ថ្នាក់ដល់ ៩៥% និងកាត់បន្ថយអត្រាបោះបង់ការសិក្សាឱ្យនៅក្រោម ២%'}
${schoolContextSection}

រចនាសម្ព័ន្ធឯកសារត្រូវតែអនុលោមតាមទម្រង់ស្តង់ដារ ៦ ជំពូកដូចខាងក្រោម៖
១. សេចក្តីផ្តើម (បរិបទសាលា បរិយាកាសទូទៅ សារៈសំខាន់នៃផែនការ)
២. វឌ្ឍនភាព និងបញ្ហាប្រឈម
   - វឌ្ឍនភាព៖
     + លទ្ធផលសិក្សារបស់សិស្ស
     + ការបង្រៀន និងរៀន
     + ការចូលរួមរបស់សហគមន៍
     + ដំណើរការប្រតិបត្តិរបស់សាលា
     + គណនេយ្យភាព
   - បញ្ហាប្រឈម៖
     + លទ្ធផលសិក្សារបស់សិស្ស
     + ការបង្រៀន និងរៀន
     + ការចូលរួមរបស់សហគមន៍
     + ដំណើរការប្រតិបត្តិរបស់សាលា
     + គណនេយ្យភាព
៣. គោលបំណង (គោលបំណងរួម និងគោលបំណងជាក់លាក់)
៤. គោលដៅសមិទ្ធកម្ម (សូចនាករស្នូល និងកម្រិតសម្រេច)
៥. សកម្មភាពអនុវត្ត (សកម្មភាពគន្លឹះយុទ្ធសាស្ត្រនីមួយៗ)
៦. សេចក្តីសន្និដ្ឋាន និងអនុសាសន៍

សូមផ្តល់ជាទម្រង់ JSON ដែលមាន Object ដូចខាងក្រោម៖
{
  "title": "ផែនការប្រតិបត្តិ...",
  "subtitle": "សម្រាប់ឆ្នាំសិក្សា...",
  "sections": [
    {
      "id": "sec-1",
      "code": "១",
      "title": "សេចក្តីផ្តើម",
      "content": "ខ្លឹមសារកថាខណ្ឌសេចក្តីផ្តើម...",
      "subsections": []
    },
    {
      "id": "sec-2",
      "code": "២",
      "title": "វឌ្ឍនភាព និងបញ្ហាប្រឈម",
      "content": "សេចក្តីសង្ខេបជារួមអំពីស្ថានភាព...",
      "subsections": [
        {
          "id": "sec-2-1",
          "code": "២.១",
          "title": "វឌ្ឍនភាព",
          "content": "",
          "items": [
            { "id": "sec-2-1-1", "title": "លទ្ធផលសិក្សារបស់សិស្ស", "content": "ខ្លឹមសារលម្អិត..." },
            { "id": "sec-2-1-2", "title": "ការបង្រៀន និងរៀន", "content": "ខ្លឹមសារលម្អិត..." },
            { "id": "sec-2-1-3", "title": "ការចូលរួមរបស់សហគមន៍", "content": "ខ្លឹមសារលម្អិត..." },
            { "id": "sec-2-1-4", "title": "ដំណើរការប្រតិបត្តិរបស់សាលា", "content": "ខ្លឹមសារលម្អិត..." },
            { "id": "sec-2-1-5", "title": "គណនេយ្យភាព", "content": "ខ្លឹមសារលម្អិត..." }
          ]
        },
        {
          "id": "sec-2-2",
          "code": "២.២",
          "title": "បញ្ហាប្រឈម",
          "content": "",
          "items": [
            { "id": "sec-2-2-1", "title": "លទ្ធផលសិក្សារបស់សិស្ស", "content": "ខ្លឹមសារលម្អិត..." },
            { "id": "sec-2-2-2", "title": "ការបង្រៀន និងរៀន", "content": "ខ្លឹមសារលម្អិត..." },
            { "id": "sec-2-2-3", "title": "ការចូលរួមរបស់សហគមន៍", "content": "ខ្លឹមសារលម្អិត..." },
            { "id": "sec-2-2-4", "title": "ដំណើរការប្រតិបត្តិរបស់សាលា", "content": "ខ្លឹមសារលម្អិត..." },
            { "id": "sec-2-2-5", "title": "គណនេយ្យភាព", "content": "ខ្លឹមសារលម្អិត..." }
          ]
        }
      ]
    },
    {
      "id": "sec-3",
      "code": "៣",
      "title": "គោលបំណង",
      "content": "ខ្លឹមសារគោលបំណងរួម និងជាក់លាក់...",
      "subsections": []
    },
    {
      "id": "sec-4",
      "code": "៤",
      "title": "គោលដៅសមិទ្ធកម្ម",
      "content": "ខ្លឹមសារគោលដៅសមិទ្ធកម្ម និងសូចនាករ...",
      "subsections": []
    },
    {
      "id": "sec-5",
      "code": "៥",
      "title": "សកម្មភាពអនុវត្ត",
      "content": "សេចក្តីណែនាំអំពីសកម្មភាពអនុវត្ត...",
      "subsections": []
    },
    {
      "id": "sec-6",
      "code": "៦",
      "title": "សេចក្តីសន្និដ្ឋាន",
      "content": "ខ្លឹមសារសេចក្តីសន្និដ្ឋាន និងសំណូមពរ...",
      "subsections": []
    }
  ],
  "actionMatrix": [
    {
      "id": "act-1",
      "activity": "រៀបចំការប្រជុំបច្ចេកទេស និងគណៈកម្មការអភិវឌ្ឍន៍សាលារៀន",
      "indicator": "ប្រជុំទៀងទាត់ ១ដង/ខែ កំណត់ហេតុ និងវត្តមាន ១០០%",
      "timeline": "ត្រីមាសទី ១ ដល់ ទី ៤",
      "budget": "១,២០០,០០០ រៀល",
      "budgetSource": "ថវិកាដំណើរការសាលា (PB)",
      "responsiblePerson": "នាយកសាលា និងប្រធានក្រុមបច្ចេកទេស"
    },
    {
      "id": "act-2",
      "activity": "ពង្រឹងការបង្រៀន និងរៀនបំណិនអាន និងគណិតវិទ្យាថ្នាក់ដំបូង",
      "indicator": "សិស្ស ៩០% អាចអាន និងធ្វើប្រមាណវិធីស្ទាត់ជំនាញ",
      "timeline": "ពេញមួយឆ្នាំសិក្សា",
      "budget": "២,០០០,០០០ រៀល",
      "budgetSource": "ថវិការដ្ឋ និងដៃគូអភិវឌ្ឍន៍",
      "responsiblePerson": "គ្រូបង្រៀនថ្នាក់ទី ១-៣"
    },
    {
      "id": "act-3",
      "activity": "យុទ្ធនាការកៀរគរសហគមន៍ និងការជួបមាតាបិតាសិស្ស",
      "indicator": "មាតាបិតា ៨៥% ចូលរួមប្រជុំ និងតាមដានលទ្ធផលកូន",
      "timeline": "ដើមឆ្នាំ និងឆមាសទី ១-២",
      "budget": "៨០០,០០០ រៀល",
      "budgetSource": "ការចូលរួមរបស់សហគមន៍",
      "responsiblePerson": "គណៈកម្មការទ្រទ្រង់សាលា"
    },
    {
      "id": "act-4",
      "activity": "ការកែលម្អបរិស្ថានសាលារៀន បន្ទប់រៀន និងបណ្ណាល័យស្ដង់ដារ",
      "indicator": "បណ្ណាល័យដំណើរការសកម្ម មានសៀវភៅអានគ្រប់គ្រាន់",
      "timeline": "ត្រីមាសទី ១ និងទី ២",
      "budget": "៣,៥០០,០០០ រៀល",
      "budgetSource": "សប្បុរសជន និងថវិកា PB",
      "responsiblePerson": "នាយករង និងបណ្ណារក្ស"
    },
    {
      "id": "act-5",
      "activity": "ការត្រួតពិនិត្យ តាមដាន និងវាយតម្លៃផ្ទៃក្នុងប្រចាំឆមាស",
      "indicator": "របាយការណ៍វាយតម្លៃ ២ លើកក្នុងមួយឆ្នាំ",
      "timeline": "ចុងត្រីមាសទី ២ និងទី ៤",
      "budget": "៦០០,០០០ រៀល",
      "budgetSource": "ថវិកា PB",
      "responsiblePerson": "ក្រុមអធិការកិច្ចផ្ទៃក្នុង"
    }
  ]
}
សំខាន់៖ សូមឆ្លើយតបតែ JSON សុទ្ធ ដោយគ្មានកូដ Markdown backticks ឬអត្ថបទបន្ថែមក្រៅពី JSON ឡើយ។`;

    const response = await generateContentWithFallback({
      contents: prompt,
      systemInstruction: KHMER_PLAN_SYSTEM_INSTRUCTION,
      responseMimeType: 'application/json',
    });

    const text = response.text || '{}';
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      // Clean up in case there are codeblocks
      const cleaned = text.replace(/```json/gi, '').replace(/```/gi, '').trim();
      data = JSON.parse(cleaned);
    }

    res.json({ success: true, plan: data });
  } catch (error: any) {
    console.error('Error generating plan:', error);
    res.status(500).json({ success: false, error: error.message || 'បរាជ័យក្នុងការបង្កើតផែនការ' });
  }
});

// Endpoint: Generate / Refine Specific Section
app.post('/api/plan/generate-section', async (req: Request, res: Response) => {
  try {
    const { sectionTitle, parentTitle, currentContent, context, action, customInstruction, schoolContextProfile } = req.body;

    const effectiveProfile = schoolContextProfile || context?.schoolProfile;

    let instructionDetails = '';
    switch (action) {
      case 'expand':
        instructionDetails = 'សូមពង្រីកខ្លឹមសារឱ្យកាន់តែលម្អិត ស៊ីជម្រៅ បន្ថែមឧទាហរណ៍ជាក់ស្តែង វិធានការដោះស្រាយ និងទិន្នន័យគរុកោសល្យ/រដ្ឋបាលជាក់ស្ដែង។';
        break;
      case 'formalize':
        instructionDetails = 'សូមកែសម្រួលពាក្យពេចន៍ឱ្យកាន់តែមានលក្ខណៈរដ្ឋបាលផ្លូវការ ត្រឹមត្រូវតាមក្បួនខ្នាតលិខិតបទដ្ឋានគតិយុត្តិ និងគរុកោសល្យកម្ពុជា។';
        break;
      case 'summarize':
        instructionDetails = 'សូមសង្ខេបខ្លឹមសារឱ្យនៅខ្លី ខ្លឹម ចំចំណុចគន្លឹះ ដោយមិនបាត់បង់អត្ថន័យស្នូល។';
        break;
      case 'add_indicators':
        instructionDetails = 'សូមបន្ថែមសូចនាករគន្លឹះ (KPIs) ភាគរយជាក់លាក់ និងទិន្នន័យវាស់វែងសមិទ្ធផលចូលក្នុងខ្លឹមសារ។';
        break;
      case 'custom':
        instructionDetails = `សូមកែប្រែ ឬបន្ថែមតាមការណែនាំ៖ ${customInstruction || ''}`;
        break;
      default:
        instructionDetails = 'សូមសរសេរខ្លឹមសារថ្មីឱ្យមានលក្ខណៈទូលំទូលាយ មានអត្ថន័យជ្រាលជ្រៅ និងស្របតាមក្បួនខ្នាតរដ្ឋបាល។';
    }

    const schoolContextPrompt = effectiveProfile ? `
- បរិបទ និងចំណុចខ្លាំង-ប្រឈមជាក់ស្តែងរបស់សាលា (School Strengths & Challenges Context)៖
  + ចំណុចខ្លាំង និងឧត្តមភាព៖ ${effectiveProfile.strengths || '(មិនមាន)'}
  + បញ្ហាប្រឈម និងឧបសគ្គជាក់ស្តែង៖ ${effectiveProfile.challenges || '(មិនមាន)'}
  + បរិស្ថានអប់រំ និងលក្ខណៈសហគមន៍៖ ${effectiveProfile.uniqueEnvironment || effectiveProfile.summary || ''}
  + ឱកាស និងទិសដៅអភិវឌ្ឍ៖ ${effectiveProfile.opportunities || ''}

* ការណែនាំកម្រិតខ្ពស់៖ សូមតាក់តែង ឬកែសម្រួលខ្លឹមសារផ្នែក '${sectionTitle}' នេះ ឱ្យឆ្លើយតបចំៗទៅនឹងចំណុចខ្លាំង និងបញ្ហាប្រឈមជាក់ស្តែងខាងលើរបស់សាលា ដើម្បីធានាថាឯកសារមានលក្ខណៈផ្ទាល់ខ្លួនពិតប្រាកដ (Personalized) និងមានប្រសិទ្ធភាពគរុកោសល្យខ្ពស់បំផុត។` : '';

    const prompt = `ផ្នែកដែលត្រូវសរសេរ/កែសម្រួល៖
- ចំណងជើងមេ៖ ${parentTitle || 'ផែនការប្រតិបត្តិ'}
- ចំណងជើងផ្នែក៖ ${sectionTitle}
- បរិបទរួម៖ ${JSON.stringify(context || {})}
${schoolContextPrompt}
- ខ្លឹមសារបច្ចុប្បន្ន (បើមាន)៖ ${currentContent || '(នៅទទេ)'}

ការណែនាំជាក់លាក់៖
${instructionDetails}

លក្ខខណ្ឌ៖
- សរសេរជាភាសាខ្មែរផ្លូវការ ត្រឹមត្រូវតាមវេយ្យាករណ៍ និងវចនានុក្រមសម្ដេចព្រះសង្ឃរាជ ជួន ណាត។
- រៀបចំកថាខណ្ឌ និងចំណុចៗឱ្យមានសណ្ដាប់ធ្នាប់ ងាយស្រួលយកទៅដាក់ក្នុងឯកសារផ្លូវការ។
- ឆ្លើយតបតែអត្ថបទខ្លឹមសារសុទ្ធ ដោយមិនបាច់សរសេរសេចក្តីគួរសម ឬពាក្យណែនាំខាងក្រៅឡើយ។`;

    const response = await generateContentWithFallback({
      contents: prompt,
      systemInstruction: KHMER_PLAN_SYSTEM_INSTRUCTION,
    });

    res.json({ success: true, content: response.text });
  } catch (error: any) {
    console.error('Error generating section:', error);
    res.status(500).json({ success: false, error: error.message || 'បរាជ័យក្នុងការកែសម្រួលផ្នែកនេះ' });
  }
});

// Endpoint: Generate Action Matrix Table Rows
app.post('/api/plan/generate-matrix', async (req: Request, res: Response) => {
  try {
    const { schoolName, priorities, targetGoals, currentMatrix, schoolContextProfile } = req.body;

    const schoolContextPrompt = schoolContextProfile ? `
- ចំណុចខ្លាំងរបស់សាលា៖ ${schoolContextProfile.strengths || ''}
- បញ្ហាប្រឈមរបស់សាលាដែលត្រូវដោះស្រាយក្នុងសកម្មភាព៖ ${schoolContextProfile.challenges || ''}
- បរិស្ថានអប់រំ៖ ${schoolContextProfile.uniqueEnvironment || schoolContextProfile.summary || ''}
- ឱកាស៖ ${schoolContextProfile.opportunities || ''}
` : '';

    const prompt = `សូមបង្កើត ឬបន្ថែមតារាងម៉ាទ្រីសសកម្មភាពអនុវត្ត (Action Matrix for School/Institutional Operational Plan) សម្រាប់៖
- ស្ថាប័ន/សាលារៀន៖ ${schoolName || 'សាលារៀន'}
- អាទិភាព៖ ${priorities || 'លើកកម្ពស់គុណភាពបង្រៀន និងរៀន ការគ្រប់គ្រង និងបរិស្ថាន'}
- គោលដៅ៖ ${targetGoals || 'សម្រេចសូចនាករសាលារៀនគំរូ'}
${schoolContextPrompt}

សូមផ្តល់នូវតារាងសកម្មភាពជា JSON Array ដែលមានទម្រង់៖
[
  {
    "id": "act-UUID",
    "activity": "ឈ្មោះសកម្មភាពអនុវត្តជាក់លាក់ (ឆ្លើយតបនឹងបញ្ហាប្រឈមខាងលើ)",
    "indicator": "សូចនាករវាស់វែងសមិទ្ធផល (លទ្ធផលរំពឹងទុក)",
    "timeline": "កាលបរិច្ឆេទ (ឧ. ត្រីមាសទី ១, ខែវិច្ឆិកា, ប្រចាំខែ...)",
    "budget": "ថវិកាប៉ាន់ស្មាន (ឧ. ១,៥០០,០០០ រៀល ឬ ៤០០ ដុល្លារ)",
    "budgetSource": "ប្រភពថវិកា (ឧ. ថវិកា PB / ថវិការដ្ឋ / សហគមន៍ / ដៃគូ)",
    "responsiblePerson": "អ្នកទទួលខុសត្រូវ (ឧ. គណៈគ្រប់គ្រង / គ្រូបន្ទុកថ្នាក់ / គណៈកម្មការ)"
  }
]
សូមផ្តល់យ៉ាងតិច ៦ ទៅ ៨ សកម្មភាពដែលគ្រប់ជ្រុងជ្រោយ និងឆ្លើយតបនឹងអាទិភាព ព្រមទាំងដោះស្រាយបញ្ហាប្រឈមរបស់សាលា។ ឆ្លើយតបជា JSON សុទ្ធ។`;

    const response = await generateContentWithFallback({
      contents: prompt,
      systemInstruction: KHMER_PLAN_SYSTEM_INSTRUCTION,
      responseMimeType: 'application/json',
    });

    const text = response.text || '[]';
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      const cleaned = text.replace(/```json/gi, '').replace(/```/gi, '').trim();
      data = JSON.parse(cleaned);
    }

    res.json({ success: true, actionMatrix: data });
  } catch (error: any) {
    console.error('Error generating matrix:', error);
    res.status(500).json({ success: false, error: error.message || 'បរាជ័យក្នុងការបង្កើតតារាងសកម្មភាព' });
  }
});

// Endpoint: AI Quick Assistant / Text Improver
app.post('/api/plan/quick-assist', async (req: Request, res: Response) => {
  try {
    const { text, promptType, customInstruction } = req.body;

    let task = '';
    if (promptType === 'fix_grammar') task = 'សូមពិនិត្យអក្ខរាវិរុទ្ធ និងវេយ្យាករណ៍ខ្មែរ ដោយកែពាក្យខុសឱ្យត្រូវតាមក្បួនខ្នាតរដ្ឋបាល។';
    else if (promptType === 'more_formal') task = 'សូមកែសម្រួលឃ្លាប្រយោគឱ្យកាន់តែផ្លូវការ បែបគរុកោសល្យ និងភាសារដ្ឋបាលជាន់ខ្ពស់។';
    else if (promptType === 'bullet_points') task = 'សូមរៀបចំខ្លឹមសារនេះជាទម្រង់ចំណុចៗ (Bullet points) ងាយស្រួលអាន និងមានសណ្ដាប់ធ្នាប់។';
    else if (promptType === 'custom') task = customInstruction;
    else task = 'សូមកែលម្អខ្លឹមសារនេះឱ្យកាន់តែប្រសើរ និងពេញលេញ។';

    const response = await generateContentWithFallback({
      contents: `អត្ថបទដើម៖
${text}

កិច្ចការ៖
${task}

សូមឆ្លើយតបតែអត្ថបទលទ្ធផលសុទ្ធ។`,
      systemInstruction: KHMER_PLAN_SYSTEM_INSTRUCTION,
    });

    res.json({ success: true, result: response.text });
  } catch (error: any) {
    console.error('Error in quick assist:', error);
    res.status(500).json({ success: false, error: error.message || 'បរាជ័យក្នុងការដំណើរការ' });
  }
});

// Endpoint: Summarize Entire Operational Plan into a One-Page Executive Summary
app.post('/api/plan/executive-summary', async (req: Request, res: Response) => {
  try {
    const { plan, focusStyle = 'standard' } = req.body;

    if (!plan) {
      return res.status(400).json({ success: false, error: 'មិនមានទិន្នន័យផែនការប្រតិបត្តិសម្រាប់សង្ខេប' });
    }

    // Extract condensed structural digest of the whole operational plan
    const chaptersDigest = (plan.sections || [])
      .map((sec: any) => {
        let block = `ជំពូក ${sec.code}. ${sec.title}: ${(sec.content || '').slice(0, 700)}`;
        if (sec.subsections && sec.subsections.length > 0) {
          const subs = sec.subsections
            .map((sub: any) => {
              const itemsText = (sub.items || [])
                .map((it: any) => `- ${it.title}: ${(it.content || '').slice(0, 220)}`)
                .join('\n');
              return `  ${sub.code}. ${sub.title} ${(sub.content || '').slice(0, 250)}\n${itemsText}`;
            })
            .join('\n');
          block += `\n${subs}`;
        }
        return block;
      })
      .join('\n\n');

    // Compute exact budget totals across Chapter 4 Standard Targets and Chapter 5 Actions
    let stdStateTotal = 0;
    let stdNonStateTotal = 0;
    let stdRowCount = 0;
    (plan.standardTargets || []).forEach((std: any) => {
      (std.rows || []).forEach((r: any) => {
        if (!r.isCategoryHeader) {
          stdRowCount += 1;
          stdStateTotal += Number(r.stateBudget || 0);
          stdNonStateTotal += Number(r.nonStateBudget || 0);
        }
      });
    });

    let ch5StateTotal = 0;
    let ch5CommunityTotal = 0;
    let ch5PartnerTotal = 0;
    let ch5Total = 0;
    let ch5Count = 0;
    (plan.chapterFiveActions || []).forEach((grp: any) => {
      (grp.items || []).forEach((item: any) => {
        ch5Count += 1;
        ch5StateTotal += Number(item.stateBudget || 0);
        ch5CommunityTotal += Number(item.communityBudget || 0);
        ch5PartnerTotal += Number(item.partnerBudget || 0);
        ch5Total += Number(item.totalBudget || 0);
      });
    });

    const effectiveTotal = ch5Total > 0 ? ch5Total : stdStateTotal + stdNonStateTotal;
    const effectiveState = ch5StateTotal > 0 ? ch5StateTotal : stdStateTotal;
    const effectiveCommunityPartner =
      ch5CommunityTotal + ch5PartnerTotal > 0 ? ch5CommunityTotal + ch5PartnerTotal : stdNonStateTotal;

    const actionsSample = (plan.chapterFiveActions || [])
      .map((grp: any) => {
        const gTotal = (grp.items || []).reduce((s: number, i: any) => s + Number(i.totalBudget || 0), 0);
        return `${grp.standardTitle}: ${(grp.items || []).length} សកម្មភាព (ថវិកា ${gTotal.toLocaleString('en-US')} រៀល)`;
      })
      .join('\n');

    const matrixSample = (plan.actionMatrix || [])
      .slice(0, 8)
      .map((m: any, idx: number) => `${idx + 1}. ${m.activity} (${m.indicator}) - ${m.budget}`)
      .join('\n');

    let focusInstruction =
      'រៀបចំឱ្យមានតុល្យភាពតាមស្តង់ដាក្រសួងអប់រំ យុវជន និងកីឡា សម្រាប់បោះពុម្ពលើក្រដាស A4 ចំនួន ១ ទំព័រគត់ ជាទំព័រណែនាំមុនឯកសារផ្លូវការ។';
    if (focusStyle === 'budget_commune') {
      focusInstruction =
        'សង្កត់ធ្ងន់លើការវិភាគតម្រូវការថវិកា គម្លាតធនធាន និងគម្រោងអាទិភាពសម្រាប់កៀរគរការវិនិយោគពីឃុំ-សង្កាត់ (CIP) និងសហគមន៍ ប៉ុន្តែនៅតែសមល្មមក្នុងក្រដាស A4 ១ ទំព័រគត់។';
    } else if (focusStyle === 'concise') {
      focusInstruction =
        'សរសេរឱ្យខ្លីបំផុត ខ្លឹម ច្បាស់ ចំចំណុចគន្លឹះងាយអានសម្រាប់គណៈគ្រប់គ្រង និងភ្ញៀវកិត្តិយសក្នុងកិច្ចប្រជុំ ដោយធានាថាចំណុចនីមួយៗមាន ១ ប្រយោគខ្លីៗ។';
    }

    const prompt = `សូមសង្ខេប "ផែនការប្រតិបត្តិប្រចាំឆ្នាំ (AOP)" ទាំងមូលខាងក្រោម ទៅជា "សេចក្តីសង្ខេបប្រតិបត្តិ (Executive Summary)" ចំនួន ១ ទំព័រ A4 សម្រាប់ប្រើជាទំព័រណែនាំផ្លូវការនៃឯកសារ។

ព័ត៌មានទូទៅសាលារៀន៖
- ចំណងជើង៖ ${plan.title || 'ផែនការប្រតិបត្តិប្រចាំឆ្នាំ'}
- ចំណងជើងរង៖ ${plan.subtitle || ''}
- ឈ្មោះសាលា៖ ${plan.schoolName || ''}
- ទីតាំង៖ ${plan.location || ''}
- ឆ្នាំសិក្សា៖ ${plan.academicYear || ''}
- កម្រិត៖ ${plan.schoolType || ''}

ទិន្នន័យថវិកា និងសូចនាករសរុបពីប្រព័ន្ធ៖
- ចំនួនសូចនាករស្តង់ដារ៖ ${stdRowCount} សូចនាករ និងសកម្មភាពលម្អិត៖ ${ch5Count || (plan.actionMatrix || []).length} សកម្មភាព
- ថវិកាគ្រោងសរុប៖ ${effectiveTotal.toLocaleString('en-US')} រៀល
- ថវិការដ្ឋ (PB)៖ ${effectiveState.toLocaleString('en-US')} រៀល
- ថវិកាសហគមន៍ និងដៃគូអភិវឌ្ឍន៍៖ ${effectiveCommunityPartner.toLocaleString('en-US')} រៀល

សង្ខេបតាមស្តង់ដារទាំង ៥៖
${actionsSample}

ម៉ាទ្រីសសកម្មភាពគន្លឹះ (ប្រសិនបើមាន)៖
${matrixSample}

ខ្លឹមសារទាំង ៦ ជំពូកនៃផែនការប្រតិបត្តិ៖
${chaptersDigest}

ការណែនាំទម្រង់៖
${focusInstruction}
ចំណាំសំខាន់៖ ត្រូវសរសេរជាភាសាខ្មែររដ្ឋបាលផ្លូវការ ច្បាស់លាស់ ខ្លឹម មិនវែងពេក ដើម្បីឱ្យបោះពុម្ពចូលក្នុងក្រដាស A4 តែ ១ ទំព័រគត់ (One-Page Executive Summary)។ ចំណុចនីមួយៗក្នុង Array គួរមាន ៣ ទៅ ៤ ចំណុចខ្លីៗដែលមានតួលេខជាក់លាក់។`;

    const response = await generateContentWithFallback({
      contents: prompt,
      systemInstruction: KHMER_PLAN_SYSTEM_INSTRUCTION,
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          documentTitle: {
            type: Type.STRING,
            description: 'Khmer formal title for the one-page executive summary header',
          },
          executiveOverview: {
            type: Type.STRING,
            description: 'Concise 3-4 sentence overview introducing the operational plan, school context, and overall goal',
          },
          keyStrengths: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: '3 concise bullet points summarizing main strengths and achievements',
          },
          criticalChallenges: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: '3 concise bullet points summarizing top challenges to address',
          },
          strategicPriorities: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: '3-4 concise strategic priorities and key actions across the 5 school standards',
          },
          expectedOutcomes: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: '3-4 measurable KPI outcomes expected by end of the academic year',
          },
          budgetSummary: {
            type: Type.OBJECT,
            properties: {
              totalBudgetRiel: { type: Type.STRING, description: 'Formatted total budget in Riel' },
              stateBudgetRiel: { type: Type.STRING, description: 'Formatted state budget (PB) in Riel' },
              communityAndPartnerRiel: {
                type: Type.STRING,
                description: 'Formatted community/commune/partner contribution in Riel',
              },
              resourceNote: {
                type: Type.STRING,
                description: '1-2 sentence explanation of budget allocation and mobilization strategy',
              },
            },
            required: ['totalBudgetRiel', 'stateBudgetRiel', 'communityAndPartnerRiel', 'resourceNote'],
          },
          closingStatement: {
            type: Type.STRING,
            description: 'Brief 1-2 sentence formal closing introduction inviting endorsement and collaboration',
          },
        },
        required: [
          'documentTitle',
          'executiveOverview',
          'keyStrengths',
          'criticalChallenges',
          'strategicPriorities',
          'expectedOutcomes',
          'budgetSummary',
          'closingStatement',
        ],
      },
    });

    const text = response.text || '{}';
    let summary;
    try {
      summary = JSON.parse(text);
    } catch {
      const cleaned = text.replace(/```json/gi, '').replace(/```/gi, '').trim();
      summary = JSON.parse(cleaned);
    }

    summary.focusStyle = focusStyle;
    summary.generatedAt = new Date().toISOString();

    res.json({ success: true, executiveSummary: summary });
  } catch (error: any) {
    console.error('Error generating executive summary:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'បរាជ័យក្នុងការបង្កើតសេចក្តីសង្ខេបប្រតិបត្តិដោយ AI',
    });
  }
});

// Temporary download file store for bulletproof browser downloads (bypasses iframe & blob restrictions)
interface TempDownloadFile {
  fileName: string;
  buffer: Buffer;
  mimeType: string;
  expiresAt: number;
}
const tempDownloadStore = new Map<string, TempDownloadFile>();

// Clean expired files every 5 minutes
setInterval(() => {
  const now = Date.now();
  for (const [id, item] of tempDownloadStore.entries()) {
    if (item.expiresAt < now) {
      tempDownloadStore.delete(id);
    }
  }
}, 5 * 60 * 1000);

// Endpoint: Prepare file download (returns temporary direct download URL)
app.post('/api/file/prepare-download', (req: Request, res: Response) => {
  try {
    const { fileName, content, contentType, isBase64 } = req.body;
    if (!fileName || !content) {
      return res.status(400).json({ success: false, error: 'Missing fileName or content' });
    }

    let buffer: Buffer;
    if (isBase64) {
      const base64Data = String(content).replace(/^data:.*?;base64,/, '');
      buffer = Buffer.from(base64Data, 'base64');
    } else {
      buffer = Buffer.from(String(content), 'utf-8');
    }

    const fileId = `dl_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    const mimeType = contentType || 'application/octet-stream';

    tempDownloadStore.set(fileId, {
      fileName: String(fileName),
      buffer,
      mimeType,
      expiresAt: Date.now() + 15 * 60 * 1000, // 15 mins
    });

    res.json({
      success: true,
      fileId,
      downloadUrl: `/api/file/download/${fileId}`,
      viewUrl: `/api/file/view/${fileId}`,
    });
  } catch (error: any) {
    console.error('Error preparing download:', error);
    res.status(500).json({ success: false, error: error.message || 'Failed to prepare download' });
  }
});

// Endpoint: Download file by ID with native Content-Disposition (immune to iframe / blob restrictions)
app.get('/api/file/download/:fileId', (req: Request, res: Response) => {
  const { fileId } = req.params;
  const item = tempDownloadStore.get(fileId);

  if (!item) {
    return res.status(404).send('ឯកសារបានផុតកំណត់ ឬមិនត្រូវបានរកឃើញ។ សូមព្យាយាមទាញយកម្តងទៀតពីក្នុងកម្មវិធី។');
  }

  const safeAscii = item.fileName.replace(/[^\w.-]/g, '_') || 'document.doc';
  const encodedUtf8 = encodeURIComponent(item.fileName);

  res.setHeader('Content-Type', item.mimeType || 'application/octet-stream');
  res.setHeader('Content-Length', item.buffer.length);
  res.setHeader(
    'Content-Disposition',
    `attachment; filename="${safeAscii}"; filename*=UTF-8''${encodedUtf8}`
  );
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');

  return res.end(item.buffer);
});

// Endpoint: View file by ID in browser (inline view)
app.get('/api/file/view/:fileId', (req: Request, res: Response) => {
  const { fileId } = req.params;
  const item = tempDownloadStore.get(fileId);

  if (!item) {
    return res.status(404).send('ឯកសារបានផុតកំណត់ ឬមិនត្រូវបានរកឃើញ។');
  }

  res.setHeader('Content-Type', item.mimeType || 'text/html; charset=utf-8');
  res.setHeader('Content-Length', item.buffer.length);
  res.setHeader('Content-Disposition', 'inline');
  res.setHeader('Cache-Control', 'no-cache');

  return res.end(item.buffer);
});

// Endpoint: Direct POST download endpoint (supports standard form submit or fetch)
app.post('/api/file/download-direct', (req: Request, res: Response) => {
  try {
    const { fileName, content, contentType, isBase64 } = req.body;
    if (!fileName || !content) {
      return res.status(400).send('Missing fileName or content');
    }

    let buffer: Buffer;
    if (isBase64) {
      const base64Data = String(content).replace(/^data:.*?;base64,/, '');
      buffer = Buffer.from(base64Data, 'base64');
    } else {
      buffer = Buffer.from(String(content), 'utf-8');
    }

    const safeAscii = String(fileName).replace(/[^\w.-]/g, '_') || 'document.doc';
    const encodedUtf8 = encodeURIComponent(String(fileName));

    res.setHeader('Content-Type', contentType || 'application/octet-stream');
    res.setHeader('Content-Length', buffer.length);
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="${safeAscii}"; filename*=UTF-8''${encodedUtf8}`
    );
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');

    return res.end(buffer);
  } catch (error: any) {
    console.error('Error in direct download:', error);
    res.status(500).send('Download failed: ' + (error?.message || error));
  }
});

// Guard: Ensure unmatched /api routes return JSON 404 instead of falling through to Vite/index.html
app.all('/api/*', (req: Request, res: Response) => {
  res.status(404).json({ success: false, error: `API route not found: ${req.method} ${req.path}` });
});

// JSON error handling middleware
app.use((err: any, _req: Request, res: Response, _next: any) => {
  console.error('Unhandled express error:', err);
  res.status(500).json({ success: false, error: err?.message || 'Server Internal Error' });
});

// Static files and Vite integration
if (process.env.NODE_ENV !== 'production') {
  const { createServer } = await import('vite');
  const vite = await createServer({
    server: { 
      middlewareMode: true,
      hmr: false,
    },
    appType: 'spa',
  });
  app.use(vite.middlewares);
} else {
  app.use(express.static(path.resolve(__dirname, 'dist')));
  app.get('*', (_req: Request, res: Response) => {
    res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
  });
}

app.listen(Number(port), '0.0.0.0', () => {
  console.log(`Server running on http://0.0.0.0:${port}`);
});
