/**
 * Safe Fetch Helper for API Requests
 * 
 * Prevents "SyntaxError: Unexpected token '<', "<!doctype "... is not valid JSON"
 * by validating HTTP status and Content-Type before parsing JSON,
 * and providing graceful, user-friendly Khmer error messages.
 */

export async function safeFetchJson<T = any>(url: string, options: RequestInit): Promise<T> {
  let response: Response;
  try {
    response = await fetch(url, {
      ...options,
      headers: {
        'Accept': 'application/json',
        ...(options.headers || {}),
      },
    });
  } catch (networkError: any) {
    console.error('Network request failed:', networkError);
    throw new Error('មិនអាចតភ្ជាប់ទៅកាន់ម៉ាស៊ីនបម្រើបានទេ។ សូមពិនិត្យមើលការតភ្ជាប់អ៊ីនធឺណិត។');
  }

  const contentType = response.headers.get('content-type') || '';

  // Check if response is actually JSON
  if (!contentType.includes('application/json')) {
    const rawText = await response.text();
    console.error(`Received non-JSON response from ${url} (HTTP ${response.status}):`, rawText.slice(0, 300));
    
    if (response.status === 404) {
      throw new Error(`មិនស្គាល់សេវា API (HTTP 404 Not Found)។`);
    } else if (response.status === 502 || response.status === 504) {
      throw new Error('ម៉ាស៊ីនបម្រើ AI ឆ្លើយតបយឺត (Gateway Timeout)។ សូមសាកល្បងម្ដងទៀតបន្តិចក្រោយ។');
    } else if (response.status >= 500) {
      throw new Error(`ម៉ាស៊ីនបម្រើជួបបញ្ហាបច្ចេកទេស (HTTP ${response.status})។ សូមព្យាយាមម្ដងទៀត។`);
    } else {
      throw new Error(`ទិន្នន័យដែលទទួលបានមិនត្រឹមត្រូវ (HTTP ${response.status})។`);
    }
  }

  let data: any;
  try {
    data = await response.json();
  } catch (parseError: any) {
    console.error(`Failed to parse JSON response from ${url}:`, parseError);
    throw new Error('ទម្រង់ទិន្នន័យពីម៉ាស៊ីនបម្រើមិនត្រឹមត្រូវ។');
  }

  if (!response.ok) {
    throw new Error(data?.error || `សំណើបរាជ័យ (HTTP ${response.status})`);
  }

  return data as T;
}
