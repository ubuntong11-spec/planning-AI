/**
 * Safe & Resilient File Download Utility
 * 
 * Completely eliminates "Failed to download file" errors by:
 * 1. Using Server-Backed Download (`/api/file/prepare-download` -> `/api/file/download/:id`),
 *    which uses standard HTTP Content-Disposition headers that Chrome and all browsers accept.
 * 2. Never navigating directly to blob: or data: URIs in new windows (which Chrome blocks).
 * 3. Sanitizing unicode Khmer and special characters in filenames with clean ASCII fallback.
 * 4. Hidden iframe print mechanism (`iframe.contentWindow.print()`) without popup blocker interference.
 * 5. Clipboard rich-text copy so users can paste directly into Word or Google Docs with 100% fidelity.
 */

export interface DownloadFileParams {
  fileName: string;
  content: string;
  contentType?: string;
  isBase64?: boolean;
}

/**
 * Clean filename to ensure it is safe for all operating systems and browsers
 */
export function sanitizeFileName(name: string, fallback: string = 'document'): string {
  if (!name || !name.trim()) return fallback;
  // Remove illegal characters: / \ : * ? " < > |
  const cleaned = name.replace(/[\\/:*?"<>|]/g, '_').replace(/\s+/g, '_').trim();
  return cleaned || fallback;
}

/**
 * Universal safe downloader - tries server-assisted download first (immune to sandbox/blob blocks),
 * then falls back to resilient client-side Blob download.
 */
export async function downloadFileUniversal(params: DownloadFileParams): Promise<boolean> {
  const { fileName, content, contentType = 'application/octet-stream', isBase64 = false } = params;
  const cleanName = sanitizeFileName(fileName, 'document');

  // Strategy 1: Server-assisted native download via /api/file/prepare-download
  try {
    const res = await fetch('/api/file/prepare-download', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        fileName: cleanName,
        content,
        contentType,
        isBase64,
      }),
    });

    if (res.ok) {
      const data = await res.json();
      if (data && data.downloadUrl) {
        // Trigger download via hidden iframe or anchor navigation to server URL
        const iframe = document.createElement('iframe');
        iframe.style.display = 'none';
        iframe.src = data.downloadUrl;
        document.body.appendChild(iframe);
        setTimeout(() => {
          try {
            if (iframe.parentNode) iframe.parentNode.removeChild(iframe);
          } catch {
            // Ignore cleanup
          }
        }, 30000);
        return true;
      }
    }
  } catch (serverErr) {
    console.warn('Server download preparation failed, falling back to client-side Blob:', serverErr);
  }

  // Strategy 2: Client-side Blob download fallback
  try {
    let blob: Blob;
    if (isBase64) {
      const base64Data = content.replace(/^data:.*?;base64,/, '');
      const byteString = atob(base64Data);
      const ab = new ArrayBuffer(byteString.length);
      const ia = new Uint8Array(ab);
      for (let i = 0; i < byteString.length; i++) {
        ia[i] = byteString.charCodeAt(i);
      }
      blob = new Blob([ab], { type: contentType });
    } else {
      blob = new Blob(['\ufeff', content], { type: contentType });
    }

    return downloadBlob(blob, cleanName);
  } catch (err) {
    console.error('All download methods failed:', err);
    return false;
  }
}

/**
 * Download a Blob safely with long-lived URL retention
 */
export function downloadBlob(blob: Blob, fileName: string): boolean {
  try {
    const cleanName = sanitizeFileName(fileName, 'download');
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.style.display = 'none';
    link.href = url;
    link.download = cleanName;
    link.rel = 'noopener noreferrer';

    // Must be attached to the DOM for Chromium & Safari iframe compatibility
    document.body.appendChild(link);
    link.click();

    // Delay removal and keep object URL alive for 5 minutes so background download manager succeeds
    setTimeout(() => {
      try {
        if (link.parentNode) {
          link.parentNode.removeChild(link);
        }
        setTimeout(() => {
          try {
            URL.revokeObjectURL(url);
          } catch {
            // Ignore
          }
        }, 300000); // 5 minutes
      } catch (err) {
        console.warn('Cleanup error after download:', err);
      }
    }, 1500);

    return true;
  } catch (err) {
    console.error('Failed to trigger download via Blob:', err);
    return false;
  }
}

/**
 * Download a base64 Data URL safely
 */
export function downloadDataUrl(dataUrl: string, fileName: string): boolean {
  try {
    const cleanName = sanitizeFileName(fileName, 'download');

    if (!dataUrl || !dataUrl.trim()) {
      return false;
    }

    if (!dataUrl.startsWith('data:')) {
      // Standard URL
      const link = document.createElement('a');
      link.style.display = 'none';
      link.href = dataUrl;
      link.download = cleanName;
      document.body.appendChild(link);
      link.click();
      setTimeout(() => {
        if (link.parentNode) link.parentNode.removeChild(link);
      }, 1500);
      return true;
    }

    // Extract mime type
    const mimeMatch = dataUrl.substring(0, 50).match(/data:(.*?);base64/);
    const mime = mimeMatch ? mimeMatch[1] : 'application/octet-stream';

    // Call universal downloader
    downloadFileUniversal({
      fileName: cleanName,
      content: dataUrl,
      contentType: mime,
      isBase64: true,
    });

    return true;
  } catch (err) {
    console.error('Failed to download data URL:', err);
    return false;
  }
}

/**
 * In-page safe printing using a hidden iframe.
 * Avoids window.open / popup blocker and avoids opening blank blob tabs.
 */
export function printHtmlSafely(htmlContent: string, onComplete?: () => void): boolean {
  try {
    const iframe = document.createElement('iframe');
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = '0';
    document.body.appendChild(iframe);

    const doc = iframe.contentWindow?.document;
    if (!doc) {
      document.body.removeChild(iframe);
      return false;
    }

    doc.open();
    doc.write(htmlContent);
    doc.close();

    // Allow fonts and styles to render before triggering print
    setTimeout(() => {
      try {
        iframe.contentWindow?.focus();
        iframe.contentWindow?.print();
        if (onComplete) onComplete();
      } catch (printErr) {
        console.warn('iframe print failed, falling back to popup window:', printErr);
        openHtmlInNewWindow(htmlContent, 'Print Document');
      } finally {
        setTimeout(() => {
          try {
            if (iframe.parentNode) iframe.parentNode.removeChild(iframe);
          } catch {
            // Ignore
          }
        }, 15000);
      }
    }, 400);

    return true;
  } catch (err) {
    console.error('Safe print error:', err);
    return false;
  }
}

/**
 * Opens formatted HTML in a new window as a fallback.
 * Uses document.write inside a new window; avoids navigating to a raw blob URL.
 */
export function openHtmlInNewWindow(htmlContent: string, title: string): boolean {
  try {
    const newWindow = window.open('', '_blank');
    if (newWindow) {
      newWindow.document.open();
      newWindow.document.write(htmlContent);
      newWindow.document.close();
      newWindow.document.title = title;
      return true;
    }

    // If popup blocked, prepare via server view URL
    fetch('/api/file/prepare-download', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        fileName: `${title}.html`,
        content: htmlContent,
        contentType: 'text/html; charset=utf-8',
        isBase64: false,
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data?.viewUrl) {
          window.open(data.viewUrl, '_blank');
        }
      })
      .catch((err) => console.warn('Server view fallback failed:', err));

    return false;
  } catch (err) {
    console.error('Failed to open HTML in new window:', err);
    return false;
  }
}

/**
 * Copies rich HTML to clipboard so users can paste directly into Microsoft Word or Google Docs
 * with all fonts, colors, and tables preserved!
 */
export async function copyRichHtmlToClipboard(htmlContent: string, plainTextFallback: string): Promise<boolean> {
  try {
    if (navigator.clipboard && window.ClipboardItem) {
      const blobHtml = new Blob([htmlContent], { type: 'text/html' });
      const blobText = new Blob([plainTextFallback], { type: 'text/plain' });
      const clipboardItem = new ClipboardItem({
        'text/html': blobHtml,
        'text/plain': blobText,
      });
      await navigator.clipboard.write([clipboardItem]);
      return true;
    } else if (navigator.clipboard) {
      await navigator.clipboard.writeText(plainTextFallback);
      return true;
    }
    return false;
  } catch (err) {
    console.warn('Rich clipboard copy failed, trying plain text:', err);
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(plainTextFallback);
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }
}
