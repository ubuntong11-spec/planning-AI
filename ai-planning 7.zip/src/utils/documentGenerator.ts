import { ExecutiveSummaryData, PlanData } from '../types/plan';

/**
 * Generates clean HTML block for the 1-page Executive Summary introduction
 */
export function generateExecutiveSummaryBodyHtml(plan: PlanData, summary: ExecutiveSummaryData): string {
  const renderList = (items: string[] = []) =>
    items
      .filter((x) => x && x.trim())
      .map((item) => `<li style="margin-bottom: 3px; line-height: 1.45;">${item}</li>`)
      .join('');

  return `
    <div class="exec-summary-page" style="page-break-after: always; break-after: page; font-family: 'Kantumruy Pro', 'Khmer OS Siemreap', 'Battambang', Arial, sans-serif; color: #0f172a;">
      <div style="text-align: center; margin-bottom: 10px; border-bottom: 2px solid #1e3a8a; padding-bottom: 8px;">
        <div style="font-size: 12pt; font-weight: bold; color: #1e3a8a;">ព្រះរាជាណាចក្រកម្ពុជា</div>
        <div style="font-size: 10.5pt; font-weight: bold; color: #1e3a8a; margin-top: 2px;">ជាតិ សាសនា ព្រះមហាក្សត្រ</div>
        <div style="display: flex; justify-content: space-between; font-size: 9pt; text-align: left; margin-top: 8px; color: #334155;">
          <div>
            <strong>ក្រសួងអប់រំ យុវជន និងកីឡា</strong><br/>
            <span>${plan.location || ''}</span> • <strong style="color: #1e3a8a;">${plan.schoolName || ''}</strong>
          </div>
          <div style="text-align: right;">
            <strong>${plan.academicYear || ''}</strong><br/>
            <span>${plan.schoolType || ''}</span>
          </div>
        </div>
        <h1 style="font-size: 13.5pt; font-weight: bold; color: #1e3a8a; margin: 10px 0 2px 0;">
          សេចក្តីសង្ខេបប្រតិបត្តិ (EXECUTIVE SUMMARY)
        </h1>
        <div style="font-size: 10pt; font-weight: 600; color: #334155;">
          ${summary.documentTitle || `ទំព័រណែនាំ៖ ${plan.title}`}
        </div>
      </div>

      <!-- 1. Overview -->
      <div style="background-color: #f8fafc; border: 1px solid #cbd5e1; border-left: 4px solid #1d4ed8; padding: 8px 10px; border-radius: 6px; margin-bottom: 10px;">
        <div style="font-size: 9.5pt; font-weight: bold; color: #1e3a8a; margin-bottom: 3px;">១. ទិដ្ឋភាពទូទៅ និងគោលបំណងស្នូល</div>
        <div style="font-size: 9pt; line-height: 1.5; text-align: justify; color: #1e293b;">
          ${summary.executiveOverview || ''}
        </div>
      </div>

      <!-- 2. Budget Snapshot Row -->
      <table style="width: 100%; border-collapse: collapse; margin: 0 0 10px 0; font-size: 8.5pt;">
        <tr>
          <td style="width: 33%; border: 1px solid #cbd5e1; background-color: #eff6ff; padding: 6px 8px; text-align: center;">
            <div style="color: #1e40af; font-weight: bold;">ថវិកាគ្រោងសរុប (N+1)</div>
            <div style="font-size: 10.5pt; font-weight: bold; color: #1e3a8a; margin-top: 2px;">${summary.budgetSummary?.totalBudgetRiel || '-'}</div>
          </td>
          <td style="width: 33%; border: 1px solid #cbd5e1; background-color: #f0fdf4; padding: 6px 8px; text-align: center;">
            <div style="color: #166534; font-weight: bold;">ថវិការដ្ឋ (PB)</div>
            <div style="font-size: 10.5pt; font-weight: bold; color: #14532d; margin-top: 2px;">${summary.budgetSummary?.stateBudgetRiel || '-'}</div>
          </td>
          <td style="width: 34%; border: 1px solid #cbd5e1; background-color: #fffbeb; padding: 6px 8px; text-align: center;">
            <div style="color: #92400e; font-weight: bold;">សហគមន៍ / ឃុំ / ដៃគូ</div>
            <div style="font-size: 10.5pt; font-weight: bold; color: #78350f; margin-top: 2px;">${summary.budgetSummary?.communityAndPartnerRiel || '-'}</div>
          </td>
        </tr>
        ${summary.budgetSummary?.resourceNote ? `
        <tr>
          <td colspan="3" style="border: 1px solid #cbd5e1; background-color: #ffffff; padding: 5px 8px; font-size: 8.5pt; color: #334155;">
            <strong>យុទ្ធសាស្ត្រធនធាន៖</strong> ${summary.budgetSummary.resourceNote}
          </td>
        </tr>` : ''}
      </table>

      <!-- 3. Strengths & Challenges 2-column grid -->
      <table style="width: 100%; border-collapse: collapse; margin: 0 0 10px 0; font-size: 8.5pt;">
        <tr>
          <td style="width: 50%; border: 1px solid #cbd5e1; padding: 7px 9px; vertical-align: top; background-color: #f0fdf4;">
            <div style="font-weight: bold; color: #166534; font-size: 9pt; margin-bottom: 4px;">២. ចំណុចខ្លាំង និងវឌ្ឍនភាពគន្លឹះ</div>
            <ul style="margin: 0; padding-left: 16px; color: #1e293b;">
              ${renderList(summary.keyStrengths)}
            </ul>
          </td>
          <td style="width: 50%; border: 1px solid #cbd5e1; padding: 7px 9px; vertical-align: top; background-color: #fff7ed;">
            <div style="font-weight: bold; color: #9a3412; font-size: 9pt; margin-bottom: 4px;">៣. បញ្ហាប្រឈមអាទិភាពត្រូវដោះស្រាយ</div>
            <ul style="margin: 0; padding-left: 16px; color: #1e293b;">
              ${renderList(summary.criticalChallenges)}
            </ul>
          </td>
        </tr>
      </table>

      <!-- 4. Strategic Priorities & Expected Outcomes 2-column grid -->
      <table style="width: 100%; border-collapse: collapse; margin: 0 0 10px 0; font-size: 8.5pt;">
        <tr>
          <td style="width: 50%; border: 1px solid #cbd5e1; padding: 7px 9px; vertical-align: top; background-color: #ffffff;">
            <div style="font-weight: bold; color: #1e3a8a; font-size: 9pt; margin-bottom: 4px;">៤. អាទិភាពយុទ្ធសាស្ត្រ និងសកម្មភាពស្នូល</div>
            <ul style="margin: 0; padding-left: 16px; color: #1e293b;">
              ${renderList(summary.strategicPriorities)}
            </ul>
          </td>
          <td style="width: 50%; border: 1px solid #cbd5e1; padding: 7px 9px; vertical-align: top; background-color: #ffffff;">
            <div style="font-weight: bold; color: #0f766e; font-size: 9pt; margin-bottom: 4px;">៥. លទ្ធផលសមិទ្ធកម្មរំពឹងទុក</div>
            <ul style="margin: 0; padding-left: 16px; color: #1e293b;">
              ${renderList(summary.expectedOutcomes)}
            </ul>
          </td>
        </tr>
      </table>

      <!-- 5. Closing Statement & Signature -->
      <div style="background-color: #f8fafc; border: 1px solid #cbd5e1; padding: 7px 10px; border-radius: 6px; font-size: 8.5pt; margin-bottom: 10px;">
        <strong>៦. សេចក្តីសន្និដ្ឋាន និងការប្តេជ្ញាចិត្ត៖</strong> ${summary.closingStatement || ''}
      </div>

      <div style="display: flex; justify-content: space-between; font-size: 8.5pt; margin-top: 8px; page-break-inside: avoid;">
        <div style="width: 45%; text-align: center;">
          <div>បានឃើញ និងឯកភាព</div>
          <div style="font-weight: bold; margin-top: 2px;">ប្រធានការិយាល័យអប់រំ យុវជន និងកីឡា</div>
        </div>
        <div style="width: 45%; text-align: center;">
          <div>${plan.createdDate || 'ថ្ងៃ.........ខែ.........ឆ្នាំ.........'}</div>
          <div style="font-weight: bold; margin-top: 2px;">នាយក / នាយិកាសាលា</div>
        </div>
      </div>
    </div>
  `;
}

/**
 * Standalone printable 1-page A4 HTML document for the Executive Summary
 */
export function generateExecutiveSummaryStandaloneHtml(plan: PlanData, summary: ExecutiveSummaryData): string {
  return `<!DOCTYPE html>
<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
<head>
  <meta charset="utf-8">
  <title>សេចក្តីសង្ខេបប្រតិបត្តិ - ${plan.schoolName}</title>
  <link href="https://fonts.googleapis.com/css2?family=Kantumruy+Pro:wght@400;600;700&display=swap" rel="stylesheet">
  <style>
    @page {
      size: A4 portrait;
      margin: 1.3cm 1.4cm;
    }
    body {
      font-family: 'Kantumruy Pro', 'Khmer OS Siemreap', 'Battambang', Arial, sans-serif;
      color: #0f172a;
      margin: 0;
      padding: 0;
      font-size: 9pt;
    }
    .exec-summary-page {
      page-break-after: auto !important;
      break-after: auto !important;
      max-width: 780px;
      margin: 0 auto;
    }
    @media print {
      body {
        margin: 0;
        padding: 0;
      }
    }
  </style>
</head>
<body>
  ${generateExecutiveSummaryBodyHtml(plan, summary)}
</body>
</html>`;
}

/**
 * Builds standard MoEYS HTML/Word compatible document markup
 */
export function generatePlanHtmlDocument(plan: PlanData): string {
  let htmlContent = `<!DOCTYPE html>
<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
<head>
  <meta charset="utf-8">
  <title>${plan.title || 'ផែនការប្រតិបត្តិប្រចាំឆ្នាំ (AOP)'}</title>
  <style>
    @page {
      size: A4;
      margin: 2.5cm 2cm 2cm 2.5cm;
      mso-page-orientation: portrait;
    }
    body {
      font-family: 'Kantumruy Pro', 'Khmer OS Siemreap', 'Battambang', Arial, sans-serif;
      line-height: 1.6;
      color: #1e293b;
      font-size: 11pt;
      margin: 20px auto;
      max-width: 800px;
      padding: 20px;
    }
    .header-block {
      text-align: center;
      margin-bottom: 25px;
    }
    .kingdom-title {
      font-size: 15pt;
      font-weight: bold;
      color: #1e3a8a;
      margin: 0;
    }
    .kingdom-subtitle {
      font-size: 13pt;
      font-weight: bold;
      color: #1e3a8a;
      margin: 4px 0;
    }
    .divider-line {
      font-weight: bold;
      color: #2563eb;
      margin-bottom: 15px;
    }
    .school-info {
      font-size: 12pt;
      color: #0f172a;
      margin: 6px 0;
    }
    .main-title {
      font-size: 17pt;
      font-weight: bold;
      color: #1e3a8a;
      margin: 15px 0 5px 0;
      text-transform: uppercase;
    }
    .main-subtitle {
      font-size: 11pt;
      font-style: italic;
      color: #475569;
      margin: 0 0 15px 0;
    }
    h2 {
      font-size: 13pt;
      color: #1e3a8a;
      border-bottom: 1.5px solid #94a3b8;
      padding-bottom: 4px;
      margin-top: 25px;
      margin-bottom: 10px;
    }
    h3 {
      font-size: 12pt;
      color: #1e40af;
      margin-top: 15px;
      margin-bottom: 6px;
    }
    h4 {
      font-size: 11pt;
      color: #334155;
      margin-top: 10px;
      margin-bottom: 4px;
    }
    p {
      text-align: justify;
      margin: 6px 0 10px 0;
      line-height: 1.7;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin: 15px 0;
      font-size: 10pt;
    }
    th, td {
      border: 1px solid #475569;
      padding: 6px 8px;
      text-align: left;
      vertical-align: top;
    }
    th {
      background-color: #f1f5f9;
      color: #0f172a;
      font-weight: bold;
      text-align: center;
    }
    .bg-blue-header {
      background-color: #1e3a8a !important;
      color: #ffffff !important;
      font-weight: bold;
    }
    .bg-sub-header {
      background-color: #e2e8f0 !important;
      font-weight: bold;
    }
    .text-center {
      text-align: center;
    }
    .text-right {
      text-align: right;
    }
    @media print {
      body {
        margin: 0;
        padding: 0;
        max-width: 100%;
      }
      .no-print {
        display: none !important;
      }
    }
  </style>
</head>
<body>
  ${plan.executiveSummary ? generateExecutiveSummaryBodyHtml(plan, plan.executiveSummary) : ''}
  <div class="header-block">
    <div class="kingdom-title">ព្រះរាជាណាចក្រកម្ពុជា</div>
    <div class="kingdom-subtitle">ជាតិ សាសនា ព្រះមហាក្សត្រ</div>
    <div class="divider-line">3 3 3</div>
    <div class="school-info">
      <strong>ក្រសួងអប់រំ យុវជន និងកីឡា</strong><br/>
      <strong>${plan.schoolName || 'សាលាបឋមសិក្សា'}</strong> — <strong>ឆ្នាំសិក្សា ${plan.academicYear || '២០២៤-២០២៥'}</strong>
    </div>
    <div class="main-title">${plan.title || 'ផែនការប្រតិបត្តិប្រចាំឆ្នាំ (AOP)'}</div>
    <div class="main-subtitle">${plan.subtitle || ''}</div>
  </div>
  <hr style="border: 0; border-top: 1px solid #cbd5e1; margin-bottom: 20px;"/>
`;

  // Content Sections
  if (plan.sections && plan.sections.length > 0) {
    for (const sec of plan.sections) {
      htmlContent += `<h2>${sec.code}. ${sec.title}</h2>`;
      if (sec.content) {
        htmlContent += `<p>${sec.content.replace(/\n/g, '<br/>')}</p>`;
      }
      if (sec.subsections && sec.subsections.length > 0) {
        for (const sub of sec.subsections) {
          htmlContent += `<h3>${sub.code}. ${sub.title}</h3>`;
          if (sub.content) {
            htmlContent += `<p>${sub.content.replace(/\n/g, '<br/>')}</p>`;
          }
          if (sub.items && sub.items.length > 0) {
            for (const item of sub.items) {
              htmlContent += `<h4>• ${item.title}</h4>`;
              if (item.content) {
                htmlContent += `<p>${item.content.replace(/\n/g, '<br/>')}</p>`;
              }
            }
          }
        }
      }
    }
  }

  // Section 4.1 Standard Targets Table
  if (plan.standardTargets && plan.standardTargets.length > 0) {
    htmlContent += `<h2>៤.១ តារាងស្តង់ដា និងសូចនាករគ្រោងថវិកា (ឆ្នាំ N+1)</h2>
    <table>
      <thead>
        <tr>
          <th style="width: 8%;">ល.រ</th>
          <th style="width: 32%;">ស្តង់ដា និងសូចនាករ</th>
          <th style="width: 10%;">ឯកតា</th>
          <th style="width: 10%;">លទ្ធផល N</th>
          <th style="width: 10%;">គោលដៅ N+1</th>
          <th style="width: 15%;">ថវិការដ្ឋ (រៀល)</th>
          <th style="width: 15%;">ថវិកាសរុប (រៀល)</th>
        </tr>
      </thead>
      <tbody>`;
    
    plan.standardTargets.forEach((std) => {
      const stdState = std.rows.reduce((sum, r) => sum + (r.isCategoryHeader ? 0 : (r.stateBudget || 0)), 0);
      htmlContent += `
        <tr class="bg-blue-header">
          <td colspan="3" style="color:white; font-weight:bold;">${std.code}៖ ${std.title}</td>
          <td class="text-center" style="color:white;">-</td>
          <td class="text-center" style="color:white;">-</td>
          <td class="text-right" style="color:white; font-weight:bold;">${stdState.toLocaleString()}</td>
          <td class="text-right" style="color:white; font-weight:bold;">${stdState.toLocaleString()}</td>
        </tr>`;
      std.rows.forEach((r) => {
        if (r.isCategoryHeader) {
          htmlContent += `
            <tr class="bg-sub-header">
              <td class="text-center"><strong>${r.code}</strong></td>
              <td colspan="4"><strong>${r.title}</strong></td>
              <td class="text-right"><strong>${r.stateBudget.toLocaleString()}</strong></td>
              <td class="text-right"><strong>${r.stateBudget.toLocaleString()}</strong></td>
            </tr>`;
        } else {
          htmlContent += `
            <tr>
              <td class="text-center">${r.code}</td>
              <td>${r.title}</td>
              <td class="text-center">${r.unit}</td>
              <td class="text-center">${r.currentN}</td>
              <td class="text-center">${r.targetN1}</td>
              <td class="text-right">${r.stateBudget.toLocaleString()}</td>
              <td class="text-right">${(r.stateBudget + (r.nonStateBudget || 0)).toLocaleString()}</td>
            </tr>`;
        }
      });
    });
    htmlContent += `</tbody></table><br/>`;
  }

  // Section 5.1 Chapter Five 71 Actions Table
  if (plan.chapterFiveActions && plan.chapterFiveActions.length > 0) {
    htmlContent += `<h2>៥.១ តារាងសកម្មភាពអនុវត្តទាំង ៧១ តាមស្តង់ដាគន្លឹះ</h2>
    <table>
      <thead>
        <tr>
          <th style="width: 8%;">កូដ</th>
          <th style="width: 32%;">លទ្ធផលរំពឹងទុក</th>
          <th style="width: 30%;">សកម្មភាពអនុវត្ត</th>
          <th style="width: 10%;">ត្រីមាស</th>
          <th style="width: 10%;">អ្នកទទួលខុសត្រូវ</th>
          <th style="width: 10%;">ថវិកាសរុប</th>
        </tr>
      </thead>
      <tbody>`;
    plan.chapterFiveActions.forEach((grp) => {
      const grpTotal = grp.items.reduce((s, i) => s + (i.totalBudget || 0), 0);
      htmlContent += `
        <tr class="bg-blue-header">
          <td colspan="5" style="color:white; font-weight:bold;">${grp.standardTitle}</td>
          <td class="text-right" style="color:white; font-weight:bold;">${grpTotal.toLocaleString()}</td>
        </tr>`;
      grp.items.forEach((item) => {
        const qs = [item.q1 ? 'Q1' : '', item.q2 ? 'Q2' : '', item.q3 ? 'Q3' : '', item.q4 ? 'Q4' : ''].filter(Boolean).join(', ');
        htmlContent += `
          <tr>
            <td class="text-center"><strong>${item.code}</strong></td>
            <td><strong>${item.categoryTitle}</strong><br/>${item.expectedOutcome}</td>
            <td>${item.activities.replace(/\n/g, '<br/>')}</td>
            <td class="text-center">${qs || '-'}</td>
            <td>${item.responsiblePerson}</td>
            <td class="text-right">${item.totalBudget ? item.totalBudget.toLocaleString() : '-'}</td>
          </tr>`;
      });
    });
    htmlContent += `</tbody></table><br/>`;
  } else if (plan.actionMatrix && plan.actionMatrix.length > 0) {
    htmlContent += `<h2>៥.១ តារាងម៉ាទ្រីសសកម្មភាពអនុវត្ត</h2>
    <table>
      <thead>
        <tr>
          <th style="width: 6%;">ល.រ</th>
          <th style="width: 30%;">សកម្មភាព</th>
          <th style="width: 20%;">សូចនាករ</th>
          <th style="width: 10%;">កាលវិភាគ</th>
          <th style="width: 12%;">ថវិកា</th>
          <th style="width: 10%;">ប្រភព</th>
          <th style="width: 12%;">អ្នកទទួលខុសត្រូវ</th>
        </tr>
      </thead>
      <tbody>`;
    plan.actionMatrix.forEach((act, idx) => {
      htmlContent += `
        <tr>
          <td class="text-center">${idx + 1}</td>
          <td>${act.activity}</td>
          <td>${act.indicator}</td>
          <td class="text-center">${act.timeline}</td>
          <td class="text-right">${act.budget}</td>
          <td class="text-center">${act.budgetSource}</td>
          <td>${act.responsiblePerson}</td>
        </tr>`;
    });
    htmlContent += `</tbody></table>`;
  }

  htmlContent += `
  <div style="margin-top: 40px; display: flex; justify-content: space-between;">
    <div style="text-align: center; width: 45%;">
      <p>បានឃើញ និងឯកភាព<br/><strong>ប្រធានការិយាល័យអប់រំ យុវជន និងកីឡា</strong></p>
    </div>
    <div style="text-align: center; width: 45%;">
      <p>ថ្ងៃ...................ខែ............ឆ្នាំ...........<br/><strong>នាយក / នាយិកាសាលា</strong></p>
    </div>
  </div>
</body>
</html>`;

  return htmlContent;
}

/**
 * Builds the complete, official MoEYS 3-Year Rolling Budget Strategic Plan (BSP)
 * with 5 Standards table and the bottom Budget Requirement Summary table
 */
export function generateBspFullHtmlDocument(
  schoolName: string,
  academicYearsLabel: string,
  tableInnerHtml: string,
  budgetSummaryHtml?: string
): string {
  return `<!DOCTYPE html>
<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
<head>
  <meta charset="utf-8">
  <title>ផែនការយុទ្ធសាស្ត្រថវិកា ៣ ឆ្នាំ (BSP) - ${schoolName}</title>
  <style>
    @page {
      size: A4 landscape;
      margin: 1.5cm 1.5cm 1.5cm 1.5cm;
    }
    body {
      font-family: 'Kantumruy Pro', 'Khmer OS Siemreap', 'Battambang', Arial, sans-serif;
      line-height: 1.4;
      color: #0f172a;
      font-size: 10pt;
      margin: 15px auto;
      padding: 15px;
    }
    .header-box {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 20px;
    }
    .left-header {
      text-align: left;
      font-size: 10pt;
      line-height: 1.4;
    }
    .right-header {
      text-align: center;
      line-height: 1.4;
    }
    .kingdom-title {
      font-size: 13pt;
      font-weight: bold;
      color: #1e3a8a;
    }
    .kingdom-motto {
      font-size: 11pt;
      font-weight: bold;
      color: #1e3a8a;
    }
    .main-doc-title {
      text-align: center;
      font-size: 14pt;
      font-weight: bold;
      color: #1e3a8a;
      margin: 15px 0 5px 0;
      text-transform: uppercase;
    }
    .sub-doc-title {
      text-align: center;
      font-size: 11pt;
      color: #475569;
      margin-bottom: 20px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 25px;
      font-size: 9pt;
    }
    th, td {
      border: 1px solid #475569;
      padding: 4px 6px;
      vertical-align: middle;
    }
    th {
      background-color: #f1f5f9;
      font-weight: bold;
      text-align: center;
    }
    .std-header {
      background-color: #e2e8f0;
      font-weight: bold;
      color: #0f172a;
    }
    .category-header {
      background-color: #f8fafc;
      font-weight: bold;
    }
    .text-center { text-align: center; }
    .text-right { text-align: right; }
    .text-bold { font-weight: bold; }
    .signatures {
      margin-top: 35px;
      display: flex;
      justify-content: space-between;
      page-break-inside: avoid;
    }
    .sig-col {
      text-align: center;
      width: 23%;
      font-size: 9.5pt;
    }
    .sig-space {
      height: 70px;
    }
  </style>
</head>
<body>
  <!-- Header: Royal Government of Cambodia -->
  <div class="header-box">
    <div class="left-header">
      <strong>ក្រសួងអប់រំ យុវជន និងកីឡា</strong><br/>
      មន្ទីរអប់រំ យុវជន និងកីឡាខេត្ត<br/>
      ការិយាល័យអប់រំ យុវជន និងកីឡានៃរដ្ឋបាលស្រុក<br/>
      <strong>${schoolName}</strong>
    </div>
    <div class="right-header">
      <div class="kingdom-title">ព្រះរាជាណាចក្រកម្ពុជា</div>
      <div class="kingdom-motto">ជាតិ សាសនា ព្រះមហាក្សត្រ</div>
      <div style="font-size: 11pt; color: #2563eb;">3 3 3 2 2</div>
    </div>
  </div>

  <div class="main-doc-title">
    ផែនការយុទ្ធសាស្ត្រថវិកា ៣ ឆ្នាំរំកិល (BSP)
  </div>
  <div class="sub-doc-title">
    សម្រាប់អនុវត្ត និងវិនិយោគរួមជាមួយរដ្ឋបាលឃុំ/សង្កាត់ (CIP) និងសហគមន៍ • ឆ្នាំ ${academicYearsLabel}
  </div>

  <!-- The Full 5 Standards Table -->
  <table cellpadding="0" cellspacing="0">
    ${tableInnerHtml}
  </table>

  <!-- Bottom Budget Requirement Summary if provided -->
  ${budgetSummaryHtml ? budgetSummaryHtml : ''}

  <!-- Formal Signatures -->
  <div class="signatures">
    <div class="sig-col">
      <p>បានឃើញ និងឯកភាព<br/><strong>ប្រធានក្រុមប្រឹក្សាឃុំ/សង្កាត់</strong></p>
      <div class="sig-space"></div>
    </div>
    <div class="sig-col">
      <p>បានឃើញ និងពិនិត្យត្រឹមត្រូវ<br/><strong>ប្រធានការិយាល័យអប់រំ យុវជន និងកីឡា</strong></p>
      <div class="sig-space"></div>
    </div>
    <div class="sig-col">
      <p>បានឃើញ និងគាំទ្រ<br/><strong>ប្រធាន គ.គ.ស.</strong></p>
      <div class="sig-space"></div>
    </div>
    <div class="sig-col">
      <p>ថ្ងៃ..................ខែ.........ឆ្នាំ ២០២...<br/><strong>នាយកសាលាបឋមសិក្សា</strong></p>
      <div class="sig-space"></div>
    </div>
  </div>
</body>
</html>`;
}

