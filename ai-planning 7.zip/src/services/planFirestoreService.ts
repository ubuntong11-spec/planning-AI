import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  deleteDoc, 
  query, 
  orderBy, 
  onSnapshot 
} from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../firebase';
import { PlanData } from '../types/plan';
import { DEFAULT_PLAN_DATA } from '../data/defaultPlan';

const PLANS_COLLECTION = 'plans';

/**
 * Recursively removes all undefined values from an object or array.
 * Firestore strictly forbids `undefined` in setDoc and updateDoc.
 */
export function sanitizeForFirestore<T>(data: T): T {
  if (data === null || data === undefined) {
    return null as any;
  }
  if (Array.isArray(data)) {
    return data
      .filter((item) => item !== undefined)
      .map((item) => sanitizeForFirestore(item)) as any;
  }
  if (typeof data === 'object') {
    const cleaned: Record<string, any> = {};
    for (const [key, value] of Object.entries(data)) {
      if (value !== undefined) {
        cleaned[key] = sanitizeForFirestore(value);
      }
    }
    return cleaned as T;
  }
  return data;
}

// Save or Auto-save Plan to Firestore
export async function savePlanToFirestore(plan: PlanData): Promise<void> {
  const planId = plan.id || 'plan-main-aop-2025';
  const path = `${PLANS_COLLECTION}/${planId}`;

  try {
    const docRef = doc(db, PLANS_COLLECTION, planId);
    const rawData = {
      ...plan,
      id: planId,
      updatedAt: new Date().toISOString(),
      userId: auth.currentUser?.uid || 'guest-user',
    };
    const dataToSave = sanitizeForFirestore(rawData);
    await setDoc(docRef, dataToSave, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

// Get single Plan by ID
export async function getPlanFromFirestore(planId: string): Promise<PlanData | null> {
  const path = `${PLANS_COLLECTION}/${planId}`;
  try {
    const docRef = doc(db, PLANS_COLLECTION, planId);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      return snap.data() as PlanData;
    }
    return null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
    return null;
  }
}

// List all plans from Firestore (For multi-plan management)
export async function listPlansFromFirestore(): Promise<PlanData[]> {
  const path = PLANS_COLLECTION;
  try {
    const q = query(collection(db, PLANS_COLLECTION));
    const snapshot = await getDocs(q);
    const plans: PlanData[] = [];
    snapshot.forEach(docSnap => {
      plans.push(docSnap.data() as PlanData);
    });
    return plans;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}

// Create a new Plan (Supports "មាន២ផែនការទៀត នឹងបង្កើតពេលក្រោយ")
export async function createNewPlanInFirestore(title: string, academicYear: string, templateType: string = 'aop'): Promise<PlanData> {
  const newId = `plan-${Date.now()}`;
  const newPlan: PlanData = {
    ...DEFAULT_PLAN_DATA,
    id: newId,
    title: title || 'ផែនការប្រតិបត្តិថ្មី',
    subtitle: 'ផែនការប្រតិបត្តិ និងតាមដានការអនុវត្ត',
    academicYear: academicYear || 'ឆ្នាំសិក្សា ២០២៥-២០២៦',
    createdDate: new Date().toLocaleDateString('km-KH', { month: 'long', year: 'numeric' }),
    updatedAt: new Date().toISOString(),
    userId: auth.currentUser?.uid || 'guest-user',
  };

  await savePlanToFirestore(newPlan);
  return newPlan;
}

// Delete plan
export async function deletePlanFromFirestore(planId: string): Promise<void> {
  const path = `${PLANS_COLLECTION}/${planId}`;
  try {
    const docRef = doc(db, PLANS_COLLECTION, planId);
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// Real-time plan sync
export function subscribeToPlan(planId: string, onUpdate: (plan: PlanData) => void, onError?: (err: any) => void) {
  const path = `${PLANS_COLLECTION}/${planId}`;
  const docRef = doc(db, PLANS_COLLECTION, planId);

  return onSnapshot(docRef, (snap) => {
    if (snap.exists()) {
      onUpdate(snap.data() as PlanData);
    }
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, path);
    if (onError) onError(error);
  });
}
