import React, { useState, useEffect } from 'react';
import { DEFAULT_PLAN_DATA } from './data/defaultPlan';
import { PlanData, PlanGeneratorParams, PlanSection, PlanSubsection, PlanItem, SchoolContextProfile, ExecutiveSummaryData } from './types/plan';
import { SchoolAssessmentData } from './types/assessment';
import { DEFAULT_ASSESSMENT_DATA } from './data/schoolAssessmentData';
import { Navbar } from './components/Navbar';
import { SidebarOutline } from './components/SidebarOutline';
import { SectionEditor } from './components/SectionEditor';
import { FormalDocumentView } from './components/FormalDocumentView';
import { SchoolAssessmentView } from './components/SchoolAssessmentView';
import { PlanGeneratorModal } from './components/PlanGeneratorModal';
import { PlanListModal } from './components/PlanListModal';
import { SchoolContextModal } from './components/SchoolContextModal';
import { ExportModal } from './components/ExportModal';
import { ExecutiveSummaryModal } from './components/ExecutiveSummaryModal';
import { generatePlanHtmlDocument } from './utils/documentGenerator';
import { downloadBlob, sanitizeFileName } from './utils/fileDownloader';
import { safeFetchJson } from './utils/apiHelper';
import { 
  savePlanToFirestore, 
  listPlansFromFirestore, 
  createNewPlanInFirestore, 
  deletePlanFromFirestore 
} from './services/planFirestoreService';
import { testFirestoreConnection } from './firebase';
import { 
  Menu, 
  X, 
  Sparkles, 
  AlertCircle, 
  CheckCircle2, 
  Layers, 
  Info, 
  Calendar, 
  School, 
  MapPin, 
  ChevronRight,
  Cloud,
  Edit3,
  Eye,
  Building2,
  Award,
  BarChart3
} from 'lucide-react';
import { ActionMatrixDashboard } from './components/ActionMatrixDashboard';
import { ThreeYearBspView } from './components/ThreeYearBspView';
import { InteractiveMeetingWalkthrough } from './components/InteractiveMeetingWalkthrough';
import { ThreeYearBspPlan } from './types/bsp';
import { DEFAULT_BSP_DATA } from './data/defaultBspData';

const STORAGE_KEY = 'khmer_operational_plan_v1';
const ASSESSMENT_STORAGE_KEY = 'khmer_school_assessment_v1';
const BSP_STORAGE_KEY = 'khmer_three_year_bsp_v1';

function normalizeStandardFourTitle(planData: PlanData): PlanData {
  if (!planData) return planData;
  const isOldStd4Title = (t: string) => 
    t === 'ដំណើរការប្រតិបត្តិរបស់សាលារៀន' || 
    t === 'ដំណើរការប្រតិបត្តិរបស់សាលា' || 
    t === 'ដំណើរការប្រតិបត្តិ និងរដ្ឋបាលសាលារៀន';

  const updatedSections = planData.sections?.map(sec => ({
    ...sec,
    subsections: sec.subsections?.map(sub => ({
      ...sub,
      title: isOldStd4Title(sub.title) ? 'អភិបាលកិច្ចរបស់សាលារៀន' : sub.title,
      items: sub.items?.map(item => ({
        ...item,
        title: isOldStd4Title(item.title) ? 'អភិបាលកិច្ចរបស់សាលារៀន' : item.title,
      }))
    }))
  }));

  const updatedStandardTargets = planData.standardTargets?.map(std => {
    if (std.id === 'std-4' || std.code === 'ស្តង់ដាទី៤' || isOldStd4Title(std.title)) {
      return { ...std, title: 'អភិបាលកិច្ចរបស់សាលារៀន' };
    }
    return std;
  });

  const updatedChapterFiveActions = planData.chapterFiveActions?.map(grp => {
    if (grp.id === 'c5-std-4' || grp.standardTitle?.includes('ស្តង់ដាទី៤')) {
      return { ...grp, standardTitle: 'ស្តង់ដាទី៤៖ អភិបាលកិច្ចរបស់សាលារៀន' };
    }
    return grp;
  });

  return {
    ...planData,
    sections: updatedSections || planData.sections,
    standardTargets: updatedStandardTargets || planData.standardTargets,
    chapterFiveActions: updatedChapterFiveActions || planData.chapterFiveActions,
  };
}

function normalizeAssessmentData(data: SchoolAssessmentData): SchoolAssessmentData {
  if (!data || !data.standards) return data;
  return {
    ...data,
    standards: data.standards.map(std => {
      if (std.id === 'std-4' || std.standardNumber === 4) {
        return { ...std, title: 'អភិបាលកិច្ចរបស់សាលារៀន' };
      }
      return std;
    })
  };
}

export default function App() {
  const [plan, setPlan] = useState<PlanData>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return normalizeStandardFourTitle(JSON.parse(saved));
    } catch (e) {
      console.warn('Failed to parse saved plan:', e);
    }
    return normalizeStandardFourTitle(DEFAULT_PLAN_DATA);
  });

  const [assessmentData, setAssessmentData] = useState<SchoolAssessmentData>(() => {
    try {
      const saved = localStorage.getItem(ASSESSMENT_STORAGE_KEY);
      if (saved) return normalizeAssessmentData(JSON.parse(saved));
    } catch (e) {
      console.warn('Failed to parse saved assessment:', e);
    }
    return normalizeAssessmentData(DEFAULT_ASSESSMENT_DATA);
  });

  const [activeSectionId, setActiveSectionId] = useState<string>('sec-1');
  const [viewMode, setViewMode] = useState<'edit' | 'preview' | 'assessment' | 'dashboard' | 'bsp'>('edit');
  const [bspPlan, setBspPlan] = useState<ThreeYearBspPlan>(() => {
    try {
      const saved = localStorage.getItem(BSP_STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Failed to parse saved BSP:', e);
    }
    return DEFAULT_BSP_DATA;
  });
  const [isWalkthroughOpen, setIsWalkthroughOpen] = useState(false);
  const [isGeneratorOpen, setIsGeneratorOpen] = useState(false);
  const [isPlanListOpen, setIsPlanListOpen] = useState(false);
  const [isSchoolContextOpen, setIsSchoolContextOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isExecutiveSummaryOpen, setIsExecutiveSummaryOpen] = useState(false);
  const [allPlans, setAllPlans] = useState<PlanData[]>([normalizeStandardFourTitle(DEFAULT_PLAN_DATA)]);
  const [isGeneratingAll, setIsGeneratingAll] = useState(false);
  const [isLoadingSectionAi, setIsLoadingSectionAi] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving' | 'error'>('saved');
  const [lastSavedTime, setLastSavedTime] = useState<Date>(new Date());

  // Save BSP plan changes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(BSP_STORAGE_KEY, JSON.stringify(bspPlan));
    } catch (e) {
      console.warn('Failed to save BSP plan:', e);
    }
  }, [bspPlan]);

  // Initialize and load plans from Firestore
  useEffect(() => {
    testFirestoreConnection();
    listPlansFromFirestore()
      .then((plans) => {
        if (plans.length > 0) {
          const normalizedPlans = plans.map(normalizeStandardFourTitle);
          setAllPlans(normalizedPlans);
          const found = normalizedPlans.find((p) => p.id === plan.id);
          if (found) {
            setPlan(found);
          }
        } else {
          savePlanToFirestore(normalizeStandardFourTitle(DEFAULT_PLAN_DATA)).then(() => {
            setAllPlans([normalizeStandardFourTitle(DEFAULT_PLAN_DATA)]);
          });
        }
      })
      .catch((e) => console.warn('Failed to load plans from Firestore:', e));
  }, []);

  // Auto-save to Firestore and LocalStorage with status indicator
  useEffect(() => {
    setSaveStatus('saving');
    const timer = setTimeout(async () => {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(plan));
        await savePlanToFirestore(plan);
        setSaveStatus('saved');
        setLastSavedTime(new Date());
        setAllPlans((prev) => prev.map((p) => (p.id === plan.id ? plan : p)));
      } catch (e) {
        console.warn('Failed to auto-save plan to Firestore:', e);
        setSaveStatus('error');
      }
    }, 600);

    return () => clearTimeout(timer);
  }, [plan]);

  // Auto-save assessment data to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem(ASSESSMENT_STORAGE_KEY, JSON.stringify(assessmentData));
    } catch (e) {
      console.warn('Failed to save assessment to localStorage:', e);
    }
  }, [assessmentData]);

  const handleResetAssessment = () => {
    if (window.confirm('តើលោកអ្នកពិតជាចង់កំណត់ទិន្នន័យវាយតម្លៃឡើងវិញជាគំរូដើមមែនទេ?')) {
      setAssessmentData(DEFAULT_ASSESSMENT_DATA);
      localStorage.removeItem(ASSESSMENT_STORAGE_KEY);
      showToast('បានកំណត់ទិន្នន័យវាយតម្លៃឡើងវិញជាគំរូដើម!');
    }
  };

  const handleSaveSchoolProfile = (profile: SchoolContextProfile) => {
    setPlan((prev) => ({
      ...prev,
      schoolContextProfile: profile,
    }));
    // Also sync assessment school name
    setAssessmentData((prev) => ({
      ...prev,
      generalInfo: {
        ...prev.generalInfo,
        schoolName: plan.schoolName,
      },
    }));
    showToast('បានរក្សាទុកព័ត៌មានបរិបទសាលារៀនជោគជ័យ!');
  };

  const formatSaveTime = (date: Date) => {
    return date.toLocaleTimeString('km-KH', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };

  const handleManualSave = async () => {
    setSaveStatus('saving');
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(plan));
      await savePlanToFirestore(plan);
      setSaveStatus('saved');
      setLastSavedTime(new Date());
      showToast('បានរក្សាទុកក្នុង Firestore និង Local Storage រួចរាល់!');
    } catch (e) {
      setSaveStatus('error');
    }
  };

  const handleSelectPlan = (selected: PlanData) => {
    setPlan(selected);
    setActiveSectionId('sec-1');
    showToast(`បានបើកផែនការ៖ ${selected.title}`);
  };

  const handleCreateNewPlan = async (title: string, academicYear: string) => {
    try {
      const created = await createNewPlanInFirestore(title, academicYear);
      setAllPlans((prev) => [...prev, created]);
      setPlan(created);
      setActiveSectionId('sec-1');
      showToast(`បានបង្កើតផែនការថ្មីជោគជ័យ៖ ${title}`);
    } catch (e) {
      alert('មានបញ្ហាក្នុងការបង្កើតផែនការថ្មី');
    }
  };

  const handleDeletePlan = async (planId: string) => {
    try {
      await deletePlanFromFirestore(planId);
      const remaining = allPlans.filter((p) => p.id !== planId);
      setAllPlans(remaining);
      if (plan.id === planId && remaining.length > 0) {
        setPlan(remaining[0]);
      }
      showToast('បានលុបផែនការរួចរាល់!');
    } catch (e) {
      alert('មានបញ្ហាក្នុងការលុបផែនការ');
    }
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Find active node information in tree
  const findActiveNode = () => {
    for (const sec of plan.sections) {
      if (sec.id === activeSectionId) {
        return {
          id: sec.id,
          code: sec.code,
          title: sec.title,
          parentTitle: undefined,
          content: sec.content,
          type: 'section' as const,
        };
      }
      if (sec.subsections) {
        for (const sub of sec.subsections) {
          if (sub.id === activeSectionId) {
            return {
              id: sub.id,
              code: sub.code,
              title: sub.title,
              parentTitle: `${sec.code}. ${sec.title}`,
              content: sub.content,
              type: 'subsection' as const,
            };
          }
          if (sub.items) {
            for (const item of sub.items) {
              if (item.id === activeSectionId) {
                return {
                  id: item.id,
                  code: undefined,
                  title: item.title,
                  parentTitle: `${sec.code}. ${sec.title} > ${sub.title}`,
                  content: item.content,
                  type: 'item' as const,
                };
              }
            }
          }
        }
      }
    }
    // Fallback to first section
    return {
      id: plan.sections[0]?.id || 'sec-1',
      code: plan.sections[0]?.code,
      title: plan.sections[0]?.title || 'សេចក្តីផ្តើម',
      parentTitle: undefined,
      content: plan.sections[0]?.content || '',
      type: 'section' as const,
    };
  };

  const activeNode = findActiveNode();

  // Content updater
  const handleUpdateContent = (newContent: string | ((prev: string) => string)) => {
    setPlan((prev) => {
      const resolveContent = (oldContent: string) => 
        typeof newContent === 'function' ? newContent(oldContent) : newContent;

      const newSections = prev.sections.map((sec) => {
        if (sec.id === activeSectionId) {
          return { ...sec, content: resolveContent(sec.content) };
        }
        if (sec.subsections) {
          const newSubs = sec.subsections.map((sub) => {
            if (sub.id === activeSectionId) {
              return { ...sub, content: resolveContent(sub.content) };
            }
            if (sub.items) {
              const newItems = sub.items.map((item) => {
                if (item.id === activeSectionId) {
                  return { ...item, content: resolveContent(item.content) };
                }
                return item;
              });
              return { ...sub, items: newItems };
            }
            return sub;
          });
          return { ...sec, subsections: newSubs };
        }
        return sec;
      });
      return { ...prev, sections: newSections };
    });
  };

  // AI Refine Specific Section
  const handleAiRefine = async (action: string, customInstruction?: string) => {
    setIsLoadingSectionAi(true);
    try {
      const data = await safeFetchJson('/api/plan/generate-section', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sectionTitle: activeNode.title,
          parentTitle: activeNode.parentTitle || plan.title,
          currentContent: activeNode.content,
          context: {
            schoolName: plan.schoolName,
            academicYear: plan.academicYear,
            location: plan.location,
            schoolType: plan.schoolType,
          },
          action,
          customInstruction,
        }),
      });

      if (data.success && data.content) {
        handleUpdateContent(data.content);
        showToast('AI បានកែសម្រួលខ្លឹមសារជោគជ័យ!');
      } else {
        alert(data.error || 'បរាជ័យក្នុងការទាញយកទិន្នន័យពី AI');
      }
    } catch (e: any) {
      console.error(e);
      alert(e?.message || 'មានបញ្ហាក្នុងការតភ្ជាប់ទៅកាន់ម៉ាស៊ីនបម្រើ AI');
    } finally {
      setIsLoadingSectionAi(false);
    }
  };

  // AI Generate Action Matrix Rows
  const handleGenerateAiRows = async () => {
    setIsLoadingSectionAi(true);
    try {
      const data = await safeFetchJson('/api/plan/generate-matrix', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          schoolName: plan.schoolName,
          priorities: plan.subtitle,
          targetGoals: plan.academicYear,
          currentMatrix: plan.actionMatrix,
        }),
      });

      if (data.success && Array.isArray(data.actionMatrix)) {
        setPlan((prev) => ({
          ...prev,
          actionMatrix: [...prev.actionMatrix, ...data.actionMatrix],
        }));
        showToast('AI បានបន្ថែមសកម្មភាពអនុវត្តថ្មីជោគជ័យ!');
      } else {
        alert(data.error || 'បរាជ័យក្នុងការបង្កើតសកម្មភាព');
      }
    } catch (e: any) {
      console.error(e);
      alert(e?.message || 'មានបញ្ហាក្នុងការបង្កើតសកម្មភាព');
    } finally {
      setIsLoadingSectionAi(false);
    }
  };

  // Generate Whole Plan
  const handleGenerateWholePlan = async (params: PlanGeneratorParams) => {
    setIsGeneratingAll(true);
    try {
      const data = await safeFetchJson('/api/plan/generate-all', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });

      if (data.success && data.plan) {
        setPlan({
          ...plan,
          id: plan.id,
          title: data.plan.title || `ផែនការប្រតិបត្តិ (AOP) ${params.schoolName}`,
          subtitle: data.plan.subtitle || `ផែនការលើកកម្ពស់គុណភាពអប់រំ និងការគ្រប់គ្រង`,
          schoolName: params.schoolName,
          academicYear: params.academicYear,
          location: params.location,
          schoolType: params.schoolType,
          preparedBy: 'គណៈកម្មការរៀបចំផែនការ និងអភិវឌ្ឍន៍សាលារៀន',
          approvedBy: 'គណៈគ្រប់គ្រងសាលារៀន',
          createdDate: new Date().toLocaleDateString('km-KH', { month: 'long', year: 'numeric' }),
          sections: data.plan.sections || DEFAULT_PLAN_DATA.sections,
          actionMatrix: data.plan.actionMatrix || DEFAULT_PLAN_DATA.actionMatrix,
          standardTargets: plan.standardTargets,
          chapterFiveActions: plan.chapterFiveActions,
        });
        setIsGeneratorOpen(false);
        showToast('បានបង្កើតផែនការប្រតិបត្តិទាំងមូលដោយជោគជ័យ!');
      } else {
        alert(data.error || 'មានបញ្ហាក្នុងការបង្កើតផែនការ');
      }
    } catch (e: any) {
      console.error(e);
      alert(e?.message || 'មានបញ្ហាក្នុងការបង្កើតផែនការដោយ AI');
    } finally {
      setIsGeneratingAll(false);
    }
  };

  // Copy Full Document for Google Docs
  const handleCopyAll = () => {
    let fullText = `${plan.title}\n${plan.subtitle}\n${plan.schoolName} - ${plan.academicYear}\n\n`;
    for (const sec of plan.sections) {
      fullText += `${sec.code}. ${sec.title}\n`;
      if (sec.content) fullText += `${sec.content}\n\n`;
      if (sec.subsections) {
        for (const sub of sec.subsections) {
          fullText += `${sub.code}. ${sub.title}\n`;
          if (sub.content) fullText += `${sub.content}\n\n`;
          if (sub.items) {
            for (const item of sub.items) {
              fullText += `• ${item.title}\n${item.content}\n\n`;
            }
          }
        }
      }
    }
    if (plan.actionMatrix && plan.actionMatrix.length > 0) {
      fullText += `\nតារាងសកម្មភាពអនុវត្ត ថវិកា និងកាលវិភាគ:\n`;
      plan.actionMatrix.forEach((act, i) => {
        fullText += `${i + 1}. ${act.activity} | សូចនាករ: ${act.indicator} | កាលវិភាគ: ${act.timeline} | ថវិកា: ${act.budget} (${act.budgetSource}) | អ្នកទទួលខុសត្រូវ: ${act.responsiblePerson}\n`;
      });
    }

    navigator.clipboard.writeText(fullText);
    setIsCopied(true);
    showToast('បានចម្លងអត្ថបទទាំងអស់! អ្នកអាច Paste ចូលក្នុង Google Docs បានភ្លាមៗ');
    setTimeout(() => setIsCopied(false), 2500);
  };

  // Download and Export Modal Handler
  const handleDownloadDoc = () => {
    setIsExportModalOpen(true);
  };

  // Synchronize Year 1 of BSP into 1-Year Operational Plan (AOP)
  const handleSyncYear1ToAop = () => {
    // 1. Update standard targets with BSP Year 1 totals
    const updatedStandards = plan.standardTargets?.map(std => {
      const bspGroup = bspPlan.standardGroups.find(g => 
        g.standardCode === std.code || 
        std.id?.includes(String(g.standardNumber)) ||
        (g.standardNumber === 4 && (std.title?.includes('អភិបាលកិច្ច') || std.title?.includes('ដំណើរការ')))
      );
      if (bspGroup) {
        const year1Budget = bspGroup.items.reduce((sum, item) => sum + (item.year1Budget || 0), 0);
        return {
          ...std,
          defaultBudget: year1Budget > 0 ? year1Budget : std.defaultBudget,
        };
      }
      return std;
    });

    // 2. Synchronize / Enrich Action Matrix with Year 1 items from BSP
    const bspYear1Activities = bspPlan.standardGroups.flatMap(group => 
      group.items.map((item, idx) => ({
        id: `am-bsp-${group.standardNumber}-${idx}-${Date.now()}`,
        activity: item.title,
        indicator: item.expectedOutcome,
        timeline: 'ប្រចាំឆមាសទី១-ទី២',
        budget: item.year1Budget.toLocaleString('km-KH') + ' ៛',
        budgetSource: item.communeShare >= 40 
          ? `ឃុំ CIP (${item.communeShare}%) + រដ្ឋ (${item.stateShare}%)` 
          : item.communityShare >= 40 
          ? `សហគមន៍ (${item.communityShare}%) + រដ្ឋ (${item.stateShare}%)`
          : `ថវិការដ្ឋ PB (${item.stateShare}%)`,
        responsiblePerson: item.responsiblePerson || 'គណៈគ្រប់គ្រងសាលា',
        status: (item.status === 'funded' ? 'completed' : item.status === 'commune_submitted' ? 'in_progress' : 'pending') as any,
        progressPercentage: item.status === 'funded' ? 100 : item.status === 'commune_submitted' ? 50 : 20,
        notes: item.communeProjectName ? `គម្រោងស្នើក្នុង CIP៖ ${item.communeProjectName}` : undefined,
      }))
    );

    const newPlan: PlanData = {
      ...plan,
      standardTargets: updatedStandards || plan.standardTargets,
      actionMatrix: bspYear1Activities.length > 0 ? bspYear1Activities : plan.actionMatrix,
      updatedAt: new Date().toISOString(),
    };

    setPlan(newPlan);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newPlan));
    showToast('បានបញ្ជូនទិន្នន័យឆ្នាំទី១ ពី BSP ទៅក្នុងផែនការប្រតិបត្តិ (AOP) រួចរាល់!');
  };

  const handlePrint = () => {
    setViewMode('preview');
    setTimeout(() => {
      window.print();
    }, 300);
  };

  const handleReset = () => {
    if (window.confirm('តើអ្នកពិតជាចង់កំណត់ទិន្នន័យឡើងវិញជាគំរូដើមមែនទេ?')) {
      setPlan(DEFAULT_PLAN_DATA);
      localStorage.removeItem(STORAGE_KEY);
      setActiveSectionId('sec-1');
      showToast('បានកំណត់ឡើងវិញជាគំរូដើម!');
    }
  };

  return (
    <div className="min-h-screen bg-slate-100/70 flex flex-col font-kantumruy w-full max-w-full overflow-x-hidden">
      {/* Top Navbar */}
      <Navbar
        onOpenGenerator={() => setIsGeneratorOpen(true)}
        onOpenExecutiveSummary={() => setIsExecutiveSummaryOpen(true)}
        onOpenPlanList={() => setIsPlanListOpen(true)}
        onOpenSchoolContext={() => setIsSchoolContextOpen(true)}
        onPrint={handlePrint}
        onCopyAll={handleCopyAll}
        onDownloadDoc={handleDownloadDoc}
        onReset={handleReset}
        onOpenWalkthrough={() => setIsWalkthroughOpen(true)}
        viewMode={viewMode}
        setViewMode={setViewMode}
        isCopied={isCopied}
        totalWords={1200}
        saveStatus={saveStatus}
        lastSavedText={formatSaveTime(lastSavedTime)}
      />

      {/* Mobile Sub-Bar for Edit Mode: Outline Drawer */}
      {viewMode === 'edit' && (
        <div className="md:hidden bg-white border-b border-slate-200 px-3 py-2 flex items-center justify-between gap-2 max-w-full">
          <button
            onClick={() => setMobileSidebarOpen(!mobileSidebarOpen)}
            className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 px-2.5 py-1.5 rounded-lg border border-slate-200 shrink-0 transition-colors"
          >
            {mobileSidebarOpen ? <X className="w-3.5 h-3.5 text-slate-700" /> : <Menu className="w-3.5 h-3.5 text-blue-600" />}
            <span className="truncate max-w-[180px]">{activeNode.title}</span>
          </button>
          <span className="text-[11px] text-slate-500">
            មាតិកាផែនការ (៦ ជំពូក)
          </span>
        </div>
      )}

      {/* Main Workspace Layout */}
      <div className="flex-1 max-w-7xl w-full mx-auto flex overflow-hidden">
        {/* Left Sidebar Outline (Desktop & Mobile Drawer) - only in edit mode */}
        {viewMode === 'edit' && (
          <div
            className={`fixed md:static inset-y-0 left-0 z-40 transform transition-transform duration-200 ease-in-out md:transform-none ${
              mobileSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
            }`}
          >
            <div className="h-full pt-16 md:pt-0">
              <SidebarOutline
                sections={plan.sections}
                activeSectionId={activeSectionId}
                onSelectSection={(id) => {
                  setActiveSectionId(id);
                  setMobileSidebarOpen(false);
                }}
              />
            </div>
          </div>
        )}

        {/* Backdrop for mobile outline */}
        {mobileSidebarOpen && viewMode === 'edit' && (
          <div
            onClick={() => setMobileSidebarOpen(false)}
            className="fixed inset-0 bg-slate-900/40 z-30 md:hidden"
          />
        )}

        {/* Content Area */}
        <main className="flex-1 overflow-y-auto p-3 sm:p-5 lg:p-7">
          {viewMode === 'edit' ? (
            <div className="max-w-4xl mx-auto space-y-6">
              {/* Quick Info Banner */}
              <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs">
                <div className="flex flex-wrap items-center gap-3 text-slate-600">
                  <span className="flex items-center gap-1.5 font-semibold text-slate-900">
                    <School className="w-4 h-4 text-blue-600" />
                    {plan.schoolName}
                  </span>
                  <span className="text-slate-300">•</span>
                  <span className="flex items-center gap-1.5 text-slate-700">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    {plan.academicYear}
                  </span>
                  <span className="text-slate-300">•</span>
                  <span className="flex items-center gap-1.5 text-slate-700">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    {plan.location}
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => setViewMode('dashboard')}
                    className="flex items-center gap-1 px-3 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-medium transition-colors"
                  >
                    <BarChart3 className="w-3.5 h-3.5 text-indigo-600" />
                    <span>ផ្ទាំងវឌ្ឍនភាព AOP</span>
                  </button>
                  <button
                    onClick={() => setIsSchoolContextOpen(true)}
                    className="flex items-center gap-1 px-3 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-medium transition-colors"
                  >
                    <Building2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>បរិបទសាលា</span>
                  </button>
                  <button
                    onClick={() => setIsGeneratorOpen(true)}
                    className="flex items-center gap-1 px-3 py-1 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 font-medium transition-colors"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                    <span>ប្ដូរព័ត៌មាន ឬបង្កើតឡើងវិញ</span>
                  </button>
                </div>
              </div>

              {/* Active Section Editor */}
              <SectionEditor
                sectionId={activeNode.id}
                sectionCode={activeNode.code}
                title={activeNode.title}
                parentTitle={activeNode.parentTitle}
                content={activeNode.content}
                onChangeContent={handleUpdateContent}
                onAiRefine={handleAiRefine}
                isLoadingAi={isLoadingSectionAi}
                actionMatrix={plan.actionMatrix}
                onChangeActionMatrix={(newMatrix) => setPlan({ ...plan, actionMatrix: newMatrix })}
                onGenerateAiRows={handleGenerateAiRows}
                standardTargets={plan.standardTargets}
                onChangeStandardTargets={(newStandards) => setPlan({ ...plan, standardTargets: newStandards })}
                onAiAutoFillStandards={() => showToast('AI បានផ្ទៀងផ្ទាត់ និងធ្វើបច្ចុប្បន្នកម្មសូចនាករស្ដង់ដារួចរាល់!')}
                chapterFiveActions={plan.chapterFiveActions}
                onChangeChapterFiveActions={(newActions) => setPlan({ ...plan, chapterFiveActions: newActions })}
              />
            </div>
          ) : viewMode === 'preview' ? (
            /* Formal Print / Document View */
            <FormalDocumentView
              plan={plan}
              onOpenExecutiveSummary={() => setIsExecutiveSummaryOpen(true)}
            />
          ) : viewMode === 'bsp' ? (
            /* 3-Year Strategic Budget Plan (BSP) Master Framework */
            <ThreeYearBspView
              bspPlan={bspPlan}
              onChangeBspPlan={setBspPlan}
              onSyncYear1ToAop={handleSyncYear1ToAop}
              onStartMeetingWalkthrough={() => setIsWalkthroughOpen(true)}
            />
          ) : viewMode === 'dashboard' ? (
            /* Action Matrix Implementation Progress Dashboard */
            <div className="max-w-5xl mx-auto space-y-6">
              <ActionMatrixDashboard
                items={plan.actionMatrix}
                onChangeItems={(newItems) => setPlan({ ...plan, actionMatrix: newItems })}
                onOpenTableEdit={() => {
                  setViewMode('edit');
                  setActiveSectionId('sec-5');
                }}
              />
            </div>
          ) : (
            /* School Assessment View (៥ ស្តង់ដារ និង ភស្តុតាង) */
            <SchoolAssessmentView
              assessmentData={assessmentData}
              onChangeAssessmentData={setAssessmentData}
              onResetAssessmentData={handleResetAssessment}
            />
          )}
        </main>
      </div>

      {/* Bottom Status Bar (របារស្ថានភាព) */}
      <footer className="no-print bg-white border-t border-slate-200/90 py-2 px-4 sm:px-6 z-20 shadow-xs">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs font-kantumruy">
          {/* Left: Auto-save status */}
          <div className="flex items-center gap-2">
            {saveStatus === 'saving' ? (
              <span className="flex items-center gap-1.5 text-amber-700 font-medium">
                <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping"></span>
                <span>កំពុងរក្សាទុកក្នុង Firestore Cloud...</span>
              </span>
            ) : saveStatus === 'saved' ? (
              <span className="flex items-center gap-1.5 text-slate-600 font-medium">
                <Cloud className="w-4 h-4 text-emerald-600" />
                <span className="text-emerald-700 font-semibold">បានរក្សាទុកក្នុង Firestore Cloud ដោយស្វ័យប្រវត្ត</span>
                <span className="text-slate-400">•</span>
                <span className="text-slate-500">ម៉ោង {formatSaveTime(lastSavedTime)}</span>
              </span>
            ) : (
              <span className="flex items-center gap-1.5 text-rose-600 font-medium">
                <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                <span>បរាជ័យក្នុងការរក្សាទុក</span>
              </span>
            )}
          </div>

          {/* Right: Document & Storage Summary */}
          <div className="flex items-center gap-3 text-slate-500 text-[11px]">
            <span className="hidden sm:inline-block">៦ ជំពូកស្តង់ដា</span>
            <span className="hidden sm:inline-block text-slate-300">•</span>
            <span className="hidden sm:inline-block">៥ ស្តង់ដារវាយតម្លៃ</span>
            <span className="hidden sm:inline-block text-slate-300">•</span>
            <span className="font-semibold text-emerald-700">ថវិកា ១៣,៩០៣,១០០ ៛</span>
            <button
              onClick={handleManualSave}
              title="ចុចដើម្បីរក្សាទុកទិន្នន័យភ្លាមៗក្នុង Firestore"
              className="ml-2 px-2.5 py-1 text-[11px] bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md font-medium transition-colors"
            >
              រក្សាទុកឥឡូវ
            </button>
          </div>
        </div>
      </footer>

      {/* Generator Modal */}
      <PlanGeneratorModal
        isOpen={isGeneratorOpen}
        onClose={() => setIsGeneratorOpen(false)}
        onGenerate={handleGenerateWholePlan}
        isGenerating={isGeneratingAll}
      />

      {/* Multi-Plan Manager Modal */}
      <PlanListModal
        isOpen={isPlanListOpen}
        onClose={() => setIsPlanListOpen(false)}
        plans={allPlans}
        currentPlanId={plan.id}
        onSelectPlan={handleSelectPlan}
        onCreateNewPlan={handleCreateNewPlan}
        onDeletePlan={handleDeletePlan}
      />

      {/* School Context Profile Modal */}
      <SchoolContextModal
        isOpen={isSchoolContextOpen}
        onClose={() => setIsSchoolContextOpen(false)}
        currentProfile={plan.schoolContextProfile}
        schoolName={plan.schoolName}
        onSaveProfile={handleSaveSchoolProfile}
      />

      {/* Export & Download Modal */}
      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        plan={plan}
        onPrint={handlePrint}
      />

      {/* AI One-Page Executive Summary Modal */}
      <ExecutiveSummaryModal
        isOpen={isExecutiveSummaryOpen}
        onClose={() => setIsExecutiveSummaryOpen(false)}
        plan={plan}
        onSaveSummary={(summary: ExecutiveSummaryData) => {
          setPlan((prev) => ({
            ...prev,
            executiveSummary: summary,
          }));
          showToast('បានរក្សាទុកសេចក្តីសង្ខេបប្រតិបត្តិ ១ ទំព័រក្នុងផែនការរួចរាល់!');
        }}
      />

      {/* Interactive Paperless Meeting Walkthrough Presentation */}
      {isWalkthroughOpen && (
        <InteractiveMeetingWalkthrough
          bspPlan={bspPlan}
          onClose={() => setIsWalkthroughOpen(false)}
          onSaveWalkthroughNotes={() => {
            showToast('បានរក្សាទុកកំណត់ត្រាកិច្ចប្រជុំជាមួយឃុំ/សហគមន៍!');
          }}
        />
      )}

      {/* Floating Toast Feedback */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-2.5 rounded-xl shadow-xl flex items-center gap-2 text-xs sm:text-sm animate-in fade-in slide-in-from-bottom-3 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
