import React, { useState } from 'react';
import { 
  ChevronRight, 
  ChevronLeft, 
  CheckCircle2, 
  Building2, 
  Award, 
  Users, 
  DollarSign, 
  Sparkles, 
  Maximize2, 
  Minimize2, 
  X, 
  Save, 
  HelpCircle, 
  MessageSquare, 
  HeartHandshake, 
  School,
  ArrowRight,
  TrendingUp,
  FileCheck,
  Table,
  Calculator,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { ThreeYearBspPlan, BspStandardGroup } from '../types/bsp';
import { 
  OFFICIAL_BSP_STANDARDS, 
  OFFICIAL_BSP_HEADER_HTML, 
  DEFAULT_BUDGET_REQUIREMENT_PLAN 
} from '../data/officialBspTableData';

interface InteractiveMeetingWalkthroughProps {
  bspPlan: ThreeYearBspPlan;
  onClose: () => void;
  onUpdateCommuneFeedback?: (askId: string, feedback: string) => void;
  onSaveWalkthroughNotes?: (notes: string) => void;
}

export const InteractiveMeetingWalkthrough: React.FC<InteractiveMeetingWalkthroughProps> = ({
  bspPlan,
  onClose,
  onUpdateCommuneFeedback,
  onSaveWalkthroughNotes,
}) => {
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [meetingNotes, setMeetingNotes] = useState<string>(() => {
    return localStorage.getItem('khmer_meeting_walkthrough_notes') || '';
  });
  const [reviewedSteps, setReviewedSteps] = useState<Record<number, boolean>>({
    0: true,
  });
  const [showNotesDrawer, setShowNotesDrawer] = useState<boolean>(false);
  const [showOfficialTableInStep, setShowOfficialTableInStep] = useState<boolean>(false);

  // Steps definition: 0 = Overview, 1-5 = 5 Standards, 6 = CIP Asks, 7 = Agreement
  const steps = [
    { id: 'overview', title: 'ទិដ្ឋភាពរួម & ចក្ខុវិស័យ', badge: 'សេចក្តីផ្តើម' },
    { id: 'std-1', title: 'ស្តង់ដាទី១៖ លទ្ធផលសិក្សា', badge: 'ស្តង់ដា ១' },
    { id: 'std-2', title: 'ស្តង់ដាទី២៖ ការបង្រៀននិងរៀន', badge: 'ស្តង់ដា ២' },
    { id: 'std-3', title: 'ស្តង់ដាទី៣៖ ការចូលរួមសហគមន៍', badge: 'ស្តង់ដា ៣' },
    { id: 'std-4', title: 'ស្តង់ដាទី៤៖ អភិបាលកិច្ចរបស់សាលារៀន', badge: 'ស្តង់ដា ៤' },
    { id: 'std-5', title: 'ស្តង់ដាទី៥៖ គណនេយ្យភាព', badge: 'ស្តង់ដា ៥' },
    { id: 'cip-asks', title: 'កញ្ចប់គម្រោងស្នើវិនិយោគឃុំ (CIP)', badge: 'គម្រោងស្នើឃុំ' },
    { id: 'agreement', title: 'ការប្ដេជ្ញាចិត្ត & កិច្ចព្រមព្រៀងរួម', badge: 'ការឯកភាព' },
  ];

  const currentStep = steps[currentStepIndex];
  const progressPercent = Math.round(((currentStepIndex + 1) / steps.length) * 100);

  const formatRiel = (amount: number) => {
    return (amount || 0).toLocaleString('km-KH') + ' ៛';
  };

  const handleNextStep = () => {
    // Mark current step as reviewed
    setReviewedSteps(prev => ({ ...prev, [currentStepIndex]: true }));
    if (currentStepIndex < steps.length - 1) {
      setCurrentStepIndex(currentStepIndex + 1);
    }
  };

  const handlePrevStep = () => {
    if (currentStepIndex > 0) {
      setCurrentStepIndex(currentStepIndex - 1);
    }
  };

  const handleSaveNotes = () => {
    localStorage.setItem('khmer_meeting_walkthrough_notes', meetingNotes);
    if (onSaveWalkthroughNotes) {
      onSaveWalkthroughNotes(meetingNotes);
    }
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
        setIsFullscreen(false);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex flex-col font-kantumruy text-slate-100 overflow-hidden animate-in fade-in duration-200">
      
      {/* Top Header Bar */}
      <header className="px-4 sm:px-6 py-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between gap-4 shrink-0 shadow-lg">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-amber-600 text-slate-950 flex items-center justify-center font-bold shadow-md shadow-amber-500/20 shrink-0">
            <HeartHandshake className="w-5 h-5" />
          </div>
          <div className="min-w-0 truncate">
            <div className="flex items-center gap-2">
              <span className="text-xs text-amber-400 font-bold tracking-wider uppercase">
                បទបង្ហាញអត់ប្រើក្រដាស (Paperless Meeting Walkthrough)
              </span>
              <span className="hidden sm:inline-block px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 text-[11px] border border-slate-700">
                {bspPlan.schoolName}
              </span>
            </div>
            <h1 className="text-sm sm:text-base font-bold text-white truncate">
              កិច្ចប្រជុំពិគ្រោះយោបល់វិនិយោគសាលារៀន ជាមួយឃុំ/សង្កាត់ & សហគមន៍
            </h1>
          </div>
        </div>

        {/* Header Right Actions */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Notes Drawer Toggle */}
          <button
            onClick={() => setShowNotesDrawer(!showNotesDrawer)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
              showNotesDrawer
                ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md shadow-amber-500/25'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">កត់ត្រាមតិឃុំ/សហគមន៍</span>
            <span className="sm:hidden">កំណត់ត្រា</span>
          </button>

          {/* Fullscreen Toggle */}
          <button
            onClick={toggleFullscreen}
            title={isFullscreen ? 'ចាកចេញពីពេញអេក្រង់' : 'ពេញអេក្រង់ (Projector Mode)'}
            className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 border border-slate-700 transition-colors"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>

          {/* Close / Exit Button */}
          <button
            onClick={onClose}
            title="បិទបទបង្ហាញ"
            className="p-2 rounded-xl bg-rose-950/80 text-rose-300 hover:text-white hover:bg-rose-900 border border-rose-800/80 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Stepper Progress Bar */}
      <div className="bg-slate-900/90 border-b border-slate-800 px-4 sm:px-6 py-2.5 shrink-0 overflow-x-auto no-scrollbar">
        <div className="flex items-center gap-2 min-w-max">
          {steps.map((st, idx) => {
            const isCurrent = idx === currentStepIndex;
            const isReviewed = !!reviewedSteps[idx];

            return (
              <button
                key={st.id}
                onClick={() => setCurrentStepIndex(idx)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  isCurrent
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-500/30 ring-2 ring-blue-400/50 scale-105'
                    : isReviewed
                    ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/60 hover:bg-emerald-900/50'
                    : 'bg-slate-800/70 text-slate-400 border border-slate-700/60 hover:bg-slate-800'
                }`}
              >
                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                  isCurrent
                    ? 'bg-white text-blue-700'
                    : isReviewed
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-700 text-slate-300'
                }`}>
                  {isReviewed && !isCurrent ? '✓' : idx + 1}
                </span>
                <span>{st.badge}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Slide / Card Stage */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-8 flex items-center justify-center">
          <div className="w-full max-w-4xl bg-slate-900/80 border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden backdrop-blur-sm">
            
            {/* Step 0: Overview & Vision */}
            {currentStepIndex === 0 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-200">
                <div className="text-center space-y-3 border-b border-slate-800 pb-6">
                  <span className="px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 border border-blue-400/30 text-xs font-bold uppercase tracking-wider">
                    ជំហានទី ១ / ៨ • ចក្ខុវិស័យរួម
                  </span>
                  <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
                    ទិសដៅអភិវឌ្ឍន៍សាលារៀន ៣ ឆ្នាំ ({bspPlan.academicYearsLabel})
                  </h2>
                  <p className="text-sm text-slate-300 max-w-2xl mx-auto leading-relaxed">
                    ផ្អែកលើការវាយតម្លៃស្ថានភាពជាក់ស្តែង និងការកៀរគរការចូលរួម ដើម្បីប្រែក្លាយសាលារៀនឱ្យក្លាយជា «សាលារៀនគំរូ»
                  </p>
                </div>

                {/* Vision Box */}
                <div className="p-5 rounded-2xl bg-gradient-to-br from-blue-950/80 to-indigo-950/80 border border-blue-800/60 shadow-inner space-y-2">
                  <div className="text-xs font-bold text-blue-300 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <span>ចក្ខុវិស័យរបស់សាលារៀន</span>
                  </div>
                  <p className="text-base sm:text-lg text-white font-medium italic leading-relaxed">
                    «{bspPlan.visionStatement}»
                  </p>
                </div>

                {/* Core Philosophy for Paperless Walkthrough */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                  <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-1.5">
                    <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-xs">
                      ១
                    </div>
                    <h4 className="font-bold text-white text-sm">មិនប្រើក្រដាសស្មុគស្មាញ</h4>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      បង្ហាញម្តងមួយចំណុចច្បាស់លាស់ មិនឱ្យសមាជិកអង្គប្រជុំធុញទ្រាន់ ឬស្ទាក់ស្ទើរ។
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-1.5">
                    <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs">
                      ២
                    </div>
                    <h4 className="font-bold text-white text-sm">អត្ថប្រយោជន៍ដល់កូនចៅ</h4>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      រាល់សកម្មភាពត្រូវឆ្លើយតបដោយផ្ទាល់ ថាតើសិស្សានុសិស្សក្នុងភូមិ/ឃុំ ទទួលបានអ្វីខ្លះ។
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-1.5">
                    <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xs">
                      ៣
                    </div>
                    <h4 className="font-bold text-white text-sm">សំណើសុំសមស្រប</h4>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      ស្នើសុំការជួយពីឃុំ (CIP) និងសហគមន៍ក្នុងទំហំសមរម្យ និងមានតម្លាភាពខ្ពស់។
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Steps 1 to 5: The 5 MoEYS Standards */}
            {currentStepIndex >= 1 && currentStepIndex <= 5 && (() => {
              const stdGroup = bspPlan.standardGroups[currentStepIndex - 1];
              if (!stdGroup) return null;

              const year1Total = stdGroup.items.reduce((s, i) => s + (i.year1Budget || 0), 0);
              const total3Y = stdGroup.items.reduce((s, i) => s + (i.year1Budget + i.year2Budget + i.year3Budget || 0), 0);
              const communeAsksInStd = bspPlan.communeAsks.filter(a => a.standardCode === stdGroup.standardCode);

              return (
                <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-200">
                  {/* Standard Header */}
                  <div className="flex items-start justify-between gap-4 border-b border-slate-800 pb-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-0.5 rounded-full bg-blue-600 text-white text-xs font-bold">
                          {stdGroup.standardCode}
                        </span>
                        <span className="text-xs text-slate-400">
                          ជំហានទី {currentStepIndex + 1} / ៨
                        </span>
                      </div>
                      <h2 className="text-xl sm:text-2xl font-bold text-white mt-1">
                        {stdGroup.standardTitle}
                      </h2>
                      <p className="text-xs sm:text-sm text-blue-200/90 mt-1">
                        គោលបំណងអាទិភាព៖ {stdGroup.priorityObjective}
                      </p>
                    </div>

                    <div className="text-right shrink-0 bg-slate-800/80 px-3 py-2 rounded-xl border border-slate-700">
                      <div className="text-[11px] text-slate-400">ថវិកា ៣ ឆ្នាំសរុប</div>
                      <div className="text-sm font-bold text-amber-400">{formatRiel(total3Y)}</div>
                      <div className="text-[10px] text-slate-400">ឆ្នាំទី១ (AOP)៖ {formatRiel(year1Total)}</div>
                    </div>
                  </div>

                  {/* 3 Core Impact Cards */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Card 1: What students receive */}
                    <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-800/60 space-y-2">
                      <div className="flex items-center gap-2 text-emerald-300 font-bold text-xs">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span>អ្វីដែលសិស្សានុសិស្ស (កូនចៅសហគមន៍) នឹងទទួលបាន</span>
                      </div>
                      <ul className="text-xs text-slate-200 space-y-2 leading-relaxed">
                        {stdGroup.items.map((item) => (
                          <li key={item.id} className="flex items-start gap-2">
                            <span className="text-emerald-400 font-bold mt-0.5">•</span>
                            <div>
                              <strong className="text-white">{item.title}៖</strong> {item.expectedOutcome}
                            </div>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Card 2: What Commune and Community contribute */}
                    <div className="p-4 rounded-2xl bg-amber-950/40 border border-amber-800/60 space-y-2">
                      <div className="flex items-center gap-2 text-amber-300 font-bold text-xs">
                        <Building2 className="w-4 h-4 text-amber-400" />
                        <span>សំណើសុំការគាំទ្រពីឃុំ (CIP) & សហគមន៍</span>
                      </div>
                      <div className="text-xs text-slate-200 space-y-2 leading-relaxed">
                        {stdGroup.items.map((item) => (
                          <div key={item.id} className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800">
                            <div className="font-semibold text-white">{item.title}</div>
                            {item.communeProjectName && (
                              <div className="text-emerald-300 text-[11px] mt-1 flex items-center gap-1">
                                <span>🏛️ គម្រោងស្នើក្នុង CIP៖</span>
                                <span>{item.communeProjectName}</span>
                              </div>
                            )}
                            <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-400">
                              <span>ឃុំជួយ៖ <strong className="text-amber-300">{item.communeShare}%</strong></span>
                              <span>•</span>
                              <span>សហគមន៍៖ <strong className="text-amber-300">{item.communityShare}%</strong></span>
                              <span>•</span>
                              <span>រដ្ឋ៖ {item.stateShare}%</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Commune Specific Projects under this Standard */}
                  {communeAsksInStd.length > 0 && (
                    <div className="p-4 rounded-2xl bg-slate-800/70 border border-slate-700/80 space-y-2.5">
                      <div className="text-xs font-bold text-white flex items-center justify-between">
                        <span>គម្រោងអាទិភាពស្នើសុំដាក់ក្នុង CIP ឃុំ ក្រោមស្តង់ដានេះ៖</span>
                        <span className="text-amber-400">{communeAsksInStd.length} គម្រោង</span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                        {communeAsksInStd.map(ask => (
                          <div key={ask.id} className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex justify-between items-start gap-2">
                            <div>
                              <div className="font-bold text-white">{ask.title}</div>
                              <div className="text-[11px] text-slate-400 mt-0.5">អ្នកទទួលផល៖ {ask.targetBeneficiaries}</div>
                              <div className="text-[11px] text-emerald-400 font-bold mt-1">
                                ស្នើឃុំជួយ៖ {formatRiel(ask.communeContribution)}
                              </div>
                            </div>
                            <span className="px-2 py-0.5 bg-blue-900/60 text-blue-200 text-[10px] rounded-md shrink-0">
                              {ask.requestedYear}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Expandable Official MoEYS Indicators Table */}
                  <div className="pt-2">
                    <button
                      onClick={() => setShowOfficialTableInStep(!showOfficialTableInStep)}
                      className="flex items-center gap-2 text-xs font-semibold text-blue-400 hover:text-blue-300 py-1.5 px-3 rounded-xl bg-blue-950/40 border border-blue-900/60 transition-colors"
                    >
                      <Table className="w-3.5 h-3.5" />
                      <span>
                        {showOfficialTableInStep ? 'បិទតារាងសូចនាករផ្លូវការ' : 'ពិនិត្យតារាងសូចនាករផ្លូវការក្រសួងអប់រំ (Official Indicators)'}
                      </span>
                      {showOfficialTableInStep ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    </button>

                    {showOfficialTableInStep && OFFICIAL_BSP_STANDARDS[currentStepIndex - 1] && (
                      <div className="mt-3 p-3 bg-white rounded-2xl overflow-x-auto text-slate-800 text-xs shadow-lg animate-in fade-in duration-150">
                        <table className="w-full border-collapse bsp-official-table">
                          <thead dangerouslySetInnerHTML={{ __html: OFFICIAL_BSP_HEADER_HTML }} />
                          <tbody
                            dangerouslySetInnerHTML={{
                              __html: OFFICIAL_BSP_STANDARDS[currentStepIndex - 1].headerTrHtml + '\n' + OFFICIAL_BSP_STANDARDS[currentStepIndex - 1].rowsHtml,
                            }}
                          />
                        </table>
                      </div>
                    )}
                  </div>
                </div>
              );
            })()}

            {/* Step 6: Full CIP Asks Package & Budget Requirement Summary */}
            {currentStepIndex === 6 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-200">
                <div className="border-b border-slate-800 pb-4">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-600 text-white text-xs font-bold">
                      កញ្ចប់វិនិយោគឃុំ (CIP) & តម្រូវការថវិកា
                    </span>
                    <span className="text-xs text-slate-400">ជំហានទី ៧ / ៨</span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-bold text-white mt-1">
                    កញ្ចប់គម្រោងស្នើសុំវិនិយោគឃុំ-សង្កាត់ & តម្រូវការថវិកា ៣ ឆ្នាំ
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-300 mt-1">
                    បង្ហាញថវិការដ្ឋបានពីសិស្ស (~១៦,០០០៛/នាក់) ផលខ្វះខាតជាក់ស្តែង និងគម្រោងស្នើសុំឃុំជួយ
                  </p>
                </div>

                {/* Priority CIP Projects */}
                <div className="space-y-3">
                  <div className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                    <Building2 className="w-4 h-4" />
                    <span>គម្រោងអាទិភាពស្នើសុំដាក់បញ្ចូលក្នុង CIP ឃុំ៖</span>
                  </div>
                  {bspPlan.communeAsks.map((ask, index) => (
                    <div 
                      key={ask.id} 
                      className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-bold">
                            {index + 1}
                          </span>
                          <span className="text-xs font-semibold text-blue-300">{ask.standardCode}</span>
                          <span className="text-xs text-slate-400">• {ask.requestedYear}</span>
                        </div>
                        <h4 className="text-sm font-bold text-white">{ask.title}</h4>
                        <div className="text-xs text-slate-400">អ្នកទទួលផល៖ {ask.targetBeneficiaries}</div>
                      </div>

                      <div className="text-right sm:border-l sm:border-slate-700 sm:pl-4 shrink-0">
                        <div className="text-xs text-slate-400">ស្នើថវិកាឃុំ (CIP)</div>
                        <div className="text-base font-bold text-amber-400">{formatRiel(ask.communeContribution)}</div>
                        <div className="text-[11px] text-slate-500">
                          តម្លៃសរុប៖ {formatRiel(ask.estimatedCost)}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Budget Requirement & Gap Financial Breakdown */}
                {bspPlan.budgetRequirement && (
                  <div className="p-4 rounded-2xl bg-slate-800/90 border border-slate-700 space-y-3 text-xs">
                    <div className="font-bold text-white flex items-center justify-between">
                      <span className="flex items-center gap-1.5">
                        <Calculator className="w-4 h-4 text-indigo-400" />
                        <span>សេចក្តីសង្ខេបតម្រូវការថវិកា & គម្លាតវិនិយោគ</span>
                      </span>
                      <span className="text-slate-400">
                        សិស្ស {bspPlan.budgetRequirement.studentCount} នាក់
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                      <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                        <span className="text-slate-400 text-[11px]">១. ថវិការដ្ឋបានពីសិស្ស (PB)</span>
                        <div className="text-sm font-bold text-emerald-400">
                          {formatRiel(bspPlan.budgetRequirement.studentCount * bspPlan.budgetRequirement.perStudentRateRiel)}
                        </div>
                        <div className="text-[10px] text-slate-500">~១៦,៤០០៛ / សិស្សម្នាក់</div>
                      </div>

                      <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                        <span className="text-slate-400 text-[11px]">២. ផលខ្វះខាតដែលសាលាត្រូវការ</span>
                        <div className="text-sm font-bold text-rose-400">
                          {formatRiel(Math.max(0, 13903100 - (bspPlan.budgetRequirement.studentCount * bspPlan.budgetRequirement.perStudentRateRiel)))}
                        </div>
                        <div className="text-[10px] text-slate-500">សម្រាប់ដំណើរការពេញមួយឆ្នាំ</div>
                      </div>

                      <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                        <span className="text-slate-400 text-[11px]">៣. ស្នើឃុំ (CIP) & សហគមន៍</span>
                        <div className="text-sm font-bold text-amber-400">
                          {formatRiel(bspPlan.budgetRequirement.communeCipAskTotal + bspPlan.budgetRequirement.communityContributionTotal)}
                        </div>
                        <div className="text-[10px] text-slate-500">ឃុំ៖ {formatRiel(bspPlan.budgetRequirement.communeCipAskTotal)}</div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Step 7: Final Commitment & Mutual Agreement */}
            {currentStepIndex === 7 && (
              <div className="space-y-6 text-center animate-in fade-in slide-in-from-bottom-2 duration-200">
                <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/30">
                  <HeartHandshake className="w-8 h-8" />
                </div>

                <div className="space-y-2">
                  <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-xs font-bold">
                    ជំហានបញ្ចប់ • ការប្ដេជ្ញាចិត្តរួម
                  </span>
                  <h2 className="text-2xl sm:text-3xl font-bold text-white">
                    ការឯកភាពរួមរវាងសាលារៀន ក្រុមប្រឹក្សាឃុំ និងសហគមន៍
                  </h2>
                  <p className="text-sm text-slate-300 max-w-xl mx-auto leading-relaxed">
                    ការអប់រំជាកាតព្វកិច្ចរួមរបស់អ្នកទាំងអស់គ្នា។ ការគាំទ្ររបស់ក្រុមប្រឹក្សាឃុំ និងសហគមន៍ គឺជាគ្រឹះដ៏រឹងមាំសម្រាប់អនាគតកូនចៅយើង។
                  </p>
                </div>

                {/* Sign-off Summary */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-left pt-4">
                  <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/80">
                    <div className="text-xs font-bold text-blue-300">តំណាងសាលារៀន</div>
                    <div className="text-sm font-bold text-white mt-1">គណៈគ្រប់គ្រង & លោកគ្រូ-អ្នកគ្រូ</div>
                    <div className="text-xs text-slate-400 mt-2">ប្ដេជ្ញា៖ បង្រៀនឱ្យអស់ពីកម្លាំងកាយចិត្ត និងគ្រប់គ្រងប្រកបដោយតម្លាភាព</div>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/80">
                    <div className="text-xs font-bold text-emerald-300">តំណាងអាជ្ញាធរមូលដ្ឋាន</div>
                    <div className="text-sm font-bold text-white mt-1">ក្រុមប្រឹក្សាឃុំ / គ.ក.ន.ក</div>
                    <div className="text-xs text-slate-400 mt-2">ប្ដេជ្ញា៖ គាំទ្របញ្ជ្រាបក្នុង CIP និងជួយការពារសុវត្ថិភាពសិស្ស</div>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/80">
                    <div className="text-xs font-bold text-amber-300">តំណាងសហគមន៍</div>
                    <div className="text-sm font-bold text-white mt-1">គ.គ.ស & មាតាបិតាសិស្ស</div>
                    <div className="text-xs text-slate-400 mt-2">ប្ដេជ្ញា៖ ជំរុញកូនៗមករៀនទៀងទាត់ និងចូលរួមថែរក្សាសាលារៀន</div>
                  </div>
                </div>

                <div className="pt-4">
                  <button
                    onClick={onClose}
                    className="px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-sm shadow-xl shadow-emerald-600/30 transition-all hover:scale-105 active:scale-95"
                  >
                    បញ្ចប់បទបង្ហាញ និងរក្សាទុកកំណត់ត្រា
                  </button>
                </div>
              </div>
            )}

            {/* Step Navigation Controls (The core buttons requested by user!) */}
            <div className="mt-8 pt-6 border-t border-slate-800 flex items-center justify-between gap-4">
              <button
                onClick={handlePrevStep}
                disabled={currentStepIndex === 0}
                className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
                  currentStepIndex === 0
                    ? 'opacity-40 cursor-not-allowed bg-slate-800 text-slate-500'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                }`}
              >
                <ChevronLeft className="w-4 h-4" />
                <span>ចំណុចមុន</span>
              </button>

              <div className="text-xs text-slate-400 font-medium hidden sm:block">
                ចំណុចទី {currentStepIndex + 1} នៃ {steps.length} ({progressPercent}%)
              </div>

              {currentStepIndex < steps.length - 1 ? (
                <button
                  onClick={handleNextStep}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs sm:text-sm font-bold shadow-lg shadow-blue-500/25 transition-all hover:scale-[1.02] active:scale-[0.98]"
                >
                  <span>បានពិនិត្យចប់ & បន្តទៅចំណុចបន្ទាប់</span>
                  <ArrowRight className="w-4 h-4 text-blue-200" />
                </button>
              ) : (
                <button
                  onClick={onClose}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs sm:text-sm font-bold shadow-lg shadow-emerald-500/25 transition-all"
                >
                  <FileCheck className="w-4 h-4" />
                  <span>បិទបទបង្ហាញ</span>
                </button>
              )}
            </div>

          </div>
        </div>

        {/* Live Meeting Notes Drawer */}
        {showNotesDrawer && (
          <div className="w-80 sm:w-96 bg-slate-900 border-l border-slate-800 p-5 flex flex-col shrink-0 space-y-4 animate-in slide-in-from-right duration-200">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-white font-bold text-xs sm:text-sm">
                <MessageSquare className="w-4 h-4 text-amber-400" />
                <span>កត់ត្រាមតិ និងការឯកភាព</span>
              </div>
              <button
                onClick={() => setShowNotesDrawer(false)}
                className="p-1 rounded-lg hover:bg-slate-800 text-slate-400"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 flex flex-col space-y-2">
              <label className="text-[11px] text-slate-400">
                កត់ត្រាមតិយោបល់របស់លោកមេឃុំ ជំទប់ មេភូមិ ឬតំណាងមាតាបិតា៖
              </label>
              <textarea
                value={meetingNotes}
                onChange={(e) => setMeetingNotes(e.target.value)}
                placeholder="ឧ. លោកមេឃុំបានឯកភាពគាំទ្រគម្រោងសាងសង់របងសាលា ៥,០០០,០០០ រៀល ក្នុងឆ្នាំ២០២៥..."
                className="w-full flex-1 p-3 bg-slate-950/70 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none resize-none leading-relaxed"
              />
            </div>

            <div className="pt-2 border-t border-slate-800 flex justify-between items-center">
              <span className="text-[10px] text-slate-500">រក្សាទុកក្នុងម៉ាស៊ីន</span>
              <button
                onClick={handleSaveNotes}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-xs transition-colors"
              >
                <Save className="w-3.5 h-3.5" />
                <span>រក្សាទុកកំណត់ត្រា</span>
              </button>
            </div>
          </div>
        )}

      </div>

    </div>
  );
};
