import React, { useState } from 'react';
import { 
  ChevronRight, 
  ChevronDown, 
  FileText, 
  Plus, 
  Search, 
  FolderTree, 
  Layers, 
  MoreVertical,
  CheckCircle2,
  Clock
} from 'lucide-react';
import { PlanSection } from '../types/plan';

interface SidebarOutlineProps {
  sections: PlanSection[];
  activeSectionId: string;
  onSelectSection: (id: string) => void;
  onAddSection?: () => void;
}

export const SidebarOutline: React.FC<SidebarOutlineProps> = ({
  sections,
  activeSectionId,
  onSelectSection,
  onAddSection,
}) => {
  const [collapsedMap, setCollapsedMap] = useState<Record<string, boolean>>({});
  const [searchQuery, setSearchQuery] = useState('');

  const toggleCollapse = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setCollapsedMap(prev => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  return (
    <aside className="w-full lg:w-72 bg-white lg:border-r border-slate-200 flex flex-col h-full select-none">
      {/* Header matching Google Docs "ផ្ទាំងឯកសារ" */}
      <div className="p-3.5 border-b border-slate-200/80 flex items-center justify-between bg-slate-50/50">
        <div className="flex items-center gap-2 text-slate-800 font-semibold text-sm font-kantumruy">
          <FolderTree className="w-4 h-4 text-blue-600" />
          <span>ផ្ទាំងឯកសារ</span>
        </div>
        <div className="flex items-center gap-1">
          {onAddSection && (
            <button
              onClick={onAddSection}
              title="បន្ថែមជំពូកថ្មី"
              className="p-1 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-md transition-colors"
            >
              <Plus className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Search Filter */}
      <div className="p-2 border-b border-slate-100">
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="ស្វែងរកជំពូក..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 hover:bg-slate-100/80 focus:bg-white border border-slate-200 rounded-lg outline-none focus:border-blue-500 transition-colors font-kantumruy"
          />
        </div>
      </div>

      {/* Outline List */}
      <div className="flex-1 overflow-y-auto p-2 space-y-1">
        {sections.map((sec) => {
          const isSecActive = activeSectionId === sec.id;
          const hasSubs = sec.subsections && sec.subsections.length > 0;
          const isSecCollapsed = !!collapsedMap[sec.id];

          // Filter logic
          if (
            searchQuery &&
            !sec.title.toLowerCase().includes(searchQuery.toLowerCase()) &&
            !sec.code.includes(searchQuery) &&
            !sec.subsections?.some(s => 
              s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
              s.items?.some(i => i.title.toLowerCase().includes(searchQuery.toLowerCase()))
            )
          ) {
            return null;
          }

          return (
            <div key={sec.id} className="space-y-0.5">
              {/* Main Chapter Item */}
              <div
                onClick={() => onSelectSection(sec.id)}
                className={`group flex items-center justify-between px-2.5 py-2 rounded-xl text-xs sm:text-sm cursor-pointer transition-all ${
                  isSecActive
                    ? 'bg-blue-50 text-blue-900 font-semibold shadow-xs border border-blue-200/60'
                    : 'text-slate-700 hover:bg-slate-100/70 hover:text-slate-900'
                }`}
              >
                <div className="flex items-center gap-2 min-w-0 flex-1">
                  {hasSubs ? (
                    <button
                      onClick={(e) => toggleCollapse(sec.id, e)}
                      className="p-0.5 text-slate-400 hover:text-slate-600 rounded-sm"
                    >
                      {isSecCollapsed ? (
                        <ChevronRight className="w-3.5 h-3.5" />
                      ) : (
                        <ChevronDown className="w-3.5 h-3.5" />
                      )}
                    </button>
                  ) : (
                    <FileText className={`w-3.5 h-3.5 shrink-0 ${isSecActive ? 'text-blue-600' : 'text-slate-400'}`} />
                  )}

                  <span className="truncate font-kantumruy">
                    {sec.code}. {sec.title}
                  </span>
                </div>

                <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                  <MoreVertical className="w-3.5 h-3.5 text-slate-400" />
                </div>
              </div>

              {/* Subsections if expanded */}
              {hasSubs && !isSecCollapsed && (
                <div className="pl-4 ml-2 border-l border-slate-200/70 space-y-0.5 mt-0.5">
                  {sec.subsections!.map((sub) => {
                    const isSubActive = activeSectionId === sub.id;
                    const hasItems = sub.items && sub.items.length > 0;
                    const isSubCollapsed = !!collapsedMap[sub.id];

                    return (
                      <div key={sub.id} className="space-y-0.5">
                        <div
                          onClick={() => onSelectSection(sub.id)}
                          className={`group flex items-center justify-between px-2 py-1.5 rounded-lg text-xs cursor-pointer transition-all ${
                            isSubActive
                              ? 'bg-blue-100/70 text-blue-900 font-medium'
                              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                          }`}
                        >
                          <div className="flex items-center gap-1.5 min-w-0 flex-1">
                            {hasItems ? (
                              <button
                                onClick={(e) => toggleCollapse(sub.id, e)}
                                className="p-0.5 text-slate-400 hover:text-slate-600 rounded-sm"
                              >
                                {isSubCollapsed ? (
                                  <ChevronRight className="w-3 h-3" />
                                ) : (
                                  <ChevronDown className="w-3 h-3" />
                                )}
                              </button>
                            ) : (
                              <FileText className="w-3 h-3 text-slate-400 shrink-0" />
                            )}
                            <span className="truncate font-kantumruy">{sub.title}</span>
                          </div>
                        </div>

                        {/* Subsection Items */}
                        {hasItems && !isSubCollapsed && (
                          <div className="pl-4 ml-1.5 border-l border-slate-200/60 space-y-0.5">
                            {sub.items!.map((item) => {
                              const isItemActive = activeSectionId === item.id;
                              return (
                                <div
                                  key={item.id}
                                  onClick={() => onSelectSection(item.id)}
                                  className={`flex items-center gap-1.5 px-2 py-1 rounded-md text-[11px] cursor-pointer transition-all ${
                                    isItemActive
                                      ? 'bg-blue-100 text-blue-900 font-semibold'
                                      : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'
                                  }`}
                                >
                                  <FileText className="w-2.5 h-2.5 text-slate-400 shrink-0" />
                                  <span className="truncate font-kantumruy">{item.title}</span>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Footer Info */}
      <div className="p-3 bg-slate-50 border-t border-slate-200 text-center">
        <p className="text-[11px] text-slate-500">
          ចុចលើចំណុចណាមួយដើម្បីកែសម្រួល ឬប្រើ AI សរសេរបំពេញ
        </p>
      </div>
    </aside>
  );
};
