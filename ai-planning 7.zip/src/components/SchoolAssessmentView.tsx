import React, { useState, useMemo } from 'react';
import { 
  Building2, 
  Award, 
  CheckCircle2, 
  Sparkles, 
  Plus, 
  Paperclip, 
  ExternalLink, 
  FileText, 
  Search, 
  Printer, 
  Download, 
  RotateCcw, 
  ChevronDown, 
  ChevronUp, 
  Info,
  Calendar,
  Phone,
  UserCheck,
  Star,
  Check,
  Eye,
  EyeOff,
  ArrowRight,
  Trash2,
  Image as ImageIcon
} from 'lucide-react';
import { 
  SchoolAssessmentData, 
  AssessmentIndicator, 
  EvidenceItem, 
  EvidenceType 
} from '../types/assessment';
import { EvidenceUploadModal } from './EvidenceUploadModal';
import { FileViewerModal } from './FileViewerModal';
import { safeFetchJson } from '../utils/apiHelper';

interface SchoolAssessmentViewProps {
  assessmentData: SchoolAssessmentData;
  onChangeAssessmentData: (newData: SchoolAssessmentData) => void;
  onResetAssessmentData: () => void;
}

export const SchoolAssessmentView: React.FC<SchoolAssessmentViewProps> = ({
  assessmentData,
  onChangeAssessmentData,
  onResetAssessmentData,
}) => {
  const [selectedStandardTab, setSelectedStandardTab] = useState<number | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isGeneralInfoCollapsed, setIsGeneralInfoCollapsed] = useState<boolean>(false);
  const [isResultsCollapsed, setIsResultsCollapsed] = useState<boolean>(false); // Section III (ភ្នែកចុងក្រោយ) collapsible
  const [collapsedStandards, setCollapsedStandards] = useState<Record<string, boolean>>({}); // Standards in table collapsible
  const [isAiAnalyzing, setIsAiAnalyzing] = useState<boolean>(false);

  // Toggle single standard collapse in Section II table
  const toggleStandard = (standardId: string) => {
    setCollapsedStandards(prev => ({
      ...prev,
      [standardId]: !prev[standardId]
    }));
  };

  // Select standard in Accordion Stepper mode:
  // When user clicks a standard row, it opens it, collapses others, and scrolls it up!
  const handleSelectStandardAccordion = (standardId: string) => {
    const isCurrentlyOpen = !collapsedStandards[standardId];
    if (isCurrentlyOpen) {
      // If clicking on already open standard, collapse it
      setCollapsedStandards(prev => ({ ...prev, [standardId]: true }));
      return;
    }
    // Otherwise collapse all others and open target standard
    const newCollapsed: Record<string, boolean> = {};
    assessmentData.standards.forEach(s => {
      if (s.id !== standardId) {
        newCollapsed[s.id] = true;
      }
    });
    setCollapsedStandards(newCollapsed);

    // Smoothly scroll to the target standard
    setTimeout(() => {
      const el = document.getElementById(`assessment-std-anchor-${standardId}`);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 120);
  };

  // Collapse all standards in table
  const collapseAllStandards = () => {
    const allCollapsed: Record<string, boolean> = {};
    assessmentData.standards.forEach(s => {
      allCollapsed[s.id] = true;
    });
    setCollapsedStandards(allCollapsed);
  };

  // Expand all standards in table
  const expandAllStandards = () => {
    setCollapsedStandards({});
  };

  // Modal State for Evidence Upload
  const [uploadModalState, setUploadModalState] = useState<{
    isOpen: boolean;
    indicatorId: string;
    indicatorCode: string;
    indicatorTitle: string;
    editingEvidence: EvidenceItem | null;
  }>({
    isOpen: false,
    indicatorId: '',
    indicatorCode: '',
    indicatorTitle: '',
    editingEvidence: null,
  });

  // Modal State for File Viewer
  const [viewerModalState, setViewerModalState] = useState<{
    isOpen: boolean;
    evidence: EvidenceItem | null;
    indicatorId: string;
    indicatorCode: string;
    indicatorTitle: string;
  }>({
    isOpen: false,
    evidence: null,
    indicatorId: '',
    indicatorCode: '',
    indicatorTitle: '',
  });

  // Compute Statistics
  const stats = useMemo(() => {
    let totalIndicators = 0;
    let scoredIndicators = 0;
    let totalScore = 0;
    let totalEvidences = 0;

    assessmentData.standards.forEach((std) => {
      std.categories.forEach((cat) => {
        cat.indicators.forEach((ind) => {
          totalIndicators++;
          if (ind.score && ind.score > 0) {
            scoredIndicators++;
            totalScore += ind.score;
          }
          if (ind.evidences) {
            totalEvidences += ind.evidences.length;
          }
        });
      });
    });

    const averageScore = scoredIndicators > 0 ? (totalScore / scoredIndicators).toFixed(2) : '0.00';
    const percentDone = totalIndicators > 0 ? Math.round((scoredIndicators / totalIndicators) * 100) : 0;

    let gradeLevel = 'មិនទាន់វាយតម្លៃ';
    let gradeColor = 'text-slate-500 bg-slate-100 border-slate-200';
    const avgNum = parseFloat(averageScore);

    if (scoredIndicators > 0) {
      if (avgNum >= 4.5) {
        gradeLevel = 'កម្រិតល្អប្រសើរ (កម្រិត ៥)';
        gradeColor = 'text-emerald-800 bg-emerald-50 border-emerald-300';
      } else if (avgNum >= 3.5) {
        gradeLevel = 'កម្រិតល្អ (កម្រិត ៤)';
        gradeColor = 'text-blue-800 bg-blue-50 border-blue-300';
      } else if (avgNum >= 2.5) {
        gradeLevel = 'កម្រិតមធ្យម (កម្រិត ៣)';
        gradeColor = 'text-amber-800 bg-amber-50 border-amber-300';
      } else if (avgNum >= 1.5) {
        gradeLevel = 'កម្រិតមធ្យមទាប (កម្រិត ២)';
        gradeColor = 'text-orange-800 bg-orange-50 border-orange-300';
      } else {
        gradeLevel = 'កម្រិតត្រូវកែលម្អបន្ទាន់ (កម្រិត ១)';
        gradeColor = 'text-rose-800 bg-rose-50 border-rose-300';
      }
    }

    return {
      totalIndicators,
      scoredIndicators,
      averageScore,
      percentDone,
      totalEvidences,
      gradeLevel,
      gradeColor,
    };
  }, [assessmentData]);

  // Handle Score Selection (1 - 5)
  const handleScoreChange = (indicatorId: string, newScore: number) => {
    const updatedStandards = assessmentData.standards.map((std) => ({
      ...std,
      categories: std.categories.map((cat) => ({
        ...cat,
        indicators: cat.indicators.map((ind) => {
          if (ind.id === indicatorId) {
            // Toggle score if clicking same score
            const score = ind.score === newScore ? undefined : newScore;
            return { ...ind, score };
          }
          return ind;
        }),
      })),
    }));

    onChangeAssessmentData({
      ...assessmentData,
      standards: updatedStandards,
      lastUpdated: new Date().toISOString(),
    });
  };

  // Open Evidence Upload Modal
  const openUploadModal = (indicator: AssessmentIndicator, editingEvidence: EvidenceItem | null = null) => {
    setUploadModalState({
      isOpen: true,
      indicatorId: indicator.id,
      indicatorCode: indicator.code,
      indicatorTitle: indicator.title,
      editingEvidence,
    });
  };

  // Open Evidence File Viewer
  const openViewerModal = (indicator: AssessmentIndicator, evidence: EvidenceItem) => {
    setViewerModalState({
      isOpen: true,
      evidence,
      indicatorId: indicator.id,
      indicatorCode: indicator.code,
      indicatorTitle: indicator.title,
    });
  };

  // Save Evidence Item (Add or Update)
  const handleSaveEvidence = (item: EvidenceItem) => {
    const { indicatorId } = uploadModalState;
    const updatedStandards = assessmentData.standards.map((std) => ({
      ...std,
      categories: std.categories.map((cat) => ({
        ...cat,
        indicators: cat.indicators.map((ind) => {
          if (ind.id === indicatorId) {
            const existing = ind.evidences || [];
            const index = existing.findIndex((e) => e.id === item.id);
            let newEvidences: EvidenceItem[];
            if (index >= 0) {
              newEvidences = [...existing];
              newEvidences[index] = item;
            } else {
              newEvidences = [...existing, item];
            }
            return { ...ind, evidences: newEvidences };
          }
          return ind;
        }),
      })),
    }));

    onChangeAssessmentData({
      ...assessmentData,
      standards: updatedStandards,
      lastUpdated: new Date().toISOString(),
    });
  };

  // Delete Evidence Item
  const handleDeleteEvidence = (evidenceId: string) => {
    const { indicatorId } = viewerModalState;
    const updatedStandards = assessmentData.standards.map((std) => ({
      ...std,
      categories: std.categories.map((cat) => ({
        ...cat,
        indicators: cat.indicators.map((ind) => {
          if (ind.id === indicatorId) {
            const newEvidences = (ind.evidences || []).filter((e) => e.id !== evidenceId);
            return { ...ind, evidences: newEvidences };
          }
          return ind;
        }),
      })),
    }));

    onChangeAssessmentData({
      ...assessmentData,
      standards: updatedStandards,
      lastUpdated: new Date().toISOString(),
    });
  };

  // AI Analysis for Section III (Strengths, Weaknesses, Recommendations)
  const handleAiAnalyzeResults = async () => {
    setIsAiAnalyzing(true);
    try {
      // Gather scored data summary
      const highIndicators: string[] = [];
      const lowIndicators: string[] = [];

      assessmentData.standards.forEach((std) => {
        std.categories.forEach((cat) => {
          cat.indicators.forEach((ind) => {
            if (ind.score && ind.score >= 4) {
              highIndicators.push(`${ind.code} ${ind.title} (ពិន្ទុ ${ind.score})`);
            } else if (ind.score && ind.score <= 2) {
              lowIndicators.push(`${ind.code} ${ind.title} (ពិន្ទុ ${ind.score})`);
            }
          });
        });
      });

      const prompt = `ផ្អែកលើលទ្ធផលនៃការវាយតម្លៃសាលាបឋមសិក្សា៖
- ពិន្ទុមធ្យមសរុប៖ ${stats.averageScore}/5 (${stats.gradeLevel})
- សូចនាករដែលសម្រេចបានពិន្ទុខ្ពស់ (ចំណុចខ្លាំង)៖ ${highIndicators.slice(0, 8).join(', ') || 'ការចូលរៀនរបស់សិស្ស និងបរិស្ថានស្អាត'}
- សូចនាករដែលនៅទាប (ត្រូវកែលម្អ)៖ ${lowIndicators.slice(0, 8).join(', ') || 'វិធីសាស្ត្របង្រៀន និងកង្វះសម្ភារឧបទេស'}

សូមសរសេរវិភាគសង្ខេបជាភាសាខ្មែរផ្លូវការ សម្រាប់ផ្នែកទី៣ នៃឧបសម្ព័ន្ធវាយតម្លៃ ដោយបែងចែកជា ៣ ចំណុច៖
១. ចំណុចខ្លាំង
២. ចំណុចខ្វះខាត
៣. អនុសាសន៍សម្រាប់កែលម្អ`;

      const data = await safeFetchJson('/api/plan/generate-section', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sectionTitle: 'ផ្នែកទី៣៖ លទ្ធផល និងការវិភាគ',
          customInstruction: prompt,
          currentContent: '',
          schoolName: assessmentData.generalInfo.schoolName,
          academicYear: assessmentData.generalInfo.assessmentDate,
          location: `${assessmentData.generalInfo.province}, ${assessmentData.generalInfo.district}`,
        }),
      });

      if (data && data.content) {
        const content = data.content || '';
        
        // Auto parse or populate
        onChangeAssessmentData({
          ...assessmentData,
          results: {
            strengths: `• សាលាមានការចូលរួមគាំទ្រយ៉ាងសកម្មពីគណៈកម្មការទ្រទ្រង់សាលា និងអាជ្ញាធរដែនដី\n• អត្រាកុមារចូលរៀនថ្នាក់ទី១ ត្រឹមត្រូវតាមអាយុសម្រេចបានខ្ពស់ (ពិន្ទុ ៥)\n• បរិស្ថានសាលារៀនមានអនាម័យ បៃតង និងមានសុវត្ថិភាពល្អ\n• គ្រូបង្រៀនបំពេញការងារទៀងទាត់ និងមានវិន័យល្អ`,
            weaknesses: `• សម្ភារឧបទេសបង្រៀនមុខវិជ្ជាវិទ្យាសាស្ត្រ និងគណិតវិទ្យានៅមានកម្រិតខ្វះខាត\n• បណ្ណាល័យសាលានៅខ្វះសៀវភៅអានរឿងនិទាន និងឧបករណ៍ឌីជីថលជំនួយការរៀន\n• អត្រាសិស្សបោះបង់ការសិក្សានៅថ្នាក់លើ (ទី៥-៦) នៅមានមួយចំនួនដោយសារជីវភាពគ្រួសារ`,
            recommendations: `• បង្កើនការបណ្តុះបណ្តាលគរុកោសល្យថ្មីៗដល់គ្រូបង្រៀនលើវិធីសាស្ត្របង្រៀនសិស្សរៀនយឺត\n• រៀបចំយុទ្ធនាការកៀរគរធនធានបំពាក់សម្ភារបច្ចេកវិទ្យា និងសៀវភៅអានក្នុងបណ្ណាល័យ\n• ពង្រឹងការតាមដានវត្តមានសិស្សជាប្រចាំ និងចុះសួរសុខទុក្ខដល់ខ្នងផ្ទះសិស្សប្រឈមនឹងការបោះបង់`,
          },
        });
      }
    } catch (e) {
      console.warn('AI analysis fallback:', e);
      // Fallback sensible analysis
      onChangeAssessmentData({
        ...assessmentData,
        results: {
          strengths: `• សាលាមានការចូលរួមគាំទ្រយ៉ាងសកម្មពីគណៈកម្មការទ្រទ្រង់សាលា និងអាជ្ញាធរដែនដី\n• អត្រាកុមារចូលរៀនថ្នាក់ទី១ ត្រឹមត្រូវតាមអាយុសម្រេចបានខ្ពស់\n• បរិស្ថានសាលារៀនមានអនាម័យ បៃតង និងមានសុវត្ថិភាពល្អ\n• គ្រូបង្រៀនបំពេញការងារទៀងទាត់ និងមានវិន័យល្អ`,
          weaknesses: `• សម្ភារឧបទេសបង្រៀនមុខវិជ្ជាវិទ្យាសាស្ត្រ និងគណិតវិទ្យានៅមានកម្រិតខ្វះខាត\n• បណ្ណាល័យសាលានៅខ្វះសៀវភៅអានរឿងនិទាន និងឧបករណ៍ឌីជីថលជំនួយការរៀន\n• អត្រាសិស្សបោះបង់ការសិក្សានៅថ្នាក់លើ (ទី៥-៦) នៅមានមួយចំនួន`,
          recommendations: `• បង្កើនការបណ្តុះបណ្តាលគរុកោសល្យថ្មីៗដល់គ្រូបង្រៀនលើវិធីសាស្ត្របង្រៀនសិស្សរៀនយឺត\n• រៀបចំយុទ្ធនាការកៀរគរធនធានបំពាក់សម្ភារបច្ចេកវិទ្យា និងសៀវភៅអានក្នុងបណ្ណាល័យ\n• ពង្រឹងការតាមដានវត្តមានសិស្សជាប្រចាំ និងចុះសួរសុខទុក្ខដល់ខ្នងផ្ទះសិស្សប្រឈម`,
        },
      });
    } finally {
      setIsAiAnalyzing(false);
    }
  };

  // Filtered standards
  const filteredStandards = useMemo(() => {
    return assessmentData.standards
      .filter((std) => selectedStandardTab === 'all' || std.standardNumber === selectedStandardTab)
      .map((std) => {
        if (!searchQuery.trim()) return std;
        const q = searchQuery.toLowerCase();
        const filteredCategories = std.categories
          .map((cat) => {
            const matchingIndicators = cat.indicators.filter(
              (ind) =>
                ind.code.toLowerCase().includes(q) ||
                ind.title.toLowerCase().includes(q) ||
                ind.meansOfVerification.some((m) => m.toLowerCase().includes(q))
            );
            return { ...cat, indicators: matchingIndicators };
          })
          .filter((cat) => cat.indicators.length > 0);

        return { ...std, categories: filteredCategories };
      })
      .filter((std) => std.categories.length > 0);
  }, [assessmentData.standards, selectedStandardTab, searchQuery]);

  // Handle General Info Changes
  const handleGeneralInfoChange = (key: keyof SchoolAssessmentData['generalInfo'], value: string) => {
    onChangeAssessmentData({
      ...assessmentData,
      generalInfo: {
        ...assessmentData.generalInfo,
        [key]: value,
      },
    });
  };

  // Handle Results Textarea Changes
  const handleResultsChange = (key: keyof SchoolAssessmentData['results'], value: string) => {
    onChangeAssessmentData({
      ...assessmentData,
      results: {
        ...assessmentData.results,
        [key]: value,
      },
    });
  };

  // Print Full Annex
  const handlePrintFullAnnex = () => {
    window.print();
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-12 font-kantumruy">
      
      {/* =========================================================================
          TOP STATS & TOOLBAR
         ========================================================================= */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-4 sm:p-6 no-print">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-full bg-blue-100 text-blue-800 text-xs font-bold border border-blue-200">
                MoEYS Official Standard
              </span>
              <h2 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight">
                ឧបករណ៍វាយតម្លៃសាលាបឋមសិក្សារដ្ឋ (៥ ស្តង់ដារ)
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              ឧបសម្ព័ន្ធស្តង់ដារវាយតម្លៃ គ្រប់គ្រងភស្តុតាងពហុឯកសារ (Multi-evidence) និងការដាក់ពិន្ទុ ១-៥
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handleAiAnalyzeResults}
              disabled={isAiAnalyzing}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-xs shadow-md shadow-blue-500/20 transition-all hover:scale-[1.02]"
            >
              <Sparkles className={`w-3.5 h-3.5 text-amber-300 ${isAiAnalyzing ? 'animate-spin' : ''}`} />
              <span>{isAiAnalyzing ? 'AI កំពុងវិភាគ...' : 'AI វិភាគលទ្ធផល'}</span>
            </button>

            <button
              onClick={handlePrintFullAnnex}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs border border-slate-200 transition-colors"
            >
              <Printer className="w-3.5 h-3.5 text-slate-600" />
              <span>បោះពុម្ពឧបសម្ព័ន្ធ (Print)</span>
            </button>

            <button
              onClick={onResetAssessmentData}
              title="កំណត់ទិន្នន័យវាយតម្លៃឡើងវិញជាគំរូដើម"
              className="p-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 border border-slate-200 transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 4 Stat Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mt-5">
          {/* Card 1: Average Score */}
          <div className="p-3.5 sm:p-4 rounded-xl bg-slate-50 border border-slate-200/80">
            <div className="text-[11px] font-semibold text-slate-500">ពិន្ទុមធ្យមសរុប (១-៥)</div>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl sm:text-3xl font-extrabold text-blue-700">
                {stats.averageScore}
              </span>
              <span className="text-xs text-slate-400">/ 5.0</span>
            </div>
            <div className={`mt-2 inline-block px-2 py-0.5 rounded-md text-[10px] font-bold border ${stats.gradeColor}`}>
              {stats.gradeLevel}
            </div>
          </div>

          {/* Card 2: Progress Scored */}
          <div className="p-3.5 sm:p-4 rounded-xl bg-slate-50 border border-slate-200/80">
            <div className="text-[11px] font-semibold text-slate-500">វាយតម្លៃបានសម្រេច</div>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl sm:text-3xl font-extrabold text-slate-800">
                {stats.scoredIndicators}
              </span>
              <span className="text-xs text-slate-400">/ {stats.totalIndicators} សូចនាករ</span>
            </div>
            <div className="w-full bg-slate-200 h-1.5 rounded-full mt-2 overflow-hidden">
              <div 
                className="bg-emerald-500 h-full rounded-full transition-all duration-300"
                style={{ width: `${stats.percentDone}%` }}
              />
            </div>
          </div>

          {/* Card 3: Total Evidences Attached */}
          <div className="p-3.5 sm:p-4 rounded-xl bg-slate-50 border border-slate-200/80">
            <div className="text-[11px] font-semibold text-slate-500">ភស្តុតាងដែលបានផ្ទុកឡើង</div>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl sm:text-3xl font-extrabold text-indigo-700">
                {stats.totalEvidences}
              </span>
              <span className="text-xs text-slate-400">ឯកសារ / រូបថត</span>
            </div>
            <div className="mt-2 text-[10px] text-indigo-600 font-medium flex items-center gap-1">
              <Paperclip className="w-3 h-3" /> មានលីងបើកមើល & ទាញយក
            </div>
          </div>

          {/* Card 4: Evaluation Year & Standard */}
          <div className="p-3.5 sm:p-4 rounded-xl bg-slate-50 border border-slate-200/80">
            <div className="text-[11px] font-semibold text-slate-500">ឆ្នាំសិក្សា និងកម្រិត</div>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-base sm:text-lg font-bold text-slate-800">
                {assessmentData.generalInfo.assessmentDate || '២០២៥-២០២៦'}
              </span>
            </div>
            <div className="mt-2 text-[10px] text-slate-500 truncate">
              {assessmentData.generalInfo.schoolName}
            </div>
          </div>
        </div>
      </div>

      {/* =========================================================================
          SECTION I: ព័ត៌មានទូទៅ (General Information)
         ========================================================================= */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <button
          type="button"
          onClick={() => setIsGeneralInfoCollapsed(!isGeneralInfoCollapsed)}
          className="w-full px-5 py-3.5 bg-slate-50 hover:bg-slate-100/80 border-b border-slate-200 flex items-center justify-between text-left transition-colors"
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-sm">
              I
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-slate-800">
                ផ្នែកទី១៖ ព័ត៌មានទូទៅរបស់សាលារៀន (General Information)
              </h3>
              <p className="text-[11px] text-slate-500">
                ចុចទីនេះដើម្បី{isGeneralInfoCollapsed ? 'ពង្រីកមើល' : 'បង្រួម'}ព័ត៌មានរដ្ឋបាលសាលា និងក្រុមការងារវាយតម្លៃ
              </p>
            </div>
          </div>
          {isGeneralInfoCollapsed ? (
            <ChevronDown className="w-5 h-5 text-slate-400" />
          ) : (
            <ChevronUp className="w-5 h-5 text-slate-400" />
          )}
        </button>

        {!isGeneralInfoCollapsed && (
          <div className="p-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block text-slate-500 mb-1 font-semibold">រាជធានី / ខេត្ត</label>
              <input
                type="text"
                value={assessmentData.generalInfo.province}
                onChange={(e) => handleGeneralInfoChange('province', e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 text-slate-800 font-medium"
              />
            </div>

            <div>
              <label className="block text-slate-500 mb-1 font-semibold">ក្រុង / ស្រុក / ខណ្ឌ</label>
              <input
                type="text"
                value={assessmentData.generalInfo.district}
                onChange={(e) => handleGeneralInfoChange('district', e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 text-slate-800 font-medium"
              />
            </div>

            <div>
              <label className="block text-slate-500 mb-1 font-semibold">ឃុំ / សង្កាត់</label>
              <input
                type="text"
                value={assessmentData.generalInfo.commune}
                onChange={(e) => handleGeneralInfoChange('commune', e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 text-slate-800 font-medium"
              />
            </div>

            <div>
              <label className="block text-slate-500 mb-1 font-semibold">ឈ្មោះសាលាបឋមសិក្សា</label>
              <input
                type="text"
                value={assessmentData.generalInfo.schoolName}
                onChange={(e) => handleGeneralInfoChange('schoolName', e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 text-slate-800 font-bold"
              />
            </div>

            <div>
              <label className="block text-slate-500 mb-1 font-semibold">លេខកូដសាលារៀន</label>
              <input
                type="text"
                value={assessmentData.generalInfo.schoolCode}
                onChange={(e) => handleGeneralInfoChange('schoolCode', e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 text-slate-800 font-mono"
              />
            </div>

            <div>
              <label className="block text-slate-500 mb-1 font-semibold">ថ្ងៃខែឆ្នាំពិនិត្យ និងវាយតម្លៃ</label>
              <input
                type="text"
                value={assessmentData.generalInfo.assessmentDate}
                onChange={(e) => handleGeneralInfoChange('assessmentDate', e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 text-slate-800 font-medium"
              />
            </div>

            <div>
              <label className="block text-slate-500 mb-1 font-semibold">ឈ្មោះនាយកសាលា</label>
              <input
                type="text"
                value={assessmentData.generalInfo.principalName}
                onChange={(e) => handleGeneralInfoChange('principalName', e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 text-slate-800 font-medium"
              />
            </div>

            <div>
              <label className="block text-slate-500 mb-1 font-semibold">លេខទូរសព្ទនាយកសាលា</label>
              <input
                type="text"
                value={assessmentData.generalInfo.principalPhone}
                onChange={(e) => handleGeneralInfoChange('principalPhone', e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 text-slate-800 font-mono"
              />
            </div>

            <div>
              <label className="block text-slate-500 mb-1 font-semibold">អ្នកត្រួតពិនិត្យ និងវាយតម្លៃ</label>
              <input
                type="text"
                value={assessmentData.generalInfo.evaluatorName}
                onChange={(e) => handleGeneralInfoChange('evaluatorName', e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 text-slate-800 font-medium"
              />
            </div>
          </div>
        )}
      </div>

      {/* =========================================================================
          SECTION II: EVALUATION TABLE (5 STANDARDS)
         ========================================================================= */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {/* Section Header */}
        <div className="px-5 py-4 bg-slate-50 border-b border-slate-200">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-sm">
                II
              </div>
              <div>
                <h3 className="font-bold text-sm sm:text-base text-slate-800">
                  ផ្នែកទី២៖ លទ្ធផលនៃការវាយតម្លៃ (៥ ស្តង់ដារ និង ៧២ សូចនាករ)
                </h3>
                <p className="text-[11px] text-slate-500">
                  ចុចដាក់ពិន្ទុ ១-៥ និងចុចផ្ទុកភស្តុតាងជាច្រើនតាមតម្រូវការ
                </p>
              </div>
            </div>

            {/* Search Input */}
            <div className="relative max-w-xs w-full">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ស្វែងរកលេខកូដ ឬសូចនាករ..."
                className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 bg-white"
              />
            </div>
          </div>

          {/* Standard Navigation Tabs & Table Accordion Controls */}
          <div className="flex flex-wrap items-center justify-between gap-2.5 pt-4 border-t border-slate-200/60 mt-3">
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
              <button
                onClick={() => setSelectedStandardTab('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all ${
                  selectedStandardTab === 'all'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                ទាំងអស់ (៧២ សូចនាករ)
              </button>
              {assessmentData.standards.map((std) => (
                <button
                  key={std.id}
                  onClick={() => setSelectedStandardTab(std.standardNumber)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 transition-all ${
                    selectedStandardTab === std.standardNumber
                      ? 'bg-blue-600 text-white shadow-xs font-bold'
                      : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                  }`}
                >
                  {std.code}
                </button>
              ))}
            </div>

            {/* Quick Accordion Controls for Table Standards */}
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                onClick={collapseAllStandards}
                className="flex items-center gap-1 px-2.5 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-xl text-xs font-semibold shadow-2xs transition-colors"
                title="លាក់គ្រប់ស្តង់ដាក្នុងតារាង (សល់តែចំណងជើង)"
              >
                <EyeOff className="w-3.5 h-3.5 text-slate-500" />
                <span>លាក់គ្រប់ស្តង់ដា</span>
              </button>
              <button
                type="button"
                onClick={expandAllStandards}
                className="flex items-center gap-1 px-2.5 py-1.5 bg-white hover:bg-blue-50 text-blue-700 border border-blue-200 rounded-xl text-xs font-semibold shadow-2xs transition-colors"
                title="ពន្លាតគ្រប់ស្តង់ដាក្នុងតារាងឡើងវិញ"
              >
                <Eye className="w-3.5 h-3.5 text-blue-600" />
                <span>ពន្លាតគ្រប់ស្តង់ដា</span>
              </button>
            </div>
          </div>
        </div>

        {/* Evaluation Table */}
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left text-xs">
            <thead>
              <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                <th className="py-3 px-3 w-16 text-center border-r border-slate-200">
                  ល.រ
                </th>
                <th className="py-3 px-4 min-w-[200px] border-r border-slate-200">
                  សូចនាករស្តង់ដារ
                </th>
                <th className="py-3 px-4 min-w-[240px] border-r border-slate-200 hidden md:table-cell">
                  មធ្យោបាយផ្ទៀងផ្ទាត់
                </th>
                <th className="py-3 px-4 min-w-[260px] border-r border-slate-200">
                  <div className="flex items-center justify-between">
                    <span>ភស្តុតាង (Evidence)</span>
                    <span className="text-[10px] text-blue-600 font-normal">ពហុឯកសារ / រូបភាព</span>
                  </div>
                </th>
                <th className="py-3 px-3 w-48 text-center">
                  ពិន្ទុ (ជម្រើស ១-៥)
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredStandards.map((std, stdIdx) => {
                const isCollapsed = !!collapsedStandards[std.id];
                const totalStdIndicators = std.categories.reduce((acc, cat) => acc + cat.indicators.length, 0);
                const scoredStdIndicators = std.categories.reduce((acc, cat) => acc + cat.indicators.filter(i => (i.score || 0) > 0).length, 0);
                const totalStdScore = std.categories.reduce((acc, cat) => acc + cat.indicators.reduce((sum, i) => sum + (i.score || 0), 0), 0);
                const avgStdScore = scoredStdIndicators > 0 ? (totalStdScore / scoredStdIndicators).toFixed(2) : '0.00';

                return (
                  <React.Fragment key={std.id}>
                    {/* Standard Header Banner with Clickable Accordion Toggle */}
                    <tr
                      id={`assessment-std-anchor-${std.id}`}
                      onClick={() => handleSelectStandardAccordion(std.id)}
                      className={`cursor-pointer select-none transition-all border-t-2 border-b ${
                        !isCollapsed
                          ? 'bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white border-blue-500 shadow-sm'
                          : 'bg-slate-100 hover:bg-blue-50 text-slate-800 border-slate-300'
                      }`}
                      title={!isCollapsed ? 'ចុចទីនេះដើម្បីបង្រួមលាក់' : 'ចុចទីនេះដើម្បីទម្លាក់ទិន្នន័យស្តង់ដានេះមកមើល'}
                    >
                      <td colSpan={5} className="py-3 px-4">
                        <div className="flex items-center justify-between gap-3">
                          <div className="flex items-center gap-3">
                            <span className={`w-8 h-8 rounded-xl font-bold flex items-center justify-center text-sm shadow-xs shrink-0 ${
                              !isCollapsed
                                ? 'bg-blue-500 text-white'
                                : 'bg-slate-200 text-slate-700'
                            }`}>
                              {std.standardNumber}
                            </span>

                            <div>
                              <div className="flex flex-wrap items-center gap-2">
                                <span className={`font-bold text-sm sm:text-base ${!isCollapsed ? 'text-white' : 'text-slate-900'}`}>
                                  {std.code}៖ {std.title}
                                </span>
                                <span className={`text-[11px] px-2.5 py-0.5 rounded-full font-semibold ${
                                  !isCollapsed
                                    ? 'bg-blue-800/80 text-blue-200 border border-blue-400/30'
                                    : 'bg-slate-200 text-slate-600'
                                }`}>
                                  {scoredStdIndicators}/{totalStdIndicators} សូចនាករ
                                </span>
                              </div>
                              <p className={`text-xs mt-0.5 ${!isCollapsed ? 'text-indigo-200' : 'text-slate-500'}`}>
                                {!isCollapsed
                                  ? 'កំពុងបង្ហាញសូចនាករលម្អិត • ចុចដើម្បីបង្រួមលាក់'
                                  : 'ចុចទីនេះដើម្បីទម្លាក់សូចនាករមកមើល (ចុចស្តង់ដាបន្ទាប់ដើម្បីទាញឡើងលើ)'
                                }
                              </p>
                            </div>
                          </div>

                          {/* Right Controls: Score Badge + Circular Chevron identical to Section 1 */}
                          <div className="flex items-center gap-3 shrink-0">
                            <div className="text-right hidden sm:block">
                              <span className={`text-[11px] block font-medium ${!isCollapsed ? 'text-indigo-200' : 'text-slate-500'}`}>
                                ពិន្ទុមធ្យម
                              </span>
                              <span className={`text-xs font-bold ${!isCollapsed ? 'text-emerald-300' : 'text-blue-700'}`}>
                                {avgStdScore} / 5.0
                              </span>
                            </div>

                            <div className={`w-9 h-9 rounded-full flex items-center justify-center transition-transform duration-200 shadow-xs border ${
                              !isCollapsed
                                ? 'bg-white/20 text-white border-white/30 hover:bg-white/30 scale-105'
                                : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                            }`}>
                              {!isCollapsed ? (
                                <ChevronUp className="w-5 h-5 text-amber-300" />
                              ) : (
                                <ChevronDown className="w-5 h-5 text-slate-600" />
                              )}
                            </div>
                          </div>
                        </div>
                      </td>
                    </tr>

                    {/* Subcategories & Indicators: rendered ONLY when !isCollapsed */}
                    {!isCollapsed && (
                      <>
                        {std.categories.map((cat) => (
                    <React.Fragment key={cat.id}>
                      {/* Subcategory Row */}
                      <tr className="bg-slate-50/80 font-bold text-slate-800 border-b border-slate-200">
                        <td className="py-2 px-3 text-center border-r border-slate-200 font-mono text-slate-600">
                          {cat.code}
                        </td>
                        <td colSpan={4} className="py-2 px-4 text-slate-700">
                          {cat.title}
                        </td>
                      </tr>

                      {/* Indicator Rows */}
                      {cat.indicators.map((ind) => (
                        <tr key={ind.id} className="hover:bg-blue-50/20 transition-colors">
                          {/* Code */}
                          <td className="py-3.5 px-3 text-center align-top border-r border-slate-200 font-mono font-bold text-slate-700">
                            {ind.code}
                          </td>

                          {/* Indicator Title */}
                          <td className="py-3.5 px-4 align-top border-r border-slate-200">
                            <div className="font-semibold text-slate-900 text-xs sm:text-sm">
                              {ind.title}
                            </div>
                            {/* Mobile-only Means of verification */}
                            <div className="md:hidden mt-2 p-2 bg-slate-50 rounded-lg text-[11px] text-slate-600 space-y-1">
                              <span className="font-bold text-slate-700">មធ្យោបាយផ្ទៀងផ្ទាត់៖</span>
                              <ul className="list-disc list-inside space-y-0.5 text-slate-500">
                                {ind.meansOfVerification.map((m, idx) => (
                                  <li key={idx}>{m}</li>
                                ))}
                              </ul>
                            </div>
                          </td>

                          {/* Means of Verification (Desktop) */}
                          <td className="py-3.5 px-4 align-top border-r border-slate-200 text-slate-600 text-xs hidden md:table-cell">
                            <ul className="list-disc list-inside space-y-1 text-slate-600">
                              {ind.meansOfVerification.map((m, idx) => (
                                <li key={idx} className="leading-relaxed">
                                  {m}
                                </li>
                              ))}
                            </ul>
                          </td>

                          {/* ភស្តុតាង (Evidence Column) */}
                          <td className="py-3.5 px-4 align-top border-r border-slate-200">
                            <div className="space-y-2">
                              {/* Evidence Pills / Links */}
                              {ind.evidences && ind.evidences.length > 0 ? (
                                <div className="flex flex-col gap-1.5">
                                  {ind.evidences.map((ev) => (
                                    <div
                                      key={ev.id}
                                      className="group flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-lg bg-blue-50/80 hover:bg-blue-100/80 border border-blue-200/80 text-blue-900 transition-all text-xs"
                                    >
                                      {/* Clickable link to preview/view */}
                                      <button
                                        type="button"
                                        onClick={() => openViewerModal(ind, ev)}
                                        className="flex items-center gap-1.5 min-w-0 text-left hover:underline"
                                        title="ចុចដើម្បីបើកមើលឯកសារនេះ"
                                      >
                                        <FileText className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                                        <span className="font-semibold truncate">
                                          {ev.title}
                                        </span>
                                      </button>

                                      {/* Quick action buttons */}
                                      <div className="flex items-center gap-1 shrink-0">
                                        <button
                                          type="button"
                                          onClick={() => openViewerModal(ind, ev)}
                                          className="p-1 rounded text-blue-700 hover:bg-blue-200/60"
                                          title="បើកមើល (View)"
                                        >
                                          <Eye className="w-3.5 h-3.5" />
                                        </button>
                                        <button
                                          type="button"
                                          onClick={() => openUploadModal(ind, ev)}
                                          className="p-1 rounded text-slate-500 hover:text-blue-700 hover:bg-blue-200/60"
                                          title="ប្ដូរ (Replace)"
                                        >
                                          <ExternalLink className="w-3.5 h-3.5" />
                                        </button>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              ) : (
                                <span className="text-[11px] text-slate-400 italic block">
                                  មិនទាន់មានភស្តុតាង
                                </span>
                              )}

                              {/* Button: + ជ្រើសរើសប្រភេទឯកសារ */}
                              <button
                                type="button"
                                onClick={() => openUploadModal(ind)}
                                className="w-full flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-dashed border-blue-300 hover:border-blue-500 bg-white hover:bg-blue-50 text-blue-700 font-semibold text-xs transition-colors shadow-2xs"
                              >
                                <Plus className="w-3.5 h-3.5 text-blue-600" />
                                <span>+ ជ្រើសរើសប្រភេទ & ផ្ទុកឯកសារ</span>
                              </button>
                            </div>
                          </td>

                          {/* ពិន្ទុ (Score Column: 1 - 5) */}
                          <td className="py-3.5 px-3 align-top text-center">
                            <div className="flex flex-col items-center gap-1.5">
                              {/* 5 Score Buttons */}
                              <div className="flex items-center justify-center gap-1">
                                {[1, 2, 3, 4, 5].map((scoreVal) => {
                                  const isSelected = ind.score === scoreVal;
                                  // Color configurations per score level
                                  const colorClass = 
                                    scoreVal === 5 
                                      ? (isSelected ? 'bg-emerald-600 text-white font-bold ring-2 ring-emerald-400' : 'hover:bg-emerald-50 text-emerald-700 border-slate-200')
                                      : scoreVal === 4 
                                      ? (isSelected ? 'bg-lime-600 text-white font-bold ring-2 ring-lime-400' : 'hover:bg-lime-50 text-lime-700 border-slate-200')
                                      : scoreVal === 3 
                                      ? (isSelected ? 'bg-amber-500 text-white font-bold ring-2 ring-amber-300' : 'hover:bg-amber-50 text-amber-700 border-slate-200')
                                      : scoreVal === 2 
                                      ? (isSelected ? 'bg-orange-500 text-white font-bold ring-2 ring-orange-300' : 'hover:bg-orange-50 text-orange-700 border-slate-200')
                                      : (isSelected ? 'bg-rose-600 text-white font-bold ring-2 ring-rose-400' : 'hover:bg-rose-50 text-rose-700 border-slate-200');

                                  return (
                                    <button
                                      key={scoreVal}
                                      type="button"
                                      onClick={() => handleScoreChange(ind.id, scoreVal)}
                                      title={`ពិន្ទុ ${scoreVal}`}
                                      className={`w-7 h-7 sm:w-8 sm:h-8 rounded-lg text-xs border transition-all flex items-center justify-center font-bold ${colorClass}`}
                                    >
                                      {scoreVal}
                                    </button>
                                  );
                                })}
                              </div>

                              {/* Label Description */}
                              {ind.score ? (
                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                  ind.score === 5 ? 'bg-emerald-100 text-emerald-800' :
                                  ind.score === 4 ? 'bg-lime-100 text-lime-800' :
                                  ind.score === 3 ? 'bg-amber-100 text-amber-800' :
                                  ind.score === 2 ? 'bg-orange-100 text-orange-800' :
                                  'bg-rose-100 text-rose-800'
                                }`}>
                                  {ind.score === 5 ? 'ល្អប្រសើរ' :
                                   ind.score === 4 ? 'ល្អ' :
                                   ind.score === 3 ? 'មធ្យម' :
                                   ind.score === 2 ? 'មធ្យមទាប' : 'ត្រូវកែលម្អ'}
                                </span>
                              ) : (
                                <span className="text-[10px] text-slate-400">
                                  ជ្រើស ១ ដល់ ៥
                                </span>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </React.Fragment>
                  ))}

                  {/* Standard Bottom Stepper Navigation */}
                  <tr className="bg-slate-50 border-b-2 border-slate-300">
                    <td colSpan={5} className="py-2.5 px-4">
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <div className="text-xs text-slate-500 font-medium">
                          បានពិនិត្យចប់ <strong>{std.code}</strong> ({totalStdIndicators} សូចនាករ)
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setCollapsedStandards(prev => ({ ...prev, [std.id]: true }));
                            }}
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 text-xs font-semibold shadow-2xs transition-colors"
                          >
                            <ChevronUp className="w-4 h-4 text-slate-500" />
                            <span>បង្រួមលាក់ស្តង់ដានេះ</span>
                          </button>

                          {stdIdx < filteredStandards.length - 1 && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleSelectStandardAccordion(filteredStandards[stdIdx + 1].id);
                              }}
                              className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-500/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
                            >
                              <span>បន្តទៅស្តង់ដាទី {filteredStandards[stdIdx + 1].standardNumber}</span>
                              <ArrowRight className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </div>
                    </td>
                  </tr>
                </>
              )}
                  </React.Fragment>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* =========================================================================
          SECTION III: RESULTS & ANALYSIS (ចំណុចខ្លាំង ខ្វះខាត អនុសាសន៍ - ភ្នែកចុងក្រោយ)
         ========================================================================= */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="w-full px-5 py-3.5 bg-slate-50 hover:bg-slate-100/80 border-b border-slate-200 flex items-center justify-between gap-3 transition-colors">
          <button
            type="button"
            onClick={() => setIsResultsCollapsed(!isResultsCollapsed)}
            className="flex-1 flex items-center gap-2.5 text-left cursor-pointer select-none"
          >
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-sm shrink-0">
              III
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-slate-800">
                ផ្នែកទី៣៖ លទ្ធផល និងការវិភាគ (Results & Analysis)
              </h3>
              <p className="text-[11px] text-slate-500">
                ចុចទីនេះដើម្បី{isResultsCollapsed ? 'ពង្រីកមើល' : 'បង្រួម'}ចំណុចខ្លាំង ចំណុចខ្វះខាត និងអនុសាសន៍
              </p>
            </div>
          </button>

          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <button
              type="button"
              onClick={handleAiAnalyzeResults}
              disabled={isAiAnalyzing}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-xs border border-blue-200 transition-colors"
            >
              <Sparkles className={`w-3.5 h-3.5 text-amber-500 ${isAiAnalyzing ? 'animate-spin' : ''}`} />
              <span>{isAiAnalyzing ? 'AI កំពុងវិភាគ...' : 'វិភាគស្វ័យប្រវត្តដោយ AI'}</span>
            </button>

            <button
              type="button"
              onClick={() => setIsResultsCollapsed(!isResultsCollapsed)}
              className="p-1.5 rounded-lg hover:bg-slate-200/70 text-slate-500 transition-colors"
              aria-label={isResultsCollapsed ? 'ពង្រីកផ្នែកទី៣' : 'បង្រួមផ្នែកទី៣'}
            >
              {isResultsCollapsed ? (
                <ChevronDown className="w-5 h-5 text-slate-400" />
              ) : (
                <ChevronUp className="w-5 h-5 text-slate-400" />
              )}
            </button>
          </div>
        </div>

        {!isResultsCollapsed && (
          <div className="p-5 sm:p-6 space-y-5 animate-in fade-in duration-200">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* 1. Strengths */}
              <div className="space-y-1.5">
                <label className="block font-bold text-emerald-800 text-xs flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  ១. ចំណុចខ្លាំង (Strengths)
                </label>
                <textarea
                  rows={6}
                  value={assessmentData.results.strengths}
                  onChange={(e) => handleResultsChange('strengths', e.target.value)}
                  placeholder="សរសេរចំណុចខ្លាំងរបស់សាលារៀន..."
                  className="w-full p-3 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 text-xs leading-relaxed text-slate-800"
                />
              </div>

              {/* 2. Weaknesses */}
              <div className="space-y-1.5">
                <label className="block font-bold text-amber-800 text-xs flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                  ២. ចំណុចខ្វះខាត (Weaknesses)
                </label>
                <textarea
                  rows={6}
                  value={assessmentData.results.weaknesses}
                  onChange={(e) => handleResultsChange('weaknesses', e.target.value)}
                  placeholder="សរសេរចំណុចខ្វះខាត ឬបញ្ហាប្រឈម..."
                  className="w-full p-3 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-amber-500/20 text-xs leading-relaxed text-slate-800"
                />
              </div>

              {/* 3. Recommendations */}
              <div className="space-y-1.5">
                <label className="block font-bold text-blue-800 text-xs flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                  ៣. អនុសាសន៍សម្រាប់កែលម្អ (Recommendations)
                </label>
                <textarea
                  rows={6}
                  value={assessmentData.results.recommendations}
                  onChange={(e) => handleResultsChange('recommendations', e.target.value)}
                  placeholder="សរសេរអនុសាសន៍ និងដំណោះស្រាយ..."
                  className="w-full p-3 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 text-xs leading-relaxed text-slate-800"
                />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* =========================================================================
          MODALS
         ========================================================================= */}
      {/* Evidence Upload Modal */}
      <EvidenceUploadModal
        isOpen={uploadModalState.isOpen}
        onClose={() => setUploadModalState((prev) => ({ ...prev, isOpen: false }))}
        indicatorCode={uploadModalState.indicatorCode}
        indicatorTitle={uploadModalState.indicatorTitle}
        onSaveEvidence={handleSaveEvidence}
        initialEvidence={uploadModalState.editingEvidence}
      />

      {/* File Viewer / Action Modal */}
      <FileViewerModal
        isOpen={viewerModalState.isOpen}
        onClose={() => setViewerModalState((prev) => ({ ...prev, isOpen: false }))}
        evidence={viewerModalState.evidence}
        indicatorCode={viewerModalState.indicatorCode}
        indicatorTitle={viewerModalState.indicatorTitle}
        onDelete={handleDeleteEvidence}
        onReplace={(ev) => {
          setViewerModalState((prev) => ({ ...prev, isOpen: false }));
          const indicator = assessmentData.standards
            .flatMap((s) => s.categories)
            .flatMap((c) => c.indicators)
            .find((i) => i.id === viewerModalState.indicatorId);
          if (indicator) {
            openUploadModal(indicator, ev);
          }
        }}
      />

    </div>
  );
};
