import React, { useState, useEffect, useRef } from 'react';
import { 
  Sparkles, 
  Printer, 
  Copy, 
  Download, 
  RotateCcw, 
  Eye, 
  Edit3,
  Check,
  BookOpen,
  CheckCircle2,
  RefreshCw,
  AlertCircle,
  MoreVertical,
  X,
  Cloud,
  Building2,
  Award,
  ClipboardCheck,
  BarChart3,
  Presentation,
  FileSpreadsheet
} from 'lucide-react';

interface NavbarProps {
  onOpenGenerator: () => void;
  onOpenExecutiveSummary?: () => void;
  onOpenPlanList: () => void;
  onOpenSchoolContext?: () => void;
  onPrint: () => void;
  onCopyAll: () => void;
  onDownloadDoc: () => void;
  onReset: () => void;
  onOpenWalkthrough?: () => void;
  viewMode: 'edit' | 'preview' | 'assessment' | 'dashboard' | 'bsp';
  setViewMode: (mode: 'edit' | 'preview' | 'assessment' | 'dashboard' | 'bsp') => void;
  isCopied: boolean;
  totalWords: number;
  saveStatus: 'saved' | 'saving' | 'error';
  lastSavedText: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenGenerator,
  onOpenExecutiveSummary,
  onOpenPlanList,
  onOpenSchoolContext,
  onPrint,
  onCopyAll,
  onDownloadDoc,
  onReset,
  onOpenWalkthrough,
  viewMode,
  setViewMode,
  isCopied,
  totalWords,
  saveStatus,
  lastSavedText,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // Close mobile menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent | TouchEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setMobileMenuOpen(false);
      }
    };
    if (mobileMenuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('touchstart', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('touchstart', handleClickOutside);
    };
  }, [mobileMenuOpen]);

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-slate-200/80 shadow-xs w-full max-w-full">
      {/* =========================================================================
          DESKTOP & TABLET NAVBAR (hidden on mobile < md)
         ========================================================================= */}
      <div className="hidden md:flex max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 items-center justify-between gap-4">
        {/* Left Branding */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-700 via-indigo-600 to-sky-500 flex items-center justify-center text-white shadow-md shadow-blue-500/20 shrink-0">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base lg:text-lg font-bold text-slate-900 tracking-tight font-kantumruy">
                ផែនការប្រតិបត្តិ <span className="text-blue-600 font-normal">AI</span>
              </h1>
              <span className="hidden lg:inline-block px-2 py-0.5 text-[11px] font-medium bg-blue-50 text-blue-700 rounded-full border border-blue-200/60">
                MoEYS AOP & ៥ ស្តង់ដារ
              </span>
            </div>
            <p className="text-xs text-slate-500 hidden lg:block">
              កម្មវិធីសរសេរផែនការប្រតិបត្តិ (AOP) & យុទ្ធសាស្ត្រថវិកា ៣ ឆ្នាំ (BSP)
            </p>
          </div>
        </div>

        {/* Center View Switcher & Auto-save Indicator */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-medium">
            {/* 1-Year AOP Edit */}
            <button
              onClick={() => setViewMode('edit')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                viewMode === 'edit'
                  ? 'bg-white text-blue-700 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>កែសម្រួល</span>
            </button>

            {/* Formal Print View */}
            <button
              onClick={() => setViewMode('preview')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                viewMode === 'preview'
                  ? 'bg-white text-blue-700 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>ទម្រង់ផ្លូវការ</span>
            </button>

            {/* 3-Year BSP Plan */}
            <button
              onClick={() => setViewMode('bsp')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                viewMode === 'bsp'
                  ? 'bg-indigo-600 text-white shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              title="ផែនការយុទ្ធសាស្ត្រថវិកា ៣ ឆ្នាំ (BSP) មេសម្រាប់វិនិយោគជាមួយឃុំ"
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>ផែនការ ៣ ឆ្នាំ (BSP)</span>
            </button>

            {/* Dashboard */}
            <button
              onClick={() => setViewMode('dashboard')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                viewMode === 'dashboard'
                  ? 'bg-white text-blue-700 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5 text-blue-600" />
              <span className="hidden xl:inline">ផ្ទាំងវឌ្ឍនភាព (Dashboard)</span>
              <span className="xl:hidden">វឌ្ឍនភាព</span>
            </button>

            {/* Assessment Tool */}
            <button
              onClick={() => setViewMode('assessment')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                viewMode === 'assessment'
                  ? 'bg-blue-600 text-white shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Award className="w-3.5 h-3.5 text-amber-300" />
              <span>៥ ស្តង់ដារ</span>
            </button>
          </div>

          {/* Auto-save Status Indicator */}
          <div className="hidden lg:flex items-center transition-all">
            {saveStatus === 'saving' && (
              <div className="flex items-center gap-1.5 text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200 text-xs font-medium">
                <RefreshCw className="w-3 h-3 animate-spin text-amber-600" />
                <span>កំពុងរក្សាទុក...</span>
              </div>
            )}
            {saveStatus === 'saved' && (
              <div className="flex items-center gap-1.5 text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200 text-xs font-medium animate-in fade-in duration-200">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>បានរក្សាទុក {lastSavedText}</span>
              </div>
            )}
            {saveStatus === 'error' && (
              <div className="flex items-center gap-1.5 text-rose-700 bg-rose-50 px-2.5 py-1 rounded-full border border-rose-200 text-xs font-medium">
                <AlertCircle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                <span>បរាជ័យក្នុងការរក្សាទុក</span>
              </div>
            )}
          </div>
        </div>

        {/* Right Action Buttons */}
        <div className="flex items-center gap-2 shrink-0">
          {/* School Context Profile Button */}
          {onOpenSchoolContext && (
            <button
              onClick={onOpenSchoolContext}
              title="បរិបទ និងចំណុចខ្លាំង-ប្រឈមរបស់សាលារៀន"
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-semibold transition-all border border-emerald-200"
            >
              <Building2 className="w-4 h-4 text-emerald-600" />
              <span className="hidden xl:inline">បរិបទសាលា</span>
            </button>
          )}

          {/* Multi-Plan Manager Button */}
          <button
            onClick={onOpenPlanList}
            title="គ្រប់គ្រង ឬបង្កើតផែនការបន្ថែមក្នុង Firestore"
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition-all border border-slate-200"
          >
            <BookOpen className="w-4 h-4 text-blue-600" />
            <span className="hidden xl:inline">បញ្ជីផែនការ (Firestore)</span>
            <span className="xl:hidden">ផែនការ</span>
          </button>

          {/* Paperless Walkthrough Button */}
          {onOpenWalkthrough && (
            <button
              onClick={onOpenWalkthrough}
              title="បទបង្ហាញពិគ្រោះយោបល់ជាមួយឃុំ និងសហគមន៍ (មិនប្រើក្រដាស)"
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 text-xs font-bold transition-all border border-amber-300 shadow-2xs hover:scale-[1.02] active:scale-[0.98]"
            >
              <Presentation className="w-4 h-4 text-amber-600" />
              <span className="hidden xl:inline">បទបង្ហាញសហគមន៍/ឃុំ</span>
            </button>
          )}

          {/* Executive Summary AI Button */}
          {onOpenExecutiveSummary && (
            <button
              onClick={onOpenExecutiveSummary}
              title="សង្ខេបផែនការទាំងមូលជា ១ ទំព័រណែនាំ (AI Executive Summary)"
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-teal-50 hover:bg-teal-100 text-teal-800 text-xs font-bold transition-all border border-teal-200 shadow-2xs"
            >
              <FileSpreadsheet className="w-4 h-4 text-teal-600" />
              <span className="hidden xl:inline">សង្ខេប ១ ទំព័រ AI</span>
              <span className="xl:hidden">សង្ខេប AI</span>
            </button>
          )}

          {/* AI Generator Button */}
          <button
            onClick={onOpenGenerator}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white text-xs font-semibold shadow-md shadow-blue-500/25 transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
            <span className="hidden lg:inline">បង្កើតដោយ AI ស្វ័យប្រវត្ត</span>
            <span className="lg:hidden">AI បង្កើត</span>
          </button>

          {/* Print / Export Icons */}
          <div className="flex items-center border-l border-slate-200 pl-2 gap-1.5">
            <button
              onClick={onPrint}
              title="បោះពុម្ព ឬរក្សាទុកជា PDF (Print / Save as PDF)"
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors border border-transparent hover:border-slate-200"
            >
              <Printer className="w-4 h-4" />
            </button>

            <button
              onClick={onCopyAll}
              title="ចម្លងអត្ថបទទាំងអស់ (Copy All for Google Docs)"
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors border border-transparent hover:border-slate-200 relative"
            >
              {isCopied ? (
                <Check className="w-4 h-4 text-emerald-600" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
            </button>

            <button
              onClick={onDownloadDoc}
              title="ទាញយក និងនាំចេញឯកសារ (Word, PDF, HTML, ផ្ទាំងថ្មី...)"
              className="p-2 text-slate-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-colors border border-transparent hover:border-blue-200"
            >
              <Download className="w-4 h-4" />
            </button>

            <button
              onClick={onReset}
              title="កំណត់ឡើងវិញជាគំរូដើម (Reset to Default)"
              className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors border border-transparent hover:border-rose-200"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* =========================================================================
          MOBILE DEDICATED NAVBAR (visible ONLY on mobile < md)
          Guaranteed 100% viewport width without horizontal overflow
         ========================================================================= */}
      <div className="md:hidden px-3.5 h-14 flex items-center justify-between gap-2 max-w-full">
        {/* Left Branding */}
        <div className="flex items-center gap-2 min-w-0 shrink">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-blue-700 via-indigo-600 to-sky-500 flex items-center justify-center text-white shadow-xs shrink-0">
            <BookOpen className="w-4 h-4" />
          </div>
          <div className="truncate">
            <h1 className="text-sm font-bold text-slate-900 tracking-tight font-kantumruy truncate">
              ផែនការប្រតិបត្តិ <span className="text-blue-600 font-semibold">AI</span>
            </h1>
          </div>
        </div>

        {/* Right Mobile Actions: AI Generator Button + More Options Menu */}
        <div className="flex items-center gap-1.5 shrink-0" ref={menuRef}>
          {/* AI Generator Button */}
          <button
            onClick={onOpenGenerator}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-xs font-semibold shadow-xs transition-transform active:scale-95"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>AI បង្កើត</span>
          </button>

          {/* More Menu Dropdown Trigger */}
          <div className="relative">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              title="ម៉ឺនុយជម្រើសបន្ថែម"
              className={`p-2 rounded-lg border transition-colors ${
                mobileMenuOpen
                  ? 'bg-blue-50 text-blue-700 border-blue-200'
                  : 'text-slate-600 hover:bg-slate-100 border-slate-200'
              }`}
            >
              {mobileMenuOpen ? <X className="w-4 h-4" /> : <MoreVertical className="w-4 h-4" />}
            </button>

            {/* Mobile Dropdown Popover */}
            {mobileMenuOpen && (
              <div className="absolute right-0 top-full mt-2 w-72 bg-white rounded-2xl shadow-xl border border-slate-200 p-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="px-3 py-2 border-b border-slate-100 mb-1 flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700">ជម្រើស និងមុខងារ</span>
                  {saveStatus === 'saved' && (
                    <span className="text-[10px] text-emerald-600 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> រក្សាទុករួចរាល់
                    </span>
                  )}
                  {saveStatus === 'saving' && (
                    <span className="text-[10px] text-amber-600 flex items-center gap-1">
                      <RefreshCw className="w-3 h-3 animate-spin" /> កំពុងរក្សាទុក...
                    </span>
                  )}
                </div>

                <div className="space-y-1 text-xs">
                  {/* View Modes in Mobile Menu */}
                  <div className="p-1.5 bg-slate-50 rounded-xl space-y-1 mb-1">
                    <button
                      onClick={() => {
                        setViewMode('edit');
                        setMobileMenuOpen(false);
                      }}
                      className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left ${
                        viewMode === 'edit' ? 'bg-white text-blue-700 font-bold shadow-2xs' : 'text-slate-700'
                      }`}
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>កែសម្រួលផែនការ</span>
                    </button>
                    <button
                      onClick={() => {
                        setViewMode('preview');
                        setMobileMenuOpen(false);
                      }}
                      className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left ${
                        viewMode === 'preview' ? 'bg-white text-blue-700 font-bold shadow-2xs' : 'text-slate-700'
                      }`}
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>ទម្រង់រដ្ឋបាលផ្លូវការ</span>
                    </button>
                    <button
                      onClick={() => {
                        setViewMode('bsp');
                        setMobileMenuOpen(false);
                      }}
                      className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left ${
                        viewMode === 'bsp' ? 'bg-indigo-600 text-white font-bold shadow-2xs' : 'text-slate-700'
                      }`}
                    >
                      <Building2 className="w-3.5 h-3.5" />
                      <span>ផែនការយុទ្ធសាស្ត្រថវិកា ៣ ឆ្នាំ (BSP)</span>
                    </button>
                    <button
                      onClick={() => {
                        setViewMode('dashboard');
                        setMobileMenuOpen(false);
                      }}
                      className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left ${
                        viewMode === 'dashboard' ? 'bg-blue-600 text-white font-bold shadow-2xs' : 'text-slate-700'
                      }`}
                    >
                      <BarChart3 className="w-3.5 h-3.5" />
                      <span>ផ្ទាំងវឌ្ឍនភាព (Dashboard)</span>
                    </button>
                    <button
                      onClick={() => {
                        setViewMode('assessment');
                        setMobileMenuOpen(false);
                      }}
                      className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left ${
                        viewMode === 'assessment' ? 'bg-blue-600 text-white font-bold shadow-2xs' : 'text-blue-900'
                      }`}
                    >
                      <Award className="w-3.5 h-3.5 text-amber-300" />
                      <span>ឧបករណ៍វាយតម្លៃ ៥ ស្តង់ដារ</span>
                    </button>
                  </div>

                  {/* Executive Summary 1-Page AI Button in Mobile Menu */}
                  {onOpenExecutiveSummary && (
                    <button
                      onClick={() => {
                        onOpenExecutiveSummary();
                        setMobileMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl bg-teal-50 hover:bg-teal-100 text-teal-900 border border-teal-200 transition-colors text-left font-bold"
                    >
                      <FileSpreadsheet className="w-4 h-4 text-teal-600 shrink-0" />
                      <div>
                        <div className="font-bold text-teal-950">សេចក្តីសង្ខេបប្រតិបត្តិ ១ ទំព័រ AI</div>
                        <div className="text-[11px] text-teal-700 font-normal">ទំព័រណែនាំផ្លូវការងាយស្រួលបោះពុម្ព</div>
                      </div>
                    </button>
                  )}

                  {/* Walkthrough Presentation Button in Mobile Menu */}
                  {onOpenWalkthrough && (
                    <button
                      onClick={() => {
                        onOpenWalkthrough();
                        setMobileMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 transition-colors text-left font-bold"
                    >
                      <Presentation className="w-4 h-4 text-amber-600 shrink-0" />
                      <div>
                        <div className="font-bold text-amber-950">បទបង្ហាញសហគមន៍/ឃុំ</div>
                        <div className="text-[11px] text-amber-800 font-normal">បង្ហាញមួយចំណុចៗ មិនប្រើក្រដាស</div>
                      </div>
                    </button>
                  )}

                  {/* School Context Profile Button */}
                  {onOpenSchoolContext && (
                    <button
                      onClick={() => {
                        onOpenSchoolContext();
                        setMobileMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl hover:bg-emerald-50 text-slate-700 hover:text-emerald-800 transition-colors text-left"
                    >
                      <Building2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <div>
                        <div className="font-semibold text-slate-800">បរិបទ និងចំណុចខ្លាំង-ប្រឈម</div>
                        <div className="text-[11px] text-slate-500">ផ្ទុកឡើងរបាយការណ៍សាលា</div>
                      </div>
                    </button>
                  )}

                  {/* Open Plans List */}
                  <button
                    onClick={() => {
                      onOpenPlanList();
                      setMobileMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl hover:bg-blue-50 text-slate-700 hover:text-blue-700 transition-colors text-left"
                  >
                    <BookOpen className="w-4 h-4 text-blue-600 shrink-0" />
                    <div>
                      <div className="font-semibold text-slate-800">បញ្ជីផែនការ (Firestore)</div>
                      <div className="text-[11px] text-slate-500">បើក ឬបង្កើតផែនការថ្មី</div>
                    </div>
                  </button>

                  {/* Print / PDF */}
                  <button
                    onClick={() => {
                      onPrint();
                      setMobileMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl hover:bg-slate-50 text-slate-700 transition-colors text-left"
                  >
                    <Printer className="w-4 h-4 text-slate-600 shrink-0" />
                    <div>
                      <div className="font-medium text-slate-800">បោះពុម្ព ឬរក្សាទុកជា PDF</div>
                      <div className="text-[11px] text-slate-500">ទម្រង់រដ្ឋបាលផ្លូវការ</div>
                    </div>
                  </button>

                  {/* Copy All */}
                  <button
                    onClick={() => {
                      onCopyAll();
                      setMobileMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl hover:bg-slate-50 text-slate-700 transition-colors text-left"
                  >
                    {isCopied ? (
                      <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                    ) : (
                      <Copy className="w-4 h-4 text-slate-600 shrink-0" />
                    )}
                    <div>
                      <div className="font-medium text-slate-800">
                        {isCopied ? 'បានចម្លងរួចរាល់!' : 'ចម្លងអត្ថបទទាំងអស់'}
                      </div>
                      <div className="text-[11px] text-slate-500">សម្រាប់ Paste ចូល Google Docs</div>
                    </div>
                  </button>

                  {/* Download Doc */}
                  <button
                    onClick={() => {
                      onDownloadDoc();
                      setMobileMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl hover:bg-slate-50 text-slate-700 transition-colors text-left"
                  >
                    <Download className="w-4 h-4 text-blue-600 shrink-0" />
                    <div>
                      <div className="font-medium text-slate-800">ទាញយក និងនាំចេញឯកសារ</div>
                      <div className="text-[11px] text-slate-500">Word (.doc), ផ្ទាំងថ្មី, ចម្លង, HTML, PDF</div>
                    </div>
                  </button>

                  {/* Reset */}
                  <div className="pt-1 mt-1 border-t border-slate-100">
                    <button
                      onClick={() => {
                        onReset();
                        setMobileMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl hover:bg-rose-50 text-rose-600 transition-colors text-left"
                    >
                      <RotateCcw className="w-4 h-4 text-rose-500 shrink-0" />
                      <div className="font-medium">កំណត់ឡើងវិញជាគំរូដើម</div>
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Mode Switcher Bar */}
      <div className="md:hidden px-3 pb-2 pt-0.5 flex items-center justify-between gap-1 border-t border-slate-100 bg-white">
        <button
          onClick={() => setViewMode('edit')}
          className={`flex-1 flex items-center justify-center gap-1 py-1.5 px-2 rounded-lg text-xs font-semibold transition-all ${
            viewMode === 'edit'
              ? 'bg-blue-50 text-blue-700 border border-blue-200 shadow-2xs font-bold'
              : 'text-slate-600 hover:bg-slate-50'
          }`}
        >
          <Edit3 className="w-3.5 h-3.5" />
          <span>កែសម្រួល</span>
        </button>
        <button
          onClick={() => setViewMode('preview')}
          className={`flex-1 flex items-center justify-center gap-1 py-1.5 px-2 rounded-lg text-xs font-semibold transition-all ${
            viewMode === 'preview'
              ? 'bg-blue-50 text-blue-700 border border-blue-200 shadow-2xs font-bold'
              : 'text-slate-600 hover:bg-slate-50'
          }`}
        >
          <Eye className="w-3.5 h-3.5" />
          <span>ផ្លូវការ</span>
        </button>
        <button
          onClick={() => setViewMode('bsp')}
          className={`flex-1 flex items-center justify-center gap-1 py-1.5 px-2 rounded-lg text-xs font-semibold transition-all ${
            viewMode === 'bsp'
              ? 'bg-indigo-600 text-white font-bold shadow-2xs'
              : 'text-slate-600 hover:bg-slate-50'
          }`}
        >
          <Building2 className="w-3.5 h-3.5" />
          <span>BSP ៣ ឆ្នាំ</span>
        </button>
        <button
          onClick={() => setViewMode('assessment')}
          className={`flex-1 flex items-center justify-center gap-1 py-1.5 px-2 rounded-lg text-xs font-semibold transition-all ${
            viewMode === 'assessment'
              ? 'bg-blue-600 text-white font-bold shadow-2xs'
              : 'text-slate-600 hover:bg-slate-50'
          }`}
        >
          <Award className="w-3.5 h-3.5 text-amber-300" />
          <span>៥ ស្តង់ដារ</span>
        </button>
      </div>
    </header>
  );
};
