import React from 'react';
import { PlanData } from '../types/plan';
import { Sparkles, Printer, FileSpreadsheet } from 'lucide-react';

interface FormalDocumentViewProps {
  plan: PlanData;
  onOpenExecutiveSummary?: () => void;
}

export const FormalDocumentView: React.FC<FormalDocumentViewProps> = ({
  plan,
  onOpenExecutiveSummary,
}) => {
  const execSummary = plan.executiveSummary;

  return (
    <div className="space-y-4 max-w-4xl mx-auto my-6">
      {/* Quick Action Bar for Executive Summary & Printing */}
      <div className="no-print bg-white border border-slate-200 rounded-2xl p-3.5 sm:px-5 shadow-xs flex flex-wrap items-center justify-between gap-3 font-kantumruy">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center border border-teal-200">
            <FileSpreadsheet className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-bold text-slate-900">
              ទំព័រណែនាំ៖ សេចក្តីសង្ខេបប្រតិបត្តិ ១ ទំព័រ (Executive Summary)
            </div>
            <div className="text-[11px] text-slate-500">
              {execSummary
                ? 'បានភ្ជាប់ជាទំព័រទី ១ នៃឯកសារផ្លូវការរួចរាល់'
                : 'បង្កើតទំព័រណែនាំ ១ ទំព័រ A4 ដោយ AI មុនពេលបោះពុម្ពឯកសារផ្លូវការ'}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {onOpenExecutiveSummary && (
            <button
              type="button"
              onClick={onOpenExecutiveSummary}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white text-xs font-bold shadow-sm transition-all"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>{execSummary ? 'មើល ឬកែសេចក្តីសង្ខេប ១ ទំព័រ' : 'បង្កើតសេចក្តីសង្ខេប ១ ទំព័រ AI'}</span>
            </button>
          )}
          <button
            type="button"
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-sm transition-all"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>បោះពុម្ពទាំងមូល</span>
          </button>
        </div>
      </div>

      {/* Introduction Page 1: Executive Summary (when generated & attached) */}
      {execSummary && (
        <div className="bg-white p-8 sm:p-12 shadow-lg border border-slate-200 rounded-2xl print:shadow-none print:border-none print:p-0 print:m-0 font-kantumruy text-slate-900 leading-relaxed text-xs print:break-after-page">
          <div className="text-center border-b-2 border-blue-900 pb-3 mb-4">
            <div className="font-moul text-sm sm:text-base text-blue-950">ព្រះរាជាណាចក្រកម្ពុជា</div>
            <div className="font-moul text-xs sm:text-sm text-blue-900 mt-0.5">ជាតិ សាសនា ព្រះមហាក្សត្រ</div>
            <div className="flex justify-between items-start text-xs text-slate-700 mt-3 text-left">
              <div>
                <div className="font-bold text-slate-900">ក្រសួងអប់រំ យុវជន និងកីឡា</div>
                <div>{plan.location} • <strong className="text-blue-900">{plan.schoolName}</strong></div>
              </div>
              <div className="text-right">
                <div className="font-bold text-slate-900">{plan.academicYear}</div>
                <div>{plan.schoolType}</div>
              </div>
            </div>
            <h2 className="font-moul text-base sm:text-lg text-blue-900 mt-4">
              សេចក្តីសង្ខេបប្រតិបត្តិ (EXECUTIVE SUMMARY)
            </h2>
            <p className="text-xs sm:text-sm font-semibold text-slate-700 mt-0.5">
              {execSummary.documentTitle}
            </p>
          </div>

          <div className="space-y-3">
            <div className="bg-slate-50 border border-slate-200 border-l-4 border-l-blue-700 rounded-lg p-3">
              <div className="font-bold text-blue-950 mb-1">១. ទិដ្ឋភាពទូទៅ និងគោលបំណងស្នូល</div>
              <p className="text-justify leading-relaxed text-slate-800">{execSummary.executiveOverview}</p>
            </div>

            <div className="grid grid-cols-3 gap-2.5 text-center">
              <div className="bg-blue-50/70 border border-blue-200 rounded-lg p-2">
                <div className="text-[11px] font-bold text-blue-800">ថវិកាគ្រោងសរុប (N+1)</div>
                <div className="text-sm font-extrabold text-blue-950">{execSummary.budgetSummary?.totalBudgetRiel}</div>
              </div>
              <div className="bg-emerald-50/70 border border-emerald-200 rounded-lg p-2">
                <div className="text-[11px] font-bold text-emerald-800">ថវិការដ្ឋ (PB)</div>
                <div className="text-sm font-extrabold text-emerald-950">{execSummary.budgetSummary?.stateBudgetRiel}</div>
              </div>
              <div className="bg-amber-50/70 border border-amber-200 rounded-lg p-2">
                <div className="text-[11px] font-bold text-amber-800">សហគមន៍ / ឃុំ / ដៃគូ</div>
                <div className="text-sm font-extrabold text-amber-950">{execSummary.budgetSummary?.communityAndPartnerRiel}</div>
              </div>
            </div>

            {execSummary.budgetSummary?.resourceNote && (
              <div className="border border-slate-200 rounded-lg px-3 py-2 bg-white">
                <strong className="text-slate-900">យុទ្ធសាស្ត្រធនធាន៖ </strong>
                <span className="text-slate-700">{execSummary.budgetSummary.resourceNote}</span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="bg-emerald-50/40 border border-emerald-200 rounded-lg p-3">
                <div className="font-bold text-emerald-900 mb-1.5">២. ចំណុចខ្លាំង និងវឌ្ឍនភាពគន្លឹះ</div>
                <ul className="list-disc list-inside space-y-1 text-slate-800">
                  {execSummary.keyStrengths?.map((item, i) => <li key={i}>{item}</li>)}
                </ul>
              </div>
              <div className="bg-amber-50/40 border border-amber-200 rounded-lg p-3">
                <div className="font-bold text-amber-900 mb-1.5">៣. បញ្ហាប្រឈមអាទិភាពត្រូវដោះស្រាយ</div>
                <ul className="list-disc list-inside space-y-1 text-slate-800">
                  {execSummary.criticalChallenges?.map((item, i) => <li key={i}>{item}</li>)}
                </ul>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="bg-white border border-slate-200 rounded-lg p-3">
                <div className="font-bold text-blue-900 mb-1.5">៤. អាទិភាពយុទ្ធសាស្ត្រ និងសកម្មភាពស្នូល</div>
                <ul className="list-disc list-inside space-y-1 text-slate-800">
                  {execSummary.strategicPriorities?.map((item, i) => <li key={i}>{item}</li>)}
                </ul>
              </div>
              <div className="bg-white border border-slate-200 rounded-lg p-3">
                <div className="font-bold text-teal-900 mb-1.5">៥. លទ្ធផលសមិទ្ធកម្មរំពឹងទុក</div>
                <ul className="list-disc list-inside space-y-1 text-slate-800">
                  {execSummary.expectedOutcomes?.map((item, i) => <li key={i}>{item}</li>)}
                </ul>
              </div>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800">
              <strong className="text-slate-900">៦. សេចក្តីសន្និដ្ឋាន និងការប្តេជ្ញាចិត្ត៖ </strong>
              {execSummary.closingStatement}
            </div>
          </div>
        </div>
      )}

      {/* Main Formal Document Container */}
      <div className="bg-white p-8 sm:p-14 shadow-lg border border-slate-200 rounded-2xl print:shadow-none print:border-none print:p-0 print:m-0 font-kantumruy text-slate-900 leading-relaxed text-sm">
        {/* Official Cambodian Administrative Header */}
        <div className="flex flex-col items-center justify-center text-center pb-6 border-b-2 border-slate-900 mb-8">
          <h3 className="font-moul text-base sm:text-lg text-slate-900 tracking-wide mb-1">
            ព្រះរាជាណាចក្រកម្ពុជា
          </h3>
          <h4 className="font-moul text-sm sm:text-base text-slate-800 tracking-wider mb-2">
            ជាតិ សាសនា ព្រះមហាក្សត្រ
          </h4>
          <div className="w-24 h-0.5 bg-slate-800 mx-auto mb-6"></div>

        <div className="w-full flex items-start justify-between text-xs text-left mb-6">
          <div>
            <p className="font-bold">ក្រសួងអប់រំ យុវជន និងកីឡា</p>
            <p>{plan.location}</p>
            <p className="font-semibold text-blue-900">{plan.schoolName}</p>
          </div>
          <div className="text-right">
            <p>កាលបរិច្ឆេទ៖ {plan.createdDate}</p>
            <p>កម្រិត៖ {plan.schoolType}</p>
          </div>
        </div>

        {/* Document Title */}
        <div className="my-4 text-center">
          <h1 className="font-moul text-xl sm:text-2xl text-blue-900 mb-2">
            {plan.title}
          </h1>
          <p className="text-sm font-semibold text-slate-700">
            {plan.subtitle}
          </p>
          <p className="text-xs text-slate-600 mt-1 font-medium bg-blue-50/80 inline-block px-3 py-1 rounded-full border border-blue-200">
            {plan.academicYear}
          </p>
        </div>
      </div>

      {/* Chapters Content */}
      <div className="space-y-8">
        {plan.sections.map((section) => (
          <section key={section.id} className="space-y-4">
            {/* Chapter Header */}
            <div className="border-b border-slate-300 pb-1.5 flex items-baseline gap-2">
              <h2 className="font-bold text-base sm:text-lg text-blue-950">
                {section.code}. {section.title}
              </h2>
            </div>

            {/* Chapter Content */}
            {section.content && (
              <div className="whitespace-pre-line text-slate-800 text-justify leading-relaxed">
                {section.content}
              </div>
            )}

            {/* Subsections if any */}
            {section.subsections && section.subsections.length > 0 && (
              <div className="space-y-5 pl-3 border-l-2 border-slate-200 mt-3">
                {section.subsections.map((sub) => (
                  <div key={sub.id} className="space-y-3">
                    <h3 className="font-semibold text-sm sm:text-base text-slate-900 flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-blue-600"></span>
                      <span>{sub.code}. {sub.title}</span>
                    </h3>

                    {sub.content && (
                      <p className="text-xs text-slate-600 italic">
                        {sub.content}
                      </p>
                    )}

                    {/* Subsection items */}
                    {sub.items && sub.items.length > 0 && (
                      <div className="grid grid-cols-1 gap-3.5 pl-3">
                        {sub.items.map((item) => (
                          <div key={item.id} className="bg-slate-50/70 p-3 rounded-xl border border-slate-200/80 text-xs sm:text-sm">
                            <h4 className="font-bold text-slate-900 mb-1.5 text-blue-900">
                              • {item.title}
                            </h4>
                            <div className="whitespace-pre-line text-slate-700 leading-relaxed">
                              {item.content}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* Section 4 Special: Standards & Indicators Budget Planning Table */}
            {section.id === 'sec-4' && plan.standardTargets && plan.standardTargets.length > 0 && (
              <div className="mt-4 overflow-x-auto">
                <table className="w-full text-left text-xs border border-slate-300 border-collapse">
                  <thead>
                    <tr className="bg-slate-100 font-bold border-b border-slate-300 text-slate-800">
                      <th rowSpan={2} className="p-2 border border-slate-300 text-center w-10">ល.រ</th>
                      <th rowSpan={2} className="p-2 border border-slate-300">ស្តង់ដា និងសូចនាករ</th>
                      <th rowSpan={2} className="p-2 border border-slate-300 text-center w-12">ឯកតា</th>
                      <th rowSpan={2} className="p-2 border border-slate-300 text-center w-24">
                        លទ្ធផលសូចនាករ<br/>ឆ្នាំបច្ចុប្បន្ន(N)
                      </th>
                      <th rowSpan={2} className="p-2 border border-slate-300 text-center w-24">
                        គោលដៅសូចនាករ<br/>គ្រោងថវិកា (N+1)
                      </th>
                      <th colSpan={3} className="p-1.5 border border-slate-300 text-center bg-blue-50 text-blue-900">
                        ឆ្នាំគ្រោងថវិកា (ឆ្នាំ N+1)
                      </th>
                    </tr>
                    <tr className="bg-slate-50 font-semibold border-b border-slate-300 text-center text-slate-700">
                      <th className="p-1.5 border border-slate-300 w-24">ថវិការដ្ឋ</th>
                      <th className="p-1.5 border border-slate-300 w-24">ថវិកាក្រៅពីរដ្ឋ</th>
                      <th className="p-1.5 border border-slate-300 w-24 bg-emerald-50 text-emerald-950 font-bold">ថវិកាសរុប</th>
                    </tr>
                    <tr className="bg-amber-50 font-bold border-b-2 border-slate-400">
                      <th colSpan={5} className="p-2 border border-slate-300 text-right uppercase">
                        ថវិកាសរុបទាំងអស់ (Grand Total)៖
                      </th>
                      <td className="p-2 border border-slate-300 text-right font-mono">
                        {plan.standardTargets.reduce((acc, s) => acc + s.rows.reduce((rA, r) => rA + (r.isCategoryHeader ? 0 : (r.stateBudget || 0)), 0), 0).toLocaleString()}
                      </td>
                      <td className="p-2 border border-slate-300 text-right font-mono">-</td>
                      <td className="p-2 border border-slate-300 text-right font-mono bg-emerald-100 text-emerald-950 font-bold">
                        {plan.standardTargets.reduce((acc, s) => acc + s.rows.reduce((rA, r) => rA + (r.isCategoryHeader ? 0 : (r.stateBudget || 0) + (r.nonStateBudget || 0)), 0), 0).toLocaleString()}
                      </td>
                    </tr>
                  </thead>
                  <tbody>
                    {plan.standardTargets.map((std) => {
                      const stdState = std.rows.reduce((sum, r) => sum + (r.isCategoryHeader ? 0 : (r.stateBudget || 0)), 0);
                      const stdTotal = std.rows.reduce((sum, r) => sum + (r.isCategoryHeader ? 0 : (r.stateBudget || 0) + (r.nonStateBudget || 0)), 0);
                      return (
                        <React.Fragment key={std.id}>
                          <tr className="bg-blue-900 text-white font-bold border-t border-b border-blue-950">
                            <td colSpan={3} className="p-2 border border-blue-800">
                              {std.code}៖ {std.title} ({std.subtitle})
                            </td>
                            <td className="p-2 border border-blue-800 text-center">-</td>
                            <td className="p-2 border border-blue-800 text-center">-</td>
                            <td className="p-2 border border-blue-800 text-right font-mono">{stdState.toLocaleString()}</td>
                            <td className="p-2 border border-blue-800 text-right font-mono">-</td>
                            <td className="p-2 border border-blue-800 text-right font-mono font-bold">{stdTotal.toLocaleString()}</td>
                          </tr>
                          {std.rows.map((row) => {
                            if (row.isCategoryHeader) {
                              return (
                                <tr key={row.id} className="bg-slate-100 font-bold border-b border-slate-300 text-slate-900">
                                  <td className="p-1.5 border border-slate-300 text-center">{row.code}</td>
                                  <td colSpan={2} className="p-1.5 border border-slate-300">{row.title}</td>
                                  <td className="p-1.5 border border-slate-300 text-center text-slate-400">-</td>
                                  <td className="p-1.5 border border-slate-300 text-center text-slate-400">-</td>
                                  <td className="p-1.5 border border-slate-300 text-right font-mono">
                                    {row.stateBudget > 0 ? row.stateBudget.toLocaleString() : '-'}
                                  </td>
                                  <td className="p-1.5 border border-slate-300 text-right font-mono">-</td>
                                  <td className="p-1.5 border border-slate-300 text-right font-mono font-bold">
                                    {row.stateBudget > 0 ? row.stateBudget.toLocaleString() : '-'}
                                  </td>
                                </tr>
                              );
                            }
                            return (
                              <tr key={row.id} className="border-b border-slate-200">
                                <td className="p-1.5 border border-slate-300 text-center text-slate-600">{row.code}</td>
                                <td className="p-1.5 border border-slate-300">{row.title}</td>
                                <td className="p-1.5 border border-slate-300 text-center">{row.unit}</td>
                                <td className="p-1.5 border border-slate-300 text-center font-medium">{row.currentN || '-'}</td>
                                <td className="p-1.5 border border-slate-300 text-center font-bold text-blue-900">{row.targetN1 || '-'}</td>
                                <td className="p-1.5 border border-slate-300 text-right font-mono">
                                  {row.stateBudget ? row.stateBudget.toLocaleString() : '-'}
                                </td>
                                <td className="p-1.5 border border-slate-300 text-right font-mono">
                                  {row.nonStateBudget ? row.nonStateBudget.toLocaleString() : '-'}
                                </td>
                                <td className="p-1.5 border border-slate-300 text-right font-mono font-semibold text-emerald-800">
                                  {((row.stateBudget || 0) + (row.nonStateBudget || 0)).toLocaleString()}
                                </td>
                              </tr>
                            );
                          })}
                        </React.Fragment>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {/* Section 5 Special: Action Matrix Table (Official 71 Activities Table) */}
            {section.id === 'sec-5' && (
              <div className="mt-4 overflow-x-auto">
                {plan.chapterFiveActions && plan.chapterFiveActions.length > 0 ? (
                  <table className="w-full text-left text-xs border border-slate-300 border-collapse">
                    <thead>
                      <tr className="bg-slate-100 font-bold border-b border-slate-300 text-center text-slate-800">
                        <th rowSpan={3} className="p-2 border border-slate-300 w-10">ល.រ</th>
                        <th rowSpan={3} className="p-2 border border-slate-300 min-w-[200px] text-left">
                          លទ្ធផលរំពឹងទុក<br/>(តាមស្តង់ដា និងសកម្មភាពគន្លឹះ)
                        </th>
                        <th rowSpan={3} className="p-2 border border-slate-300 min-w-[260px] text-left">
                          សកម្មភាព (៧១)
                        </th>
                        <th colSpan={4} className="p-1 border border-slate-300 bg-sky-50 text-sky-950 font-bold">
                          ក្របខណ្ឌពេលវេលា (ត្រីមាស)
                        </th>
                        <th rowSpan={2} className="p-2 border border-slate-300 min-w-[120px]">
                          អ្នកទទួល<br/>ខុសត្រូវ
                        </th>
                        <th colSpan={3} className="p-1 border border-slate-300 bg-indigo-50 text-indigo-950 font-bold">
                          ប្រភពធនធាន
                        </th>
                        <th rowSpan={2} className="p-2 border border-slate-300 w-24 bg-emerald-50 text-emerald-950 font-bold">
                          ថវិកាសរុប
                        </th>
                      </tr>
                      <tr className="bg-slate-50 font-semibold border-b border-slate-300 text-center text-slate-700">
                        <th className="p-1 border border-slate-300 w-7">1</th>
                        <th className="p-1 border border-slate-300 w-7">2</th>
                        <th className="p-1 border border-slate-300 w-7">3</th>
                        <th className="p-1 border border-slate-300 w-7">4</th>

                        <th className="p-1 border border-slate-300 w-20">រដ្ឋ (១)</th>
                        <th className="p-1 border border-slate-300 w-20">សហគមន៍ (២)</th>
                        <th className="p-1 border border-slate-300 w-20">ដៃគូ (៣)</th>
                      </tr>
                      <tr className="bg-slate-100 text-slate-500 text-[10px] border-b-2 border-slate-400 text-center font-mono">
                        <td className="p-0.5 border border-slate-300">Q1</td>
                        <td className="p-0.5 border border-slate-300">Q2</td>
                        <td className="p-0.5 border border-slate-300">Q3</td>
                        <td className="p-0.5 border border-slate-300">Q4</td>
                        <td className="p-0.5 border border-slate-300 font-sans text-slate-700">តួនាទី</td>
                        <td className="p-0.5 border border-slate-300">1</td>
                        <td className="p-0.5 border border-slate-300">2</td>
                        <td className="p-0.5 border border-slate-300">3</td>
                        <td className="p-0.5 border border-slate-300 font-bold text-emerald-900 bg-emerald-100">4=(1+2+3)</td>
                      </tr>
                    </thead>
                    <tbody>
                      {plan.chapterFiveActions.map((group) => {
                        const groupState = group.items.reduce((s, i) => s + (i.stateBudget || 0), 0);
                        const groupTotal = group.items.reduce((s, i) => s + (i.totalBudget || 0), 0);
                        return (
                          <React.Fragment key={group.id}>
                            <tr className="bg-blue-900 text-white font-bold border-t border-b border-blue-950">
                              <td colSpan={3} className="p-2 border border-blue-800">
                                {group.standardTitle}
                              </td>
                              <td colSpan={4} className="p-1 border border-blue-800 text-center text-blue-200">៤ ត្រីមាស</td>
                              <td className="p-1 border border-blue-800 text-center text-blue-200">-</td>
                              <td className="p-1 border border-blue-800 text-right font-mono">{groupState.toLocaleString()}</td>
                              <td className="p-1 border border-blue-800 text-center text-blue-200">-</td>
                              <td className="p-1 border border-blue-800 text-center text-blue-200">-</td>
                              <td className="p-1 border border-blue-800 text-right font-mono font-bold">{groupTotal.toLocaleString()}</td>
                            </tr>
                            {group.items.map((item) => (
                              <tr key={item.id} className="border-b border-slate-200">
                                <td className="p-1.5 border border-slate-300 text-center font-semibold text-slate-700">{item.code}</td>
                                <td className="p-1.5 border border-slate-300 font-medium">
                                  <span className="text-[10px] text-blue-800 block font-semibold">{item.categoryTitle}</span>
                                  {item.expectedOutcome}
                                </td>
                                <td className="p-1.5 border border-slate-300 text-slate-700 whitespace-pre-line text-xs">{item.activities}</td>
                                <td className="p-1 border border-slate-300 text-center font-bold text-blue-800">{item.q1 ? '✓' : ''}</td>
                                <td className="p-1 border border-slate-300 text-center font-bold text-blue-800">{item.q2 ? '✓' : ''}</td>
                                <td className="p-1 border border-slate-300 text-center font-bold text-blue-800">{item.q3 ? '✓' : ''}</td>
                                <td className="p-1 border border-slate-300 text-center font-bold text-blue-800">{item.q4 ? '✓' : ''}</td>
                                <td className="p-1.5 border border-slate-300 text-slate-700">{item.responsiblePerson}</td>
                                <td className="p-1.5 border border-slate-300 text-right font-mono">{item.stateBudget ? item.stateBudget.toLocaleString() : '-'}</td>
                                <td className="p-1.5 border border-slate-300 text-right font-mono">{item.communityBudget ? item.communityBudget.toLocaleString() : '-'}</td>
                                <td className="p-1.5 border border-slate-300 text-right font-mono">{item.partnerBudget ? item.partnerBudget.toLocaleString() : '-'}</td>
                                <td className="p-1.5 border border-slate-300 text-right font-mono font-semibold text-emerald-800">{item.totalBudget ? item.totalBudget.toLocaleString() : '-'}</td>
                              </tr>
                            ))}
                          </React.Fragment>
                        );
                      })}
                    </tbody>
                  </table>
                ) : plan.actionMatrix && plan.actionMatrix.length > 0 ? (
                  <table className="w-full text-left text-xs border border-slate-300 border-collapse">
                    <thead className="bg-slate-100 font-semibold border-b border-slate-300 text-slate-800">
                      <tr>
                        <th className="p-2 border border-slate-300 text-center w-10">ល.រ</th>
                        <th className="p-2 border border-slate-300">សកម្មភាពអនុវត្ត</th>
                        <th className="p-2 border border-slate-300">សូចនាករវាស់វែង</th>
                        <th className="p-2 border border-slate-300 text-center w-24">កាលវិភាគ</th>
                        <th className="p-2 border border-slate-300 text-right w-28">ថវិកា</th>
                        <th className="p-2 border border-slate-300 w-28">ប្រភពថវិកា</th>
                        <th className="p-2 border border-slate-300 w-32">អ្នកទទួលខុសត្រូវ</th>
                        <th className="p-2 border border-slate-300 text-center w-28">ស្ថានភាព</th>
                      </tr>
                    </thead>
                    <tbody>
                      {plan.actionMatrix.map((act, index) => (
                        <tr key={act.id} className="border-b border-slate-200">
                          <td className="p-2 border border-slate-300 text-center font-medium">{index + 1}</td>
                          <td className="p-2 border border-slate-300 font-medium">{act.activity}</td>
                          <td className="p-2 border border-slate-300 text-slate-600">{act.indicator}</td>
                          <td className="p-2 border border-slate-300 text-center">{act.timeline}</td>
                          <td className="p-2 border border-slate-300 text-right font-semibold text-emerald-800">{act.budget}</td>
                          <td className="p-2 border border-slate-300 text-slate-600">{act.budgetSource}</td>
                          <td className="p-2 border border-slate-300 text-slate-600">{act.responsiblePerson}</td>
                          <td className="p-2 border border-slate-300 text-center">
                            <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-medium ${
                              act.status === 'completed'
                                ? 'bg-emerald-100 text-emerald-800'
                                : act.status === 'in_progress'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-slate-100 text-slate-700'
                            }`}>
                              {act.status === 'completed' ? 'សម្រេចបាន' : act.status === 'in_progress' ? 'កំពុងអនុវត្ត' : 'មិនទាន់'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                ) : null}
              </div>
            )}
          </section>
        ))}
      </div>

      {/* Official Signatures & Endorsement Block */}
      <div className="mt-14 pt-8 border-t border-slate-300 grid grid-cols-1 sm:grid-cols-3 gap-6 text-center text-xs page-break">
        <div>
          <p className="font-semibold text-slate-700">បានឃើញ និងឯកភាព</p>
          <p className="font-bold text-slate-900 mt-1">ប្រធានការិយាល័យអប់រំ យុវជន និងកីឡា</p>
          <div className="h-20 flex items-center justify-center text-slate-300">
            (ហត្ថលេខា និងត្រា)
          </div>
        </div>

        <div>
          <p className="font-semibold text-slate-700">ពិនិត្យ និងអនុម័ត</p>
          <p className="font-bold text-slate-900 mt-1">នាយកសាលារៀន</p>
          <div className="h-20 flex items-center justify-center text-slate-300">
            (ហត្ថលេខា និងត្រា)
          </div>
        </div>

        <div>
          <p className="text-slate-600 italic">ថ្ងៃទី....... ខែ....... ឆ្នាំ២០២៤</p>
          <p className="font-bold text-slate-900 mt-1">គណៈកម្មការរៀបចំផែនការ</p>
          <div className="h-20 flex items-center justify-center text-slate-300">
            (ហត្ថលេខា)
          </div>
        </div>
      </div>
      </div>
    </div>
  );
};
