import React, { useState, useEffect } from 'react';
import {
  X,
  Sparkles,
  Printer,
  Download,
  Copy,
  Check,
  CheckCircle2,
  Edit3,
  Eye,
  RefreshCw,
  FileText,
  AlertCircle,
  BookOpenCheck,
  Coins,
  Target,
  TrendingUp,
  AlertTriangle,
} from 'lucide-react';
import { ExecutiveSummaryData, PlanData } from '../types/plan';
import { safeFetchJson } from '../utils/apiHelper';
import { generateExecutiveSummaryStandaloneHtml } from '../utils/documentGenerator';
import {
  copyRichHtmlToClipboard,
  downloadFileUniversal,
  printHtmlSafely,
  sanitizeFileName,
} from '../utils/fileDownloader';

interface ExecutiveSummaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  plan: PlanData;
  onSaveSummary: (summary: ExecutiveSummaryData) => void;
}

type FocusStyle = 'standard' | 'budget_commune' | 'concise';

export const ExecutiveSummaryModal: React.FC<ExecutiveSummaryModalProps> = ({
  isOpen,
  onClose,
  plan,
  onSaveSummary,
}) => {
  const [summary, setSummary] = useState<ExecutiveSummaryData | null>(plan.executiveSummary || null);
  const [focusStyle, setFocusStyle] = useState<FocusStyle>(
    plan.executiveSummary?.focusStyle || 'standard'
  );
  const [isGenerating, setIsGenerating] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [statusFeedback, setStatusFeedback] = useState<string | null>(null);
  const [isCopied, setIsCopied] = useState(false);

  // Sync local state when modal opens or plan.executiveSummary changes
  useEffect(() => {
    if (isOpen) {
      if (plan.executiveSummary) {
        setSummary(plan.executiveSummary);
        setFocusStyle(plan.executiveSummary.focusStyle || 'standard');
      } else if (!summary && !isGenerating) {
        handleGenerateSummary('standard');
      }
    }
  }, [isOpen, plan.id]);

  if (!isOpen) return null;

  const showTempStatus = (msg: string) => {
    setStatusFeedback(msg);
    setTimeout(() => setStatusFeedback(null), 3500);
  };

  const handleGenerateSummary = async (selectedFocus: FocusStyle = focusStyle) => {
    setIsGenerating(true);
    setErrorMessage(null);
    setFocusStyle(selectedFocus);
    try {
      const data = await safeFetchJson('/api/plan/executive-summary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          plan,
          focusStyle: selectedFocus,
        }),
      });

      if (data.success && data.executiveSummary) {
        setSummary(data.executiveSummary);
        onSaveSummary(data.executiveSummary);
        showTempStatus('AI បានសង្ខេបផែនការប្រតិបត្តិទាំងមូលជា ១ ទំព័រ A4 រួចរាល់!');
      } else {
        setErrorMessage(data.error || 'មិនអាចបង្កើតសេចក្តីសង្ខេបប្រតិបត្តិបានទេ');
      }
    } catch (err: any) {
      console.error('Executive summary error:', err);
      setErrorMessage(err?.message || 'មានបញ្ហាក្នុងការតភ្ជាប់ទៅកាន់ AI');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSaveToDocument = () => {
    if (!summary) return;
    onSaveSummary(summary);
    showTempStatus('បានរក្សាទុកជាទំព័រណែនាំទី ១ នៃឯកសារផ្លូវការរួចរាល់!');
  };

  const handlePrintOnePage = () => {
    if (!summary) return;
    onSaveSummary(summary);
    const htmlDoc = generateExecutiveSummaryStandaloneHtml(plan, summary);
    printHtmlSafely(htmlDoc, () => {
      showTempStatus('បានបើកផ្ទាំងបោះពុម្ព ១ ទំព័រ A4 រួចរាល់!');
    });
  };

  const handleDownloadWord = async () => {
    if (!summary) return;
    const htmlDoc = generateExecutiveSummaryStandaloneHtml(plan, summary);
    const safeSchool = sanitizeFileName(plan.schoolName || 'សាលារៀន', 'school');
    const fileName = `Executive_Summary_1Page_${safeSchool}.doc`;
    const ok = await downloadFileUniversal({
      fileName,
      content: htmlDoc,
      contentType: 'application/msword; charset=utf-8',
    });
    if (ok) {
      showTempStatus('បានទាញយកឯកសារ Word (១ ទំព័រ) រួចរាល់!');
    } else {
      setErrorMessage('មិនអាចទាញយកដោយផ្ទាល់បានទេ សូមប្រើប៊ូតុង «ចម្លង» ឬ «បោះពុម្ព»។');
    }
  };

  const handleCopySummary = async () => {
    if (!summary) return;
    const htmlDoc = generateExecutiveSummaryStandaloneHtml(plan, summary);
    const plainText = [
      `សេចក្តីសង្ខេបប្រតិបត្តិ (EXECUTIVE SUMMARY) - ${plan.schoolName}`,
      summary.documentTitle,
      '',
      `១. ទិដ្ឋភាពទូទៅ៖\n${summary.executiveOverview}`,
      '',
      `ថវិកាគ្រោងសរុប៖ ${summary.budgetSummary.totalBudgetRiel} (ថវិការដ្ឋ៖ ${summary.budgetSummary.stateBudgetRiel}, សហគមន៍/ដៃគូ៖ ${summary.budgetSummary.communityAndPartnerRiel})`,
      '',
      `២. ចំណុចខ្លាំង៖\n${summary.keyStrengths.map((s) => `• ${s}`).join('\n')}`,
      '',
      `៣. បញ្ហាប្រឈម៖\n${summary.criticalChallenges.map((c) => `• ${c}`).join('\n')}`,
      '',
      `៤. អាទិភាពយុទ្ធសាស្ត្រ៖\n${summary.strategicPriorities.map((p) => `• ${p}`).join('\n')}`,
      '',
      `៥. លទ្ធផលរំពឹងទុក៖\n${summary.expectedOutcomes.map((o) => `• ${o}`).join('\n')}`,
      '',
      `៦. សេចក្តីសន្និដ្ឋាន៖\n${summary.closingStatement}`,
    ].join('\n');

    const ok = await copyRichHtmlToClipboard(htmlDoc, plainText);
    if (ok) {
      setIsCopied(true);
      showTempStatus('បានចម្លងសេចក្តីសង្ខេប ១ ទំព័ររួចរាល់!');
      setTimeout(() => setIsCopied(false), 3000);
    }
  };

  const updateListField = (
    field: 'keyStrengths' | 'criticalChallenges' | 'strategicPriorities' | 'expectedOutcomes',
    index: number,
    value: string
  ) => {
    if (!summary) return;
    const updated = [...summary[field]];
    updated[index] = value;
    setSummary({ ...summary, [field]: updated });
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/65 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-200 font-kantumruy">
      <div className="bg-slate-100 rounded-2xl shadow-2xl max-w-5xl w-full max-h-[94vh] flex flex-col overflow-hidden border border-slate-300 animate-in zoom-in-95 duration-200">
        
        {/* Top Header Bar */}
        <div className="bg-gradient-to-r from-blue-900 via-indigo-800 to-slate-900 text-white px-5 py-4 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white/10 rounded-xl border border-white/15">
              <Sparkles className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold tracking-tight">
                  សេចក្តីសង្ខេបប្រតិបត្តិ ១ ទំព័រដោយ AI (Executive Summary)
                </h3>
                <span className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-bold bg-amber-400/20 text-amber-200 border border-amber-300/30 rounded-full">
                  ទំព័រណែនាំ A4
                </span>
              </div>
              <p className="text-xs text-blue-100/90 mt-0.5">
                សង្ខេបខ្លឹមសារ ៦ ជំពូក ស្តង់ដារទាំង ៥ និងថវិកាសរុបទៅជាទំព័រណែនាំផ្លូវការងាយស្រួលបោះពុម្ព
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-white/80 hover:text-white hover:bg-white/15 rounded-lg transition-colors"
            title="បិទ"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* AI Control & Focus Toolbar */}
        <div className="bg-white border-b border-slate-200 px-4 sm:px-5 py-3 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-xs font-bold text-slate-600 mr-1">ទម្រង់សង្ខេប៖</span>
            {(
              [
                { id: 'standard', label: 'ស្តង់ដារក្រសួង (១ ទំព័រ A4)' },
                { id: 'budget_commune', label: 'ផ្តោតលើថវិកា & ឃុំ (CIP)' },
                { id: 'concise', label: 'សង្ខេបខ្លីបំផុត' },
              ] as { id: FocusStyle; label: string }[]
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                disabled={isGenerating}
                onClick={() => handleGenerateSummary(opt.id)}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                  focusStyle === opt.id
                    ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {summary && (
              <button
                type="button"
                onClick={() => setIsEditMode(!isEditMode)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors ${
                  isEditMode
                    ? 'bg-amber-500 text-slate-950 border-amber-600'
                    : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                }`}
              >
                {isEditMode ? <Eye className="w-3.5 h-3.5" /> : <Edit3 className="w-3.5 h-3.5 text-amber-600" />}
                <span>{isEditMode ? 'មើលទម្រង់ A4' : 'កែសម្រួលអត្ថបទ'}</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => handleGenerateSummary(focusStyle)}
              disabled={isGenerating}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white text-xs font-bold shadow-sm transition-all disabled:opacity-60"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isGenerating ? 'animate-spin' : ''}`} />
              <span>{isGenerating ? 'AI កំពុងសង្ខេប...' : summary ? 'បង្កើតឡើងវិញដោយ AI' : 'បង្កើតដោយ AI'}</span>
            </button>
          </div>
        </div>

        {/* Main Scrollable Content Area */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-6 space-y-4">
          {errorMessage && (
            <div className="max-w-4xl mx-auto p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{errorMessage}</span>
              </div>
              <button
                type="button"
                onClick={() => handleGenerateSummary(focusStyle)}
                className="px-3 py-1 bg-rose-600 text-white rounded-lg font-bold hover:bg-rose-700 shrink-0"
              >
                សាកល្បងម្ដងទៀត
              </button>
            </div>
          )}

          {statusFeedback && (
            <div className="max-w-4xl mx-auto p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-semibold flex items-center gap-2 animate-in fade-in duration-150">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{statusFeedback}</span>
            </div>
          )}

          {isGenerating ? (
            <div className="max-w-3xl mx-auto bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-4 shadow-xs">
              <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto">
                <Sparkles className="w-7 h-7 animate-pulse text-blue-600" />
              </div>
              <div className="space-y-1">
                <h4 className="text-base font-bold text-slate-900">
                  AI កំពុងអាន និងសង្ខេបផែនការប្រតិបត្តិទាំងមូល...
                </h4>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  កំពុងចម្រាញ់ជំពូកទាំង ៦ តារាងសូចនាករស្ដង់ដារទាំង ៥ និងគម្រោងថវិកា ឱ្យទៅជាសេចក្តីសង្ខេបប្រតិបត្តិ ១ ទំព័រ A4។
                </p>
              </div>
            </div>
          ) : summary ? (
            /* A4 One-Page Sheet Preview / Editor */
            <div className="max-w-[820px] mx-auto bg-white rounded-xl border border-slate-300 shadow-lg p-6 sm:p-10 text-slate-900 space-y-4">
              
              {/* Official Document Intro Header */}
              <div className="text-center border-b-2 border-blue-900 pb-3">
                <div className="font-moul text-sm sm:text-base text-blue-950">ព្រះរាជាណាចក្រកម្ពុជា</div>
                <div className="font-moul text-xs sm:text-sm text-blue-900 mt-0.5">ជាតិ សាសនា ព្រះមហាក្សត្រ</div>

                <div className="flex flex-wrap justify-between items-start text-xs text-slate-700 mt-3 text-left gap-2">
                  <div>
                    <div className="font-bold text-slate-900">ក្រសួងអប់រំ យុវជន និងកីឡា</div>
                    <div>
                      {plan.location} • <span className="font-bold text-blue-900">{plan.schoolName}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-slate-900">{plan.academicYear}</div>
                    <div>{plan.schoolType}</div>
                  </div>
                </div>

                <h2 className="font-moul text-base sm:text-lg text-blue-900 mt-4">
                  សេចក្តីសង្ខេបប្រតិបត្តិ (EXECUTIVE SUMMARY)
                </h2>
                {isEditMode ? (
                  <input
                    type="text"
                    value={summary.documentTitle}
                    onChange={(e) => setSummary({ ...summary, documentTitle: e.target.value })}
                    className="mt-1.5 w-full max-w-xl mx-auto text-center text-xs font-semibold px-3 py-1.5 rounded-lg border border-amber-300 bg-amber-50/40"
                  />
                ) : (
                  <p className="text-xs sm:text-sm font-semibold text-slate-700 mt-1">
                    {summary.documentTitle}
                  </p>
                )}
              </div>

              {/* 1. Overview */}
              <div className="bg-slate-50 border border-slate-200 border-l-4 border-l-blue-700 rounded-lg p-3.5">
                <div className="flex items-center gap-1.5 text-xs font-bold text-blue-950 mb-1">
                  <BookOpenCheck className="w-4 h-4 text-blue-700" />
                  <span>១. ទិដ្ឋភាពទូទៅ និងគោលបំណងស្នូល</span>
                </div>
                {isEditMode ? (
                  <textarea
                    rows={3}
                    value={summary.executiveOverview}
                    onChange={(e) => setSummary({ ...summary, executiveOverview: e.target.value })}
                    className="w-full text-xs p-2 rounded-lg border border-amber-300 bg-white leading-relaxed"
                  />
                ) : (
                  <p className="text-xs leading-relaxed text-slate-800 text-justify">
                    {summary.executiveOverview}
                  </p>
                )}
              </div>

              {/* 2. Budget KPI Cards */}
              <div className="space-y-2">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-center">
                  <div className="bg-blue-50/80 border border-blue-200 rounded-xl p-2.5">
                    <div className="text-[11px] font-bold text-blue-800 flex items-center justify-center gap-1">
                      <Coins className="w-3.5 h-3.5" />
                      <span>ថវិកាគ្រោងសរុប (N+1)</span>
                    </div>
                    {isEditMode ? (
                      <input
                        type="text"
                        value={summary.budgetSummary.totalBudgetRiel}
                        onChange={(e) =>
                          setSummary({
                            ...summary,
                            budgetSummary: { ...summary.budgetSummary, totalBudgetRiel: e.target.value },
                          })
                        }
                        className="mt-1 w-full text-center text-xs font-bold p-1 rounded border border-amber-300 bg-white"
                      />
                    ) : (
                      <div className="text-sm font-extrabold text-blue-950 mt-0.5">
                        {summary.budgetSummary.totalBudgetRiel}
                      </div>
                    )}
                  </div>

                  <div className="bg-emerald-50/80 border border-emerald-200 rounded-xl p-2.5">
                    <div className="text-[11px] font-bold text-emerald-800">ថវិការដ្ឋ (PB)</div>
                    {isEditMode ? (
                      <input
                        type="text"
                        value={summary.budgetSummary.stateBudgetRiel}
                        onChange={(e) =>
                          setSummary({
                            ...summary,
                            budgetSummary: { ...summary.budgetSummary, stateBudgetRiel: e.target.value },
                          })
                        }
                        className="mt-1 w-full text-center text-xs font-bold p-1 rounded border border-amber-300 bg-white"
                      />
                    ) : (
                      <div className="text-sm font-extrabold text-emerald-950 mt-0.5">
                        {summary.budgetSummary.stateBudgetRiel}
                      </div>
                    )}
                  </div>

                  <div className="bg-amber-50/80 border border-amber-200 rounded-xl p-2.5">
                    <div className="text-[11px] font-bold text-amber-800">សហគមន៍ / ឃុំ / ដៃគូ</div>
                    {isEditMode ? (
                      <input
                        type="text"
                        value={summary.budgetSummary.communityAndPartnerRiel}
                        onChange={(e) =>
                          setSummary({
                            ...summary,
                            budgetSummary: {
                              ...summary.budgetSummary,
                              communityAndPartnerRiel: e.target.value,
                            },
                          })
                        }
                        className="mt-1 w-full text-center text-xs font-bold p-1 rounded border border-amber-300 bg-white"
                      />
                    ) : (
                      <div className="text-sm font-extrabold text-amber-950 mt-0.5">
                        {summary.budgetSummary.communityAndPartnerRiel}
                      </div>
                    )}
                  </div>
                </div>

                <div className="bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-700">
                  <span className="font-bold text-slate-900">យុទ្ធសាស្ត្រធនធាន៖ </span>
                  {isEditMode ? (
                    <input
                      type="text"
                      value={summary.budgetSummary.resourceNote}
                      onChange={(e) =>
                        setSummary({
                          ...summary,
                          budgetSummary: { ...summary.budgetSummary, resourceNote: e.target.value },
                        })
                      }
                      className="mt-1 w-full text-xs p-1.5 rounded border border-amber-300 bg-amber-50/40"
                    />
                  ) : (
                    <span>{summary.budgetSummary.resourceNote}</span>
                  )}
                </div>
              </div>

              {/* 3. Strengths & Challenges 2-column grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="bg-emerald-50/50 border border-emerald-200 rounded-xl p-3.5">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-900 mb-2">
                    <TrendingUp className="w-4 h-4 text-emerald-700" />
                    <span>២. ចំណុចខ្លាំង និងវឌ្ឍនភាពគន្លឹះ</span>
                  </div>
                  <ul className="space-y-1.5 text-xs text-slate-800 list-disc list-inside">
                    {summary.keyStrengths.map((item, idx) =>
                      isEditMode ? (
                        <li key={idx} className="list-none">
                          <input
                            type="text"
                            value={item}
                            onChange={(e) => updateListField('keyStrengths', idx, e.target.value)}
                            className="w-full text-xs p-1.5 rounded border border-amber-300 bg-white"
                          />
                        </li>
                      ) : (
                        <li key={idx} className="leading-relaxed">
                          {item}
                        </li>
                      )
                    )}
                  </ul>
                </div>

                <div className="bg-amber-50/50 border border-amber-200 rounded-xl p-3.5">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900 mb-2">
                    <AlertTriangle className="w-4 h-4 text-amber-700" />
                    <span>៣. បញ្ហាប្រឈមអាទិភាពត្រូវដោះស្រាយ</span>
                  </div>
                  <ul className="space-y-1.5 text-xs text-slate-800 list-disc list-inside">
                    {summary.criticalChallenges.map((item, idx) =>
                      isEditMode ? (
                        <li key={idx} className="list-none">
                          <input
                            type="text"
                            value={item}
                            onChange={(e) => updateListField('criticalChallenges', idx, e.target.value)}
                            className="w-full text-xs p-1.5 rounded border border-amber-300 bg-white"
                          />
                        </li>
                      ) : (
                        <li key={idx} className="leading-relaxed">
                          {item}
                        </li>
                      )
                    )}
                  </ul>
                </div>
              </div>

              {/* 4. Strategic Priorities & Expected Outcomes 2-column grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="bg-white border border-slate-200 rounded-xl p-3.5">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-blue-900 mb-2">
                    <Target className="w-4 h-4 text-blue-700" />
                    <span>៤. អាទិភាពយុទ្ធសាស្ត្រ និងសកម្មភាពស្នូល</span>
                  </div>
                  <ul className="space-y-1.5 text-xs text-slate-800 list-disc list-inside">
                    {summary.strategicPriorities.map((item, idx) =>
                      isEditMode ? (
                        <li key={idx} className="list-none">
                          <input
                            type="text"
                            value={item}
                            onChange={(e) => updateListField('strategicPriorities', idx, e.target.value)}
                            className="w-full text-xs p-1.5 rounded border border-amber-300 bg-white"
                          />
                        </li>
                      ) : (
                        <li key={idx} className="leading-relaxed">
                          {item}
                        </li>
                      )
                    )}
                  </ul>
                </div>

                <div className="bg-white border border-slate-200 rounded-xl p-3.5">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-teal-900 mb-2">
                    <CheckCircle2 className="w-4 h-4 text-teal-700" />
                    <span>៥. លទ្ធផលសមិទ្ធកម្មរំពឹងទុក</span>
                  </div>
                  <ul className="space-y-1.5 text-xs text-slate-800 list-disc list-inside">
                    {summary.expectedOutcomes.map((item, idx) =>
                      isEditMode ? (
                        <li key={idx} className="list-none">
                          <input
                            type="text"
                            value={item}
                            onChange={(e) => updateListField('expectedOutcomes', idx, e.target.value)}
                            className="w-full text-xs p-1.5 rounded border border-amber-300 bg-white"
                          />
                        </li>
                      ) : (
                        <li key={idx} className="leading-relaxed">
                          {item}
                        </li>
                      )
                    )}
                  </ul>
                </div>
              </div>

              {/* 5. Closing Statement & Signature */}
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-xs text-slate-800">
                <span className="font-bold text-slate-900">៦. សេចក្តីសន្និដ្ឋាន និងការប្តេជ្ញាចិត្ត៖ </span>
                {isEditMode ? (
                  <textarea
                    rows={2}
                    value={summary.closingStatement}
                    onChange={(e) => setSummary({ ...summary, closingStatement: e.target.value })}
                    className="mt-1 w-full text-xs p-2 rounded border border-amber-300 bg-white"
                  />
                ) : (
                  <span>{summary.closingStatement}</span>
                )}
              </div>

              <div className="pt-3 border-t border-slate-200 grid grid-cols-2 gap-6 text-center text-xs text-slate-700">
                <div>
                  <div>បានឃើញ និងឯកភាព</div>
                  <div className="font-bold text-slate-900 mt-1">ប្រធានការិយាល័យអប់រំ យុវជន និងកីឡា</div>
                </div>
                <div>
                  <div>{plan.createdDate}</div>
                  <div className="font-bold text-slate-900 mt-1">នាយក / នាយិកាសាលា</div>
                </div>
              </div>
            </div>
          ) : (
            <div className="max-w-2xl mx-auto bg-white rounded-2xl border border-slate-200 p-10 text-center space-y-4">
              <FileText className="w-10 h-10 text-blue-600 mx-auto" />
              <p className="text-sm font-bold text-slate-800">
                មិនទាន់មានសេចក្តីសង្ខេបប្រតិបត្តិនៅឡើយទេ
              </p>
              <button
                type="button"
                onClick={() => handleGenerateSummary(focusStyle)}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md"
              >
                បង្កើតសេចក្តីសង្ខេបដោយ AI ឥឡូវនេះ
              </button>
            </div>
          )}
        </div>

        {/* Bottom Action Footer */}
        <div className="bg-white border-t border-slate-200 px-4 sm:px-5 py-3 flex flex-wrap items-center justify-between gap-2.5 shrink-0">
          <div className="text-[11px] text-slate-500">
            * សេចក្តីសង្ខេបនេះត្រូវបានរៀបចំឱ្យសមល្មម ១ ទំព័រ A4 ដើម្បីប្រើជាទំព័រណែនាំផ្លូវការ
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleCopySummary}
              disabled={!summary || isGenerating}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold border border-slate-200 transition-colors disabled:opacity-50"
            >
              {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{isCopied ? 'បានចម្លង' : 'ចម្លង'}</span>
            </button>

            <button
              type="button"
              onClick={handleDownloadWord}
              disabled={!summary || isGenerating}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-800 text-xs font-bold border border-indigo-200 transition-colors disabled:opacity-50"
            >
              <Download className="w-3.5 h-3.5 text-indigo-600" />
              <span>Word (.doc)</span>
            </button>

            <button
              type="button"
              onClick={handleSaveToDocument}
              disabled={!summary || isGenerating}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition-colors disabled:opacity-50"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>ភ្ជាប់ជាទំព័រទី១ ក្នុងឯកសារ</span>
            </button>

            <button
              type="button"
              onClick={handlePrintOnePage}
              disabled={!summary || isGenerating}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-500/20 transition-all disabled:opacity-50"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>បោះពុម្ព ១ ទំព័រ (Print)</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
