import React, { useState } from 'react';
import { 
  Building2, 
  Upload, 
  Sparkles, 
  X, 
  FileText, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw, 
  Layers, 
  ThumbsUp, 
  AlertTriangle,
  Compass,
  ArrowRight
} from 'lucide-react';
import { SchoolContextProfile } from '../types/plan';
import { safeFetchJson } from '../utils/apiHelper';

interface SchoolContextModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentProfile?: SchoolContextProfile;
  schoolName: string;
  onSaveProfile: (profile: SchoolContextProfile) => void;
}

const CONTEXT_PRESETS: { label: string; profile: SchoolContextProfile }[] = [
  {
    label: 'សាលាបឋមសិក្សាជនបទ / ពាក់កណ្តាលដាច់ស្រយាល',
    profile: {
      summary: 'សាលាបឋមសិក្សាស្ថិតនៅតំបន់ជនបទពាក់កណ្តាលដាច់ស្រយាល សហគមន៍កសិករធ្វើស្រែចម្ការ។ សាលាមានផ្ទៃដីធំទូលាយ មានបរិស្ថានស្អាត និងការចូលរួមពីសហគមន៍ ប៉ុន្តែប្រឈមនឹងការខ្វះបន្ទប់កុំព្យូទ័រ សៀវភៅអាន និងមាតាបិតាចំណាកស្រុក។',
      strengths: `• គ្រូបង្រៀនមានការប្តេជ្ញាចិត្តខ្ពស់ រស់នៅជាប់មូលដ្ឋាន និងស្រឡាញ់សិស្ស
• គណៈកម្មការទ្រទ្រង់សាលា (SSC) និងព្រះសង្ឃនៅវត្តជិតខាងជួយឧបត្ថម្ភជាប្រចាំ
• មានទីធ្លាធំទូលាយ មានសួនបន្លែសាលា និងបរិស្ថានបៃតង
• អត្រាចូលរៀនរបស់កុមារក្នុងភូមិសម្រេចបាន ៩៨%`,
      challenges: `• មាតាបិតាជាង ៣៥% ចំណាកស្រុកទៅធ្វើការនៅក្រៅប្រទេស/ភ្នំពេញ ទុកកូនឱ្យនៅជាមួយចាស់ជរា
• កង្វះខាតសៀវភៅអានថ្មីៗ និងសម្ភារបច្ចេកវិទ្យា (គ្មានកុំព្យូទ័រ និងអ៊ីនធឺណិត)
• សិស្សមួយចំនួនបោះបង់ការសិក្សានៅរដូវច្រូតកាត់ និងរដូវដាំដុះ
• សម្ភារឧបទេសបង្រៀនវិទ្យាសាស្ត្រ និងគណិតវិទ្យានៅខ្វះខាតច្រើន`,
      uniqueEnvironment: 'សាលាបឋមសិក្សាកម្រិត ១-៦ មានសិស្ស ៤២០ នាក់ គ្រូបង្រៀន ១៤ នាក់ ស្ថិតនៅចម្ងាយ ៤៥ គីឡូម៉ែត្រពីទីរួមខេត្ត',
      opportunities: 'សហការជាមួយអង្គការដៃគូដើម្បីសាងសង់បណ្ណាល័យស្ដង់ដារ បង្កើតកម្មវិធីអាហារូបត្ថម្ភសាលារៀន និងវគ្គបំប៉នសិស្សរៀនយឺត',
      fileName: 'preset_rural_primary.txt',
      lastUpdated: 'ខែវិច្ឆិកា ឆ្នាំ២០២៤'
    }
  },
  {
    label: 'វិទ្យាល័យធនធាន / ទីប្រជុំជន (STEM Focus)',
    profile: {
      summary: 'វិទ្យាល័យធនធានកម្រិតអនុវិទ្យាល័យ និងវិទ្យាល័យ មានសិស្សច្រើនមកពីឃុំនានា។ សាលាមានអគារសិក្សាគ្រប់គ្រាន់ បន្ទប់ពិសោធន៍វិទ្យាសាស្ត្រ និងគ្រូបង្រៀនកម្រិតឧត្តម ប៉ុន្តែប្រឈមការគ្រប់គ្រងវិន័យ ភាពយឺតយ៉ាវនៃបច្ចេកវិទ្យាឌីជីថល និងសិស្សខ្សោយគណិតវិទ្យា។',
      strengths: `• ក្រុមគ្រូបង្រៀនកម្រិតឧត្តមមានសមត្ថភាពខ្ពស់ និងឆ្លងកាត់ការបណ្តុះបណ្តាល STEM
• មានបន្ទប់ពិសោធន៍រូបវិទ្យា គីមីវិទ្យា និងជីវវិទ្យាដំណើរការល្អ
• សិស្សជាប់សញ្ញាបត្របាក់ឌុបនិទ្ទេស A និង B មានកំណើនជារៀងរាល់ឆ្នាំ
• មានបណ្ណាល័យឌីជីថល និងការតភ្ជាប់អ៊ីនធឺណិតល្បឿនលឿន`,
      challenges: `• ចំនួនសិស្សក្នុងមួយថ្នាក់មានកម្រិតខ្ពស់ (៤៥-៥០ នាក់/បន្ទប់)
• សិស្សមួយចំនួនប្រើប្រាស់ទូរស័ព្ទដៃខុសគោលដៅក្នុងម៉ោងសិក្សា ប៉ះពាល់វិន័យ
• កង្វះសម្ភារអនុវត្តជាក់ស្តែងសម្រាប់សិស្សរៀនមុខវិជ្ជាព័ត៌មានវិទ្យា និងមនុស្សយន្ត (Robotics)
• គម្លាតចំណេះដឹងរវាងសិស្សមកពីសាលាបឋមជនបទ និងទីប្រជុំជននៅមានកម្រិតធំ`,
      uniqueEnvironment: 'វិទ្យាល័យធនធានកម្រិត ៧-១២ សិស្សសរុប ១,៨៥០ នាក់ (ស្រី ៩8០ នាក់) គ្រូបង្រៀន ៨៦ នាក់ ស្ថិតនៅទីរួមស្រុក',
      opportunities: 'ពង្រីកក្លឹបសិក្សា STEM និងក្លឹបយុវជនកាកបាទក្រហម ពង្រឹងការបង្រៀនគរុកោសល្យថ្មី និងការណែនាំអាជីពសាកលវិទ្យាល័យ',
      fileName: 'preset_highschool_resource.txt',
      lastUpdated: 'ខែវិច្ឆិកា ឆ្នាំ២០២៤'
    }
  },
  {
    label: 'សាលារៀនគំរូស្តង់ដា (Model School SBM)',
    profile: {
      summary: 'សាលារៀនអនុវត្តការគ្រប់គ្រងតាមសាលារៀន (School-Based Management) កម្រិតគំរូរបស់ក្រសួងអប់រំ យុវជន និងកីឡា។ សាលាមានស្ដង់ដាគ្រប់គ្រងច្បាស់លាស់ គណនេយ្យភាពខ្ពស់ និងការចូលរួមពីអាណាព្យាបាលល្អណាស់។',
      strengths: `• គណៈគ្រប់គ្រងសាលាមានភាពជាអ្នកដឹកនាំគរុកោសល្យ និងការគ្រប់គ្រងហិរញ្ញវត្ថុតម្លាភាព
• ការអនុវត្តស្តង់ដាសាលារៀនគំរូទាំង ៥ សម្រេចបានលទ្ធផលខ្ពស់
• មាតាបិតាសិស្ស ៩៥% ចូលរួមតាមដានការសិក្សារបស់កូនជាប្រចាំ
• បរិស្ថានសាលារៀនស្អាត បៃតង គ្មានសំរាម និងមានសួនកុមារមេត្រីភាព`,
      challenges: `• ការរក្សាស្ថិរភាព និងនិរន្តរភាពគុណភាពបង្រៀនក្នុងពេលគ្រូចាស់ៗចូលនិវត្តន៍
• តម្រូវការថវិកាបន្ថែមសម្រាប់ថែទាំសម្ភារបច្ចេកវិទ្យា និងបន្ទប់រៀនឆ្លាតវៃ (Smart Classrooms)
• សិស្សមួយចំនួននៅតែមានបញ្ហាសុខភាពផ្លូវចិត្ត និងសម្ពាធការប្រឡង`,
      uniqueEnvironment: 'សាលារៀនគំរូកម្រិតជាតិ មានសិស្ស ៩៥០ នាក់ គ្រូបង្រៀន ៣៦ នាក់ និងគណៈកម្មការអភិវឌ្ឍន៍សាលារៀនសកម្ម',
      opportunities: 'ក្លាយជាសាលាធនធានចែករំលែកបទពិសោធន៍ SBM ដល់សាលាដទៃក្នុងស្រុក និងអនុវត្តកម្មវិធីផ្លាស់ប្តូរការសិក្សាជាតិ',
      fileName: 'preset_model_school.txt',
      lastUpdated: 'ខែវិច្ឆិកា ឆ្នាំ២០២៤'
    }
  }
];

export const SchoolContextModal: React.FC<SchoolContextModalProps> = ({
  isOpen,
  onClose,
  currentProfile,
  schoolName,
  onSaveProfile,
}) => {
  const [profile, setProfile] = useState<SchoolContextProfile>(() => {
    return currentProfile || {
      summary: '',
      strengths: '',
      challenges: '',
      uniqueEnvironment: '',
      opportunities: '',
      fileName: '',
      lastUpdated: new Date().toLocaleDateString('km-KH', { month: 'long', year: 'numeric' })
    };
  });

  const [activeTab, setActiveTab] = useState<'upload' | 'edit'>('upload');
  const [uploadedFileName, setUploadedFileName] = useState<string>('');
  const [uploadedRawText, setUploadedRawText] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);

  if (!isOpen) return null;

  // Handle local file selection
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadedFileName(file.name);
    setAnalysisError(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        setUploadedRawText(content);
      }
    };
    reader.onerror = () => {
      setAnalysisError('មិនអាចអានឯកសារនេះបានឡើយ។ សូមសាកល្បងឯកសារ .txt ឬ .md');
    };
    reader.readAsText(file);
  };

  // AI Analyze uploaded text
  const handleRunAiAnalysis = async (textToAnalyze?: string) => {
    const content = textToAnalyze || uploadedRawText;
    if (!content.trim()) {
      setAnalysisError('សូមបញ្ចូល ឬផ្ទុកឡើងអត្ថបទសង្ខេបអំពីសាលារៀនជាមុនសិន!');
      return;
    }

    setIsAnalyzing(true);
    setAnalysisError(null);

    try {
      const data = await safeFetchJson('/api/plan/analyze-school-context', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rawText: content,
          fileName: uploadedFileName || 'ឯកសារផ្ទុកឡើង',
        }),
      });

      if (data.success && data.profile) {
        setProfile({
          summary: data.profile.summary || '',
          strengths: data.profile.strengths || '',
          challenges: data.profile.challenges || '',
          uniqueEnvironment: data.profile.uniqueEnvironment || '',
          opportunities: data.profile.opportunities || '',
          fileName: uploadedFileName || 'ការវិភាគដោយ AI',
          lastUpdated: new Date().toLocaleDateString('km-KH', { month: 'long', year: 'numeric' })
        });
        setActiveTab('edit');
      } else {
        setAnalysisError(data.error || 'មានបញ្ហាក្នុងការវិភាគឯកសារ');
      }
    } catch (err: any) {
      console.error(err);
      setAnalysisError(err?.message || 'បរាជ័យក្នុងការតភ្ជាប់ទៅកាន់ម៉ាស៊ីនបម្រើ AI');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleApplyPreset = (preset: typeof CONTEXT_PRESETS[0]) => {
    setProfile({
      ...preset.profile,
      fileName: preset.label,
      lastUpdated: new Date().toLocaleDateString('km-KH', { month: 'long', year: 'numeric' })
    });
    setActiveTab('edit');
  };

  const handleSave = () => {
    onSaveProfile({
      ...profile,
      lastUpdated: new Date().toLocaleDateString('km-KH', { month: 'long', year: 'numeric' })
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-3xl w-full shadow-2xl border border-slate-200 overflow-hidden my-6 animate-in fade-in zoom-in-95 duration-200 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-blue-800 via-indigo-700 to-sky-700 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 backdrop-blur-xs flex items-center justify-center border border-white/20">
              <Building2 className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold font-kantumruy">
                បរិបទ និងចំណុចខ្លាំង-ប្រឈមរបស់សាលារៀន
              </h2>
              <p className="text-xs text-blue-100 font-sans">
                {schoolName} • សម្រាប់ផ្គត់ផ្គង់ AI បង្កើតផែនការឱ្យចំស្ថានភាពជាក់ស្តែង
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="px-5 pt-3 pb-2 bg-slate-50 border-b border-slate-200 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center bg-slate-200/80 p-1 rounded-xl text-xs font-semibold">
            <button
              onClick={() => setActiveTab('upload')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                activeTab === 'upload'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Upload className="w-3.5 h-3.5" />
              <span>ផ្ទុកឡើងឯកសារ / គំរូសាលា</span>
            </button>
            <button
              onClick={() => setActiveTab('edit')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                activeTab === 'edit'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>ចំណុចខ្លាំង & បញ្ហាប្រឈម ({profile.strengths ? 'បានផ្ទុក' : 'ទទេ'})</span>
            </button>
          </div>

          {profile.strengths && (
            <span className="hidden sm:inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>ទិន្នន័យបានភ្ជាប់</span>
            </span>
          )}
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-5 flex-1">
          {activeTab === 'upload' ? (
            <div className="space-y-5">
              {/* Info banner */}
              <div className="p-3.5 rounded-xl bg-blue-50/80 border border-blue-200 text-xs text-blue-900 leading-relaxed">
                <div className="font-bold flex items-center gap-1.5 mb-1 text-blue-800">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  <span>ហេតុអ្វីបានជាត្រូវបញ្ចូលបរិបទ និងចំណុចខ្លាំង-ប្រឈមរបស់សាលា?</span>
                </div>
                <p>
                  នៅពេលអ្នកផ្ទុកឡើងរបាយការណ៍សង្ខេប ឬកំណត់ចំណាំអំពីស្ថានភាពសាលារបស់អ្នក ប្រព័ន្ធ AI នឹងប្រើប្រាស់ទិន្នន័យជាក់ស្តែងទាំងនេះ ដើម្បីសរសេររាល់ជំពូក វឌ្ឍនភាព បញ្ហាប្រឈម គោលបំណង និងតារាងសកម្មភាពឱ្យឆ្លើយតបចំៗទៅនឹងបរិស្ថានអប់រំផ្ទាល់ខ្លួនរបស់សាលា ដោយមិនសរសេរជាទូទៅៗឡើយ។
                </p>
              </div>

              {/* File Upload Box */}
              <div className="border-2 border-dashed border-slate-300 hover:border-blue-400 rounded-2xl p-6 bg-slate-50/60 hover:bg-blue-50/20 text-center transition-all cursor-pointer relative">
                <input
                  type="file"
                  accept=".txt,.md,.doc,.docx,.pdf,.json"
                  onChange={handleFileUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <div className="w-12 h-12 rounded-2xl bg-blue-100 text-blue-600 flex items-center justify-center mx-auto mb-3 shadow-xs">
                  <Upload className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-bold text-slate-800 mb-1">
                  {uploadedFileName ? `ឯកសារបានជ្រើស៖ ${uploadedFileName}` : 'ចុច ឬអូសទម្លាក់ឯកសារសង្ខេបអំពីសាលារៀននៅទីនេះ'}
                </h4>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  គាំទ្រឯកសារអត្ថបទ (.txt, .md, .doc, .docx, .pdf, .json) ស្ដីពីរបាយការណ៍ស្វ័យវាយតម្លៃ ស្ថានភាពសាលា ឬកំណត់ហេតុប្រជុំ
                </p>
              </div>

              {/* Direct Paste / Raw Text Area */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  ឬចម្លង (Paste) អត្ថបទសង្ខេបអំពីសាលារបស់អ្នកដោយផ្ទាល់នៅទីនេះ៖
                </label>
                <textarea
                  rows={4}
                  value={uploadedRawText}
                  onChange={(e) => setUploadedRawText(e.target.value)}
                  placeholder="ឧ. សាលាបឋមសិក្សាគំរូ មានសិស្ស ៥២០ នាក់ គ្រូ ១៨ នាក់។ ចំណុចខ្លាំង៖ គ្រូខិតខំបង្រៀន មានការប្រជុំ PLC ទៀងទាត់ និងបរិស្ថានស្អាត។ បញ្ហាប្រឈម៖ ខ្វះសម្ភារបច្ចេកវិទ្យា មាតាបិតាចំណាកស្រុក និងសិស្សមួយចំនួនខ្សោយអំណាន..."
                  className="w-full p-3 text-xs bg-white border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 font-kantumruy"
                />
              </div>

              {/* Action Button: AI Analyze */}
              {uploadedRawText.trim() && (
                <div className="flex items-center justify-between gap-3 bg-indigo-50/70 p-3 rounded-xl border border-indigo-200">
                  <div className="text-xs text-indigo-900">
                    <span className="font-bold">ត្រៀមវិភាគ៖ </span>
                    <span>AI នឹងចម្រាញ់យកចំណុចខ្លាំង បញ្ហាប្រឈម និងបរិស្ថានអប់រំចេញពីអត្ថបទនេះដោយស្វ័យប្រវត្ត</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleRunAiAnalysis()}
                    disabled={isAnalyzing}
                    className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white text-xs font-bold rounded-xl shadow-md transition-all shrink-0 disabled:opacity-50"
                  >
                    {isAnalyzing ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>កំពុងវិភាគ...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                        <span>ឱ្យ AI វិភាគស្វ័យប្រវត្ត</span>
                      </>
                    )}
                  </button>
                </div>
              )}

              {analysisError && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{analysisError}</span>
                </div>
              )}

              {/* Quick Presets for Convenient Testing */}
              <div className="pt-2 border-t border-slate-200">
                <h4 className="text-xs font-bold text-slate-700 mb-2 flex items-center gap-1.5">
                  <Compass className="w-3.5 h-3.5 text-blue-600" />
                  <span>ឬជ្រើសរើសគំរូបរិបទសាលាគំរូ (Quick Templates)៖</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  {CONTEXT_PRESETS.map((preset, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleApplyPreset(preset)}
                      className="p-3 text-left rounded-xl border border-slate-200 hover:border-blue-400 bg-white hover:bg-blue-50/40 text-xs transition-all shadow-2xs group"
                    >
                      <div className="font-semibold text-slate-800 group-hover:text-blue-700 mb-1 flex items-center justify-between">
                        <span>{preset.label}</span>
                        <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-blue-600 transition-transform group-hover:translate-x-0.5" />
                      </div>
                      <p className="text-[11px] text-slate-500 line-clamp-2">
                        {preset.profile.summary}
                      </p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            /* Structured Review & Direct Edit Tab */
            <div className="space-y-4 text-xs">
              <div className="flex items-center justify-between text-xs text-slate-500 pb-1 border-b border-slate-100">
                <span>អ្នកអាចកែប្រែ ឬបន្ថែមទិន្នន័យជាក់ស្តែងរបស់សាលាដោយសេរីនៅខាងក្រោម៖</span>
                {profile.fileName && (
                  <span className="text-[11px] bg-slate-100 px-2 py-0.5 rounded font-mono">
                    {profile.fileName}
                  </span>
                )}
              </div>

              {/* Summary */}
              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  ១. សេចក្តីសង្ខេបជារួមអំពីសាលារៀន (Overview & Summary)៖
                </label>
                <textarea
                  rows={2}
                  value={profile.summary}
                  onChange={(e) => setProfile({ ...profile, summary: e.target.value })}
                  placeholder="សេចក្តីសង្ខេបអំពីទីតាំង ប្រភេទសាលា និងស្ថានភាពសាលាបច្ចុប្បន្ន..."
                  className="w-full p-2.5 bg-white border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 font-kantumruy"
                />
              </div>

              {/* Strengths */}
              <div>
                <label className="block font-bold text-emerald-800 mb-1 flex items-center gap-1.5">
                  <ThumbsUp className="w-3.5 h-3.5 text-emerald-600" />
                  <span>២. ចំណុចខ្លាំង និងឧត្តមភាពជាក់ស្តែងរបស់សាលា (School Unique Strengths)៖</span>
                </label>
                <textarea
                  rows={4}
                  value={profile.strengths}
                  onChange={(e) => setProfile({ ...profile, strengths: e.target.value })}
                  placeholder="• គ្រូបង្រៀនមានស្មារតីសាមគ្គីភាព និងគរុកោសល្យល្អ...&#10;• គណៈកម្មការទ្រទ្រង់សាលា និងសហគមន៍ជួយគាំទ្រយ៉ាងសកម្ម...&#10;• អត្រាសិស្សជាប់ថ្នាក់ខ្ពស់..."
                  className="w-full p-2.5 bg-emerald-50/30 border border-emerald-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 font-kantumruy"
                />
              </div>

              {/* Challenges */}
              <div>
                <label className="block font-bold text-rose-800 mb-1 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                  <span>៣. បញ្ហាប្រឈម និងឧបសគ្គជាក់ស្តែង (School Specific Challenges)៖</span>
                </label>
                <textarea
                  rows={4}
                  value={profile.challenges}
                  onChange={(e) => setProfile({ ...profile, challenges: e.target.value })}
                  placeholder="• កង្វះខាតសម្ភារបច្ចេកវិទ្យា និងបន្ទប់ពិសោធន៍វិទ្យាសាស្ត្រ...&#10;• មាតាបិតាសិស្សចំណាកស្រុក ទុកកូនឱ្យនៅជាមួយជីដូនជីតា...&#10;• សិស្សមួយចំនួនខ្សោយបំណិនអាន និងគណិតវិទ្យា..."
                  className="w-full p-2.5 bg-rose-50/30 border border-rose-200 rounded-xl outline-none focus:ring-2 focus:ring-rose-500 font-kantumruy"
                />
              </div>

              {/* Environment and Demographics */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-800 mb-1">
                    ៤. បរិស្ថានអប់រំ និងសហគមន៍ (Environment)៖
                  </label>
                  <textarea
                    rows={3}
                    value={profile.uniqueEnvironment || ''}
                    onChange={(e) => setProfile({ ...profile, uniqueEnvironment: e.target.value })}
                    placeholder="ចំនួនសិស្ស គ្រូ ចម្ងាយ ស្ថានភាពសេដ្ឋកិច្ចសហគមន៍..."
                    className="w-full p-2.5 bg-white border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 font-kantumruy"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-800 mb-1">
                    ៥. ឱកាស និងទិសដៅអភិវឌ្ឍន៍ (Opportunities)៖
                  </label>
                  <textarea
                    rows={3}
                    value={profile.opportunities || ''}
                    onChange={(e) => setProfile({ ...profile, opportunities: e.target.value })}
                    placeholder="គម្រោងកៀរគរជំនួយ ការបណ្តុះបណ្តាលគ្រូ ការបង្កើតក្លឹបសិក្សា..."
                    className="w-full p-2.5 bg-white border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 font-kantumruy"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-200 rounded-xl transition-colors"
          >
            បោះបង់
          </button>

          <div className="flex items-center gap-2">
            {activeTab === 'upload' && uploadedRawText.trim() && (
              <button
                type="button"
                onClick={() => {
                  setProfile({
                    ...profile,
                    summary: uploadedRawText.slice(0, 300),
                    strengths: uploadedRawText,
                    fileName: uploadedFileName || 'សេចក្តីសង្ខេបផ្ទាល់',
                  });
                  setActiveTab('edit');
                }}
                className="px-3 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors"
              >
                កែសម្រួលដោយដៃ
              </button>
            )}

            <button
              type="button"
              onClick={handleSave}
              className="flex items-center gap-1.5 px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-md shadow-blue-500/25 transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-300" />
              <span>រក្សាទុកបរិបទសាលា</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
