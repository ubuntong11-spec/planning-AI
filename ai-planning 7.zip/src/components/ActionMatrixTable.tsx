import React, { useState } from 'react';
import { 
  Plus, 
  Trash2, 
  Sparkles, 
  DollarSign, 
  Calendar, 
  UserCheck, 
  Target,
  Edit2,
  Check,
  X,
  RefreshCw
} from 'lucide-react';
import { ActionMatrixItem, ActivityStatus } from '../types/plan';
import { BarChart3 } from 'lucide-react';

interface ActionMatrixTableProps {
  items: ActionMatrixItem[];
  onChange: (items: ActionMatrixItem[]) => void;
  onGenerateAiRows: () => void;
  isGenerating?: boolean;
  onOpenDashboard?: () => void;
}

export const ActionMatrixTable: React.FC<ActionMatrixTableProps> = ({
  items,
  onChange,
  onGenerateAiRows,
  isGenerating = false,
  onOpenDashboard,
}) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [tempRow, setTempRow] = useState<ActionMatrixItem | null>(null);

  const handleStartEdit = (item: ActionMatrixItem) => {
    setEditingId(item.id);
    setTempRow({ ...item });
  };

  const handleSaveEdit = () => {
    if (!tempRow) return;
    const updated = items.map(item => item.id === tempRow.id ? tempRow : item);
    onChange(updated);
    setEditingId(null);
    setTempRow(null);
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setTempRow(null);
  };

  const handleAddRow = () => {
    const newItem: ActionMatrixItem = {
      id: `act-${Date.now()}`,
      activity: 'សកម្មភាពថ្មី...',
      indicator: 'សូចនាករវាស់វែង...',
      timeline: 'ត្រីមាសទី ១-៤',
      budget: '១,០០០,០០០ រៀល',
      budgetSource: 'ថវិកា PB',
      responsiblePerson: 'គណៈគ្រប់គ្រង',
    };
    onChange([...items, newItem]);
    handleStartEdit(newItem);
  };

  const handleDeleteRow = (id: string) => {
    onChange(items.filter(item => item.id !== id));
  };

  return (
    <div className="space-y-4">
      {/* Header with AI Generate, Dashboard and Add Button */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
        <div>
          <h4 className="text-sm font-bold text-slate-800 font-kantumruy">
            តារាងម៉ាទ្រីសសកម្មភាពអនុវត្ត ថវិកា និងកាលវិភាគ
          </h4>
          <p className="text-xs text-slate-500">
            សរុប {items.length} សកម្មភាពគន្លឹះដែលបានគ្រោងទុក
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {onOpenDashboard && (
            <button
              onClick={onOpenDashboard}
              type="button"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-semibold border border-emerald-200 transition-colors"
            >
              <BarChart3 className="w-3.5 h-3.5 text-emerald-600" />
              <span>ផ្ទាំងវឌ្ឍនភាព (Dashboard)</span>
            </button>
          )}

          <button
            onClick={onGenerateAiRows}
            disabled={isGenerating}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-semibold border border-indigo-200 transition-colors disabled:opacity-50"
          >
            {isGenerating ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
            )}
            <span>AI បង្កើតសកម្មភាពបន្ថែម</span>
          </button>

          <button
            onClick={handleAddRow}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>បន្ថែមសកម្មភាព</span>
          </button>
        </div>
      </div>

      {/* Table Container */}
      <div className="overflow-x-auto rounded-xl border border-slate-200 shadow-xs bg-white">
        <table className="w-full text-left text-xs text-slate-700 border-collapse">
          <thead className="bg-slate-100 text-slate-800 font-semibold border-b border-slate-200 font-kantumruy">
            <tr>
              <th className="py-3 px-3 text-center w-12 border-r border-slate-200">ល.រ</th>
              <th className="py-3 px-3 min-w-[200px] border-r border-slate-200">សកម្មភាពអនុវត្ត</th>
              <th className="py-3 px-3 min-w-[160px] border-r border-slate-200">សូចនាករវាស់វែង</th>
              <th className="py-3 px-3 min-w-[110px] border-r border-slate-200">កាលវិភាគ</th>
              <th className="py-3 px-3 min-w-[110px] border-r border-slate-200">ថវិកា</th>
              <th className="py-3 px-3 min-w-[120px] border-r border-slate-200">ប្រភពថវិកា</th>
              <th className="py-3 px-3 min-w-[130px] border-r border-slate-200">អ្នកទទួលខុសត្រូវ</th>
              <th className="py-3 px-3 text-center min-w-[110px] border-r border-slate-200">ស្ថានភាព</th>
              <th className="py-3 px-2 text-center w-16">សកម្មភាព</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 font-kantumruy">
            {items.map((item, index) => {
              const isEditing = editingId === item.id;
              const currentStatus = item.status || 'pending';

              if (isEditing && tempRow) {
                return (
                  <tr key={item.id} className="bg-blue-50/40">
                    <td className="py-2.5 px-3 text-center font-medium border-r border-slate-200">
                      {index + 1}
                    </td>
                    <td className="py-2 px-2 border-r border-slate-200">
                      <textarea
                        value={tempRow.activity}
                        onChange={(e) => setTempRow({ ...tempRow, activity: e.target.value })}
                        className="w-full p-1.5 text-xs bg-white border border-blue-400 rounded-md outline-none"
                        rows={2}
                      />
                    </td>
                    <td className="py-2 px-2 border-r border-slate-200">
                      <textarea
                        value={tempRow.indicator}
                        onChange={(e) => setTempRow({ ...tempRow, indicator: e.target.value })}
                        className="w-full p-1.5 text-xs bg-white border border-blue-400 rounded-md outline-none"
                        rows={2}
                      />
                    </td>
                    <td className="py-2 px-2 border-r border-slate-200">
                      <input
                        type="text"
                        value={tempRow.timeline}
                        onChange={(e) => setTempRow({ ...tempRow, timeline: e.target.value })}
                        className="w-full p-1.5 text-xs bg-white border border-blue-400 rounded-md outline-none"
                      />
                    </td>
                    <td className="py-2 px-2 border-r border-slate-200">
                      <input
                        type="text"
                        value={tempRow.budget}
                        onChange={(e) => setTempRow({ ...tempRow, budget: e.target.value })}
                        className="w-full p-1.5 text-xs bg-white border border-blue-400 rounded-md outline-none font-semibold text-emerald-700"
                      />
                    </td>
                    <td className="py-2 px-2 border-r border-slate-200">
                      <input
                        type="text"
                        value={tempRow.budgetSource}
                        onChange={(e) => setTempRow({ ...tempRow, budgetSource: e.target.value })}
                        className="w-full p-1.5 text-xs bg-white border border-blue-400 rounded-md outline-none"
                      />
                    </td>
                    <td className="py-2 px-2 border-r border-slate-200">
                      <input
                        type="text"
                        value={tempRow.responsiblePerson}
                        onChange={(e) => setTempRow({ ...tempRow, responsiblePerson: e.target.value })}
                        className="w-full p-1.5 text-xs bg-white border border-blue-400 rounded-md outline-none"
                      />
                    </td>
                    <td className="py-2 px-2 border-r border-slate-200">
                      <select
                        value={tempRow.status || 'pending'}
                        onChange={(e) => setTempRow({ 
                          ...tempRow, 
                          status: e.target.value as ActivityStatus,
                          progressPercentage: e.target.value === 'completed' ? 100 : e.target.value === 'in_progress' ? 50 : 0
                        })}
                        className="w-full p-1 text-xs bg-white border border-blue-400 rounded-md outline-none"
                      >
                        <option value="pending">មិនទាន់ចាប់ផ្ដើម</option>
                        <option value="in_progress">កំពុងអនុវត្ត</option>
                        <option value="completed">សម្រេចបាន</option>
                      </select>
                    </td>
                    <td className="py-2 px-2 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={handleSaveEdit}
                          title="រក្សាទុក"
                          className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
                        >
                          <Check className="w-4 h-4" />
                        </button>
                        <button
                          onClick={handleCancelEdit}
                          title="បោះបង់"
                          className="p-1 text-slate-400 hover:bg-slate-100 rounded"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              }

              return (
                <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3 px-3 text-center text-slate-500 font-semibold border-r border-slate-200">
                    {index + 1}
                  </td>
                  <td className="py-3 px-3 font-medium text-slate-800 border-r border-slate-200">
                    {item.activity}
                  </td>
                  <td className="py-3 px-3 text-slate-600 border-r border-slate-200">
                    {item.indicator}
                  </td>
                  <td className="py-3 px-3 text-slate-600 border-r border-slate-200">
                    <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 font-medium">
                      {item.timeline}
                    </span>
                  </td>
                  <td className="py-3 px-3 font-semibold text-emerald-700 border-r border-slate-200">
                    {item.budget}
                  </td>
                  <td className="py-3 px-3 text-slate-600 border-r border-slate-200">
                    {item.budgetSource}
                  </td>
                  <td className="py-3 px-3 text-slate-600 border-r border-slate-200">
                    {item.responsiblePerson}
                  </td>
                  <td className="py-3 px-2 text-center border-r border-slate-200">
                    <button
                      type="button"
                      onClick={() => {
                        const nextStatus: ActivityStatus = 
                          currentStatus === 'completed' ? 'pending' :
                          currentStatus === 'in_progress' ? 'completed' : 'in_progress';
                        const updated = items.map(i => i.id === item.id ? { ...i, status: nextStatus } : i);
                        onChange(updated);
                      }}
                      title="ចុចដើម្បីផ្លាស់ប្តូរស្ថានភាព"
                      className={`px-2 py-1 rounded-full text-[11px] font-semibold transition-transform active:scale-95 inline-flex items-center gap-1 ${
                        currentStatus === 'completed'
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          : currentStatus === 'in_progress'
                          ? 'bg-amber-100 text-amber-800 border border-amber-300'
                          : 'bg-slate-100 text-slate-600 border border-slate-200'
                      }`}
                    >
                      <span className={`w-1.5 h-1.5 rounded-full ${
                        currentStatus === 'completed' ? 'bg-emerald-600' :
                        currentStatus === 'in_progress' ? 'bg-amber-500' : 'bg-slate-400'
                      }`} />
                      <span>
                        {currentStatus === 'completed' ? 'សម្រេចបាន' :
                         currentStatus === 'in_progress' ? 'កំពុងអនុវត្ត' : 'មិនទាន់'}
                      </span>
                    </button>
                  </td>
                  <td className="py-3 px-2 text-center">
                    <div className="flex items-center justify-center gap-1">
                      <button
                        onClick={() => handleStartEdit(item)}
                        title="កែសម្រួល"
                        className="p-1 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteRow(item.id)}
                        title="លុបសកម្មភាព"
                        className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
