import React, { useState } from 'react';
import { 
  X, 
  Eye, 
  Trash2, 
  RefreshCw, 
  Download, 
  Printer, 
  FileText, 
  Calendar, 
  HardDrive, 
  ExternalLink,
  ZoomIn,
  ZoomOut,
  Maximize2
} from 'lucide-react';
import { EvidenceItem } from '../types/assessment';
import { downloadBlob, downloadDataUrl, printHtmlSafely } from '../utils/fileDownloader';

interface FileViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  evidence: EvidenceItem | null;
  indicatorCode?: string;
  indicatorTitle?: string;
  onDelete: (id: string) => void;
  onReplace: (evidence: EvidenceItem) => void;
}

export const FileViewerModal: React.FC<FileViewerModalProps> = ({
  isOpen,
  onClose,
  evidence,
  indicatorCode,
  indicatorTitle,
  onDelete,
  onReplace,
}) => {
  const [zoomLevel, setZoomLevel] = useState<number>(100);
  const [confirmDelete, setConfirmDelete] = useState<boolean>(false);

  if (!isOpen || !evidence) return null;

  const isImage = evidence.fileType?.startsWith('image/') || 
    /\.(jpg|jpeg|png|webp|gif|svg)$/i.test(evidence.fileName);

  const isPdf = evidence.fileType === 'application/pdf' || 
    /\.pdf$/i.test(evidence.fileName);

  // Download Handler
  const handleDownload = () => {
    if (evidence.fileData) {
      downloadDataUrl(evidence.fileData, evidence.fileName || 'evidence_document');
    } else {
      // Create a dummy text blob if data is not present
      const blob = new Blob([`ឯកសារភស្តុតាង៖ ${evidence.title}\nប្រភេទ៖ ${evidence.type}\nកាលបរិច្ឆេទ៖ ${evidence.uploadedAt}`], { type: 'text/plain;charset=utf-8' });
      downloadBlob(blob, evidence.fileName || 'evidence_document.txt');
    }
  };

  // Print Handler
  const handlePrint = () => {
    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>${evidence.title}</title>
          <style>
            body { font-family: 'Kantumruy Pro', sans-serif; margin: 20px; color: #1e293b; }
            .header { border-bottom: 2px solid #3b82f6; padding-bottom: 12px; margin-bottom: 20px; }
            .title { font-size: 20px; font-weight: bold; color: #1e3a8a; }
            .meta { font-size: 13px; color: #64748b; margin-top: 6px; }
            .content { text-align: center; margin-top: 30px; }
            img { max-width: 100%; height: auto; border-radius: 8px; border: 1px solid #cbd5e1; }
          </style>
        </head>
        <body>
          <div class="header">
            <div class="title">${evidence.title}</div>
            <div class="meta">
              សូចនាករ៖ ${indicatorCode || ''} ${indicatorTitle || ''} | កាលបរិច្ឆេទ៖ ${evidence.uploadedAt} | ឈ្មោះឯកសារ៖ ${evidence.fileName}
            </div>
          </div>
          <div class="content">
            ${isImage && evidence.fileData ? `<img src="${evidence.fileData}" alt="${evidence.title}" />` : `<p>ឯកសារ៖ ${evidence.fileName}</p>`}
          </div>
        </body>
      </html>
    `;
    printHtmlSafely(htmlContent);
  };

  // Open in New Tab via Server-Assisted URL or Safe Window Write
  const handleOpenInNewTab = async () => {
    if (isImage && evidence.fileData) {
      const win = window.open();
      if (win) {
        win.document.write(`
          <html>
            <head><title>${evidence.fileName || 'ឯកសារ'}</title></head>
            <body style="margin:0;display:flex;align-items:center;justify-content:center;background:#0f172a;min-height:100vh;">
              <img src="${evidence.fileData}" style="max-width:98%;max-height:98vh;object-fit:contain;border-radius:8px;"/>
            </body>
          </html>
        `);
        win.document.close();
      }
    } else if (evidence.fileData) {
      try {
        const res = await fetch('/api/file/prepare-download', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            fileName: evidence.fileName || 'document.pdf',
            content: evidence.fileData,
            contentType: evidence.fileType || 'application/pdf',
            isBase64: true,
          }),
        });
        const data = await res.json();
        if (data?.viewUrl) {
          window.open(data.viewUrl, '_blank');
        } else {
          handleDownload();
        }
      } catch {
        handleDownload();
      }
    }
  };

  const formatFileSize = (bytes?: number) => {
    if (!bytes) return '120 KB';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/70 backdrop-blur-xs font-kantumruy">
      <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-150">
        
        {/* Top Header & Metadata */}
        <div className="px-5 py-3.5 bg-slate-900 text-white flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-md bg-blue-500/30 text-blue-300 text-xs font-mono font-bold">
                {indicatorCode || 'ភស្តុតាង'}
              </span>
              <h3 className="font-bold text-sm sm:text-base text-white truncate">
                {evidence.title}
              </h3>
            </div>
            <div className="text-[11px] text-slate-300 flex items-center gap-3 mt-1 truncate">
              <span>ឯកសារ៖ {evidence.fileName}</span>
              <span>•</span>
              <span>{formatFileSize(evidence.fileSize)}</span>
              <span>•</span>
              <span>{evidence.uploadedAt}</span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Toolbar: បើកមើល, លុប, ប្ដូរ, ទាញយក, ព្រីន */}
        <div className="px-5 py-2.5 bg-slate-100 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs">
          {/* Zoom controls for images */}
          {isImage && (
            <div className="flex items-center gap-1 bg-white px-2 py-1 rounded-lg border border-slate-200 shadow-2xs">
              <button
                onClick={() => setZoomLevel((prev) => Math.max(50, prev - 25))}
                className="p-1 text-slate-600 hover:text-slate-900 rounded-md hover:bg-slate-100"
                title="ពង្រួម (Zoom Out)"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <span className="text-[11px] text-slate-600 font-medium px-1 w-10 text-center">
                {zoomLevel}%
              </span>
              <button
                onClick={() => setZoomLevel((prev) => Math.min(250, prev + 25))}
                className="p-1 text-slate-600 hover:text-slate-900 rounded-md hover:bg-slate-100"
                title="ពង្រីក (Zoom In)"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setZoomLevel(100)}
                className="p-1 text-slate-600 hover:text-slate-900 rounded-md hover:bg-slate-100"
                title="ទំហំដើម (Reset Zoom)"
              >
                <Maximize2 className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Action Buttons as requested */}
          <div className="flex items-center gap-1.5 ml-auto">
            {/* ប្ដូរ (Replace / Edit) */}
            <button
              onClick={() => {
                onReplace(evidence);
                onClose();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 hover:border-slate-300 font-semibold shadow-2xs transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5 text-blue-600" />
              <span>ប្ដូរ (Replace)</span>
            </button>

            {/* បើកផ្ទាំងថ្មី (Open in New Tab) */}
            {evidence.fileData && (
              <button
                onClick={handleOpenInNewTab}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 hover:border-slate-300 font-semibold shadow-2xs transition-colors"
                title="បើកមើលក្នុងផ្ទាំងថ្មី"
              >
                <ExternalLink className="w-3.5 h-3.5 text-blue-600" />
                <span>បើកផ្ទាំងថ្មី</span>
              </button>
            )}

            {/* ទាញយក (Download) */}
            <button
              onClick={handleDownload}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 hover:border-slate-300 font-semibold shadow-2xs transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-emerald-600" />
              <span>ទាញយក</span>
            </button>

            {/* ព្រីន (Print) */}
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 hover:border-slate-300 font-semibold shadow-2xs transition-colors"
            >
              <Printer className="w-3.5 h-3.5 text-indigo-600" />
              <span>ព្រីន</span>
            </button>

            {/* លុប (Delete) */}
            {!confirmDelete ? (
              <button
                onClick={() => setConfirmDelete(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-semibold transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>លុប</span>
              </button>
            ) : (
              <div className="flex items-center gap-1 bg-rose-100 p-0.5 rounded-lg border border-rose-300 animate-in fade-in">
                <button
                  onClick={() => {
                    onDelete(evidence.id);
                    onClose();
                  }}
                  className="px-2 py-1 rounded-md bg-rose-600 text-white font-bold text-[11px] hover:bg-rose-700"
                >
                  បញ្ជាក់លុប
                </button>
                <button
                  onClick={() => setConfirmDelete(false)}
                  className="px-2 py-1 rounded-md text-slate-600 hover:bg-rose-200/60 text-[11px]"
                >
                  ទេ
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Content Viewer Area */}
        <div className="flex-1 overflow-auto p-4 bg-slate-950/5 flex items-center justify-center min-h-[340px]">
          {isImage && evidence.fileData ? (
            <div className="max-w-full overflow-auto flex items-center justify-center p-2">
              <img
                src={evidence.fileData}
                alt={evidence.title}
                style={{ width: `${zoomLevel}%`, maxWidth: 'none' }}
                className="rounded-xl shadow-lg border border-slate-300 transition-all object-contain max-h-[60vh]"
              />
            </div>
          ) : isPdf && evidence.fileData ? (
            <div className="max-w-md w-full bg-white p-6 rounded-2xl border border-slate-200 shadow-sm text-center space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mx-auto border border-rose-200 shadow-2xs">
                <FileText className="w-8 h-8" />
              </div>
              <div>
                <span className="px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-700 font-bold text-xs">
                  ឯកសារ PDF
                </span>
                <h4 className="font-bold text-slate-900 text-base mt-2">
                  {evidence.title}
                </h4>
                <p className="text-xs text-slate-500 mt-1">
                  ឈ្មោះឯកសារ៖ <span className="font-mono text-slate-700">{evidence.fileName}</span> ({formatFileSize(evidence.fileSize)})
                </p>
              </div>
              
              <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
                <button
                  onClick={handleOpenInNewTab}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md shadow-blue-500/25 transition-all"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>បើកមើលផ្ទាំងដាច់ដោយឡែក</span>
                </button>
                <button
                  onClick={handleDownload}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-500/25 transition-all"
                >
                  <Download className="w-4 h-4" />
                  <span>ទាញយក PDF</span>
                </button>
                <button
                  onClick={handlePrint}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 font-bold text-xs transition-colors"
                >
                  <Printer className="w-4 h-4" />
                  <span>បោះពុម្ព</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="max-w-md w-full bg-white p-6 rounded-2xl border border-slate-200 shadow-sm text-center space-y-3">
              <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto border border-blue-200">
                <FileText className="w-8 h-8" />
              </div>
              <h4 className="font-bold text-slate-900 text-base">
                {evidence.title}
              </h4>
              <p className="text-xs text-slate-500">
                ឯកសារ៖ <span className="font-mono text-slate-700">{evidence.fileName}</span>
              </p>
              <div className="pt-2 flex justify-center gap-3">
                <button
                  onClick={handleDownload}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md shadow-blue-500/25 transition-all"
                >
                  <Download className="w-4 h-4" />
                  <span>ទាញយកដើម្បីមើលលើកុំព្យូទ័រ/ទូរស័ព្ទ</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-white border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>ប្រភេទ៖ <strong className="text-slate-700">{evidence.type}</strong></span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold transition-colors"
          >
            បិទ
          </button>
        </div>

      </div>
    </div>
  );
};
