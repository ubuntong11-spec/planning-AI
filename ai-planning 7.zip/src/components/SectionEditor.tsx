import React, { useState, useEffect, useRef } from 'react';
import { 
  Sparkles, 
  Wand2, 
  Maximize2, 
  FileCheck, 
  Copy, 
  Check, 
  Send, 
  TrendingUp, 
  RefreshCw, 
  HelpCircle, 
  ChevronRight,
  Mic,
  MicOff,
  Radio,
  Languages,
  AlertCircle,
  X,
  Building2,
  BarChart3,
  PieChart
} from 'lucide-react';
import { ActionMatrixItem, SchoolContextProfile } from '../types/plan';
import { ActionMatrixTable } from './ActionMatrixTable';
import { ActionMatrixDashboard } from './ActionMatrixDashboard';
import { StandardCategory } from '../data/standardFourData';
import { StandardFourTable } from './StandardFourTable';
import { ChapterFiveStandardGroup } from '../data/standardFiveActionsData';
import { ChapterFiveActionTable } from './ChapterFiveActionTable';

interface SectionEditorProps {
  sectionId: string;
  sectionCode?: string;
  title: string;
  parentTitle?: string;
  content: string;
  onChangeContent: (newContent: string | ((prev: string) => string)) => void;
  onAiRefine: (action: string, customInstruction?: string) => Promise<void>;
  isLoadingAi: boolean;
  actionMatrix?: ActionMatrixItem[];
  onChangeActionMatrix?: (items: ActionMatrixItem[]) => void;
  onGenerateAiRows?: () => void;
  standardTargets?: StandardCategory[];
  onChangeStandardTargets?: (standards: StandardCategory[]) => void;
  onAiAutoFillStandards?: () => void;
  chapterFiveActions?: ChapterFiveStandardGroup[];
  onChangeChapterFiveActions?: (groups: ChapterFiveStandardGroup[]) => void;
  schoolProfile?: SchoolContextProfile;
  onOpenSchoolContext?: () => void;
}

export const SectionEditor: React.FC<SectionEditorProps> = ({
  sectionId,
  sectionCode,
  title,
  parentTitle,
  content,
  onChangeContent,
  onAiRefine,
  isLoadingAi,
  actionMatrix,
  onChangeActionMatrix,
  onGenerateAiRows,
  standardTargets,
  onChangeStandardTargets,
  onAiAutoFillStandards,
  chapterFiveActions,
  onChangeChapterFiveActions,
  schoolProfile,
  onOpenSchoolContext,
}) => {
  const [customPrompt, setCustomPrompt] = useState('');
  const [showCustomInput, setShowCustomInput] = useState(false);
  const [copied, setCopied] = useState(false);
  const [actionViewType, setActionViewType] = useState<'dashboard' | 'detailed71' | 'concise'>('dashboard');

  // =========================================================================
  // Voice-to-Text State & Web Speech API Integration
  // =========================================================================
  const [isListening, setIsListening] = useState(false);
  const [speechLang, setSpeechLang] = useState<'km-KH' | 'en-US'>('km-KH');
  const [interimTranscript, setInterimTranscript] = useState('');
  const [voiceError, setVoiceError] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Check Web Speech API browser availability
  const isSpeechSupported = typeof window !== 'undefined' && 
    Boolean((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);

  // Cleanup speech recognition on unmount or section change
  const stopListening = () => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {
        try {
          recognitionRef.current.abort();
        } catch {}
      }
      recognitionRef.current = null;
    }
    setIsListening(false);
    setInterimTranscript('');
  };

  useEffect(() => {
    stopListening();
  }, [sectionId]);

  useEffect(() => {
    return () => {
      stopListening();
    };
  }, []);

  const startListening = () => {
    setVoiceError(null);
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    
    if (!SpeechRecognition) {
      setVoiceError('កម្មវិធីរុករករបស់អ្នកមិនគាំទ្រ Web Speech API ឡើយ។ សូមប្រើប្រាស់ Google Chrome ឬ Safari ដើម្បីបញ្ជាសំឡេង។');
      return;
    }

    try {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch {}
      }

      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = speechLang;

      recognition.onstart = () => {
        setIsListening(true);
        setInterimTranscript('');
        setVoiceError(null);
      };

      recognition.onresult = (event: any) => {
        let interim = '';
        let finalChunk = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalChunk += transcript;
          } else {
            interim += transcript;
          }
        }

        setInterimTranscript(interim);

        if (finalChunk.trim()) {
          onChangeContent((prev: string) => {
            if (!prev || !prev.trim()) {
              return finalChunk.trim();
            }
            // Smart spacing: Khmer script doesn't strictly require spaces, but English does
            const needsSpace = !prev.endsWith(' ') && !prev.endsWith('\n');
            return prev + (needsSpace ? ' ' : '') + finalChunk.trim();
          });
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition event error:', event.error);
        if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
          setVoiceError('សូមអនុញ្ញាតសិទ្ធិប្រើប្រាស់ Microphone ក្នុងកម្មវិធីរុករករបស់អ្នកដើម្បីនិយាយ។');
          setIsListening(false);
        } else if (event.error === 'network') {
          setVoiceError('មានបញ្ហាក្នុងការតភ្ជាប់សេវាបំប្លែងសំឡេង (Network Error)។');
          setIsListening(false);
        } else if (event.error === 'no-speech') {
          // Silent timeout, keep listening
        } else {
          setVoiceError(`បញ្ហាស្ដាប់សំឡេង៖ ${event.error}`);
          setIsListening(false);
        }
      };

      recognition.onend = () => {
        setIsListening(false);
        setInterimTranscript('');
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err: any) {
      console.error('Failed to initialize speech recognition:', err);
      setVoiceError('មិនអាចបើក Microphone បានទេ។ សូមព្យាយាមម្ដងទៀត។');
      setIsListening(false);
    }
  };

  const toggleListening = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customPrompt.trim()) return;
    onAiRefine('custom', customPrompt.trim());
    setCustomPrompt('');
    setShowCustomInput(false);
  };

  const wordCount = content.trim() ? content.trim().split(/\s+/).length : 0;
  const isActionChapter = sectionId === 'sec-5';
  const isStandardFourChapter = sectionId === 'sec-4';

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
      {/* Top Header & Breadcrumbs */}
      <div className="px-5 py-4 border-b border-slate-100 bg-slate-50/60 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium mb-1">
            <span>ផ្ទាំងឯកសារ</span>
            <ChevronRight className="w-3 h-3 text-slate-400" />
            {parentTitle && (
              <>
                <span className="text-slate-600">{parentTitle}</span>
                <ChevronRight className="w-3 h-3 text-slate-400" />
              </>
            )}
            <span className="text-blue-600 font-semibold">{sectionCode ? `${sectionCode}. ` : ''}{title}</span>
          </div>

          <h2 className="text-base sm:text-lg font-bold text-slate-900 font-kantumruy">
            {sectionCode ? `${sectionCode}. ` : ''}{title}
          </h2>
        </div>

        {/* Word count & copy */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500 bg-slate-100 px-2.5 py-1 rounded-lg">
            {wordCount} ពាក្យ | {content.length} តួអក្សរ
          </span>
          <button
            onClick={handleCopy}
            className="flex items-center gap-1 px-2.5 py-1 text-xs text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors border border-slate-200"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'បានចម្លង' : 'ចម្លង'}</span>
          </button>
        </div>
      </div>

      {/* AI Assistance Toolbar */}
      <div className="p-3 bg-gradient-to-r from-blue-50/70 via-indigo-50/40 to-slate-50 border-b border-blue-100/70">
        {/* School Context indicator */}
        {schoolProfile && (schoolProfile.strengths || schoolProfile.challenges || schoolProfile.summary) && (
          <div className="flex flex-wrap items-center justify-between text-[11px] bg-white/80 text-blue-900 px-2.5 py-1.5 rounded-lg border border-blue-200/70 mb-2 font-kantumruy shadow-2xs gap-1.5">
            <div className="flex items-center gap-1.5 truncate max-w-full">
              <Building2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span className="font-semibold text-blue-800 shrink-0">បរិបទសាលាផ្ទាល់ខ្លួន៖</span>
              <span className="text-slate-600 truncate">
                {schoolProfile.summary ? schoolProfile.summary.slice(0, 75) + '...' : 'មានចំណុចខ្លាំង & ប្រឈមជាក់ស្តែង'}
              </span>
            </div>
            {onOpenSchoolContext && (
              <button
                type="button"
                onClick={onOpenSchoolContext}
                className="text-blue-700 hover:text-blue-900 font-bold underline shrink-0 hover:opacity-80"
              >
                កែប្រែ/ផ្ទុកឡើង
              </button>
            )}
          </div>
        )}

        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          <span className="flex items-center gap-1 text-blue-700 font-semibold mr-1 shrink-0">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            ជំនួយការ AI:
          </span>

          <button
            onClick={() => onAiRefine('generate')}
            disabled={isLoadingAi}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-medium shadow-2xs transition-colors disabled:opacity-50"
          >
            {isLoadingAi ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Wand2 className="w-3 h-3" />}
            <span>សរសេរស្វ័យប្រវត្ត</span>
          </button>

          <button
            onClick={() => onAiRefine('formalize')}
            disabled={isLoadingAi}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white hover:bg-slate-50 text-slate-700 font-medium border border-slate-200 shadow-2xs transition-colors disabled:opacity-50"
          >
            <FileCheck className="w-3 h-3 text-indigo-600" />
            <span>កែសម្រួលភាសារដ្ឋបាល</span>
          </button>

          <button
            onClick={() => onAiRefine('expand')}
            disabled={isLoadingAi}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white hover:bg-slate-50 text-slate-700 font-medium border border-slate-200 shadow-2xs transition-colors disabled:opacity-50"
          >
            <Maximize2 className="w-3 h-3 text-emerald-600" />
            <span>ពង្រីកខ្លឹមសារលម្អិត</span>
          </button>

          <button
            onClick={() => onAiRefine('add_indicators')}
            disabled={isLoadingAi}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white hover:bg-slate-50 text-slate-700 font-medium border border-slate-200 shadow-2xs transition-colors disabled:opacity-50"
          >
            <TrendingUp className="w-3 h-3 text-amber-600" />
            <span>បន្ថែមសូចនាករ/KPIs</span>
          </button>

          <button
            onClick={() => setShowCustomInput(!showCustomInput)}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg font-medium border shadow-2xs transition-colors ${
              showCustomInput 
                ? 'bg-blue-100 text-blue-800 border-blue-300' 
                : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200'
            }`}
          >
            <HelpCircle className="w-3 h-3 text-purple-600" />
            <span>បញ្ជា AI តាមចិត្ត</span>
          </button>
        </div>

        {/* Custom prompt input drawer */}
        {showCustomInput && (
          <form onSubmit={handleCustomSubmit} className="mt-2.5 flex items-center gap-2">
            <input
              type="text"
              placeholder="ឧ. បន្ថែមស្ថិតិសិស្សប្រឡងជាប់ ៩៥% និងទិន្នន័យត្រីមាសទី២..."
              value={customPrompt}
              onChange={(e) => setCustomPrompt(e.target.value)}
              className="flex-1 px-3 py-1.5 text-xs bg-white border border-blue-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-400 font-kantumruy"
            />
            <button
              type="submit"
              disabled={isLoadingAi || !customPrompt.trim()}
              className="flex items-center gap-1 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg shadow-xs disabled:opacity-50"
            >
              <Send className="w-3 h-3" />
              <span>ផ្ញើ</span>
            </button>
          </form>
        )}
      </div>

      {/* Main Text Content Area */}
      <div className="p-4 sm:p-5">
        {/* Editor Controls: Label and Voice-to-Text Dictation Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2.5 mb-2.5">
          <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
            <span>ខ្លឹមសារអត្ថបទផ្នែកនេះ</span>
            <span className="text-slate-400 font-normal hidden sm:inline">(កែប្រែដោយផ្ទាល់, និយាយបញ្ចូល ឬប្រើ AI)</span>
          </label>

          {/* Voice-to-Text Input Controls */}
          <div className="flex flex-wrap items-center gap-1.5">
            {/* Language Switcher for Voice */}
            <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200 text-[11px] font-medium">
              <button
                type="button"
                onClick={() => {
                  setSpeechLang('km-KH');
                  if (isListening) {
                    stopListening();
                  }
                }}
                title="ប្ដូរភាសាស្ដាប់ជា ភាសាខ្មែរ"
                className={`px-2 py-1 rounded-md transition-all ${
                  speechLang === 'km-KH'
                    ? 'bg-white text-blue-700 font-bold shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                🇰🇭 ខ្មែរ
              </button>
              <button
                type="button"
                onClick={() => {
                  setSpeechLang('en-US');
                  if (isListening) {
                    stopListening();
                  }
                }}
                title="Switch voice recognition to English"
                className={`px-2 py-1 rounded-md transition-all ${
                  speechLang === 'en-US'
                    ? 'bg-white text-blue-700 font-bold shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                🇺🇸 EN
              </button>
            </div>

            {/* Voice Dictation Record Button */}
            <button
              type="button"
              onClick={toggleListening}
              title={isListening ? 'ចុចដើម្បីបញ្ឈប់ការថតសំឡេង' : 'ចុចដើម្បីនិយាយបញ្ចូលខ្លឹមសារ (Voice-to-Text)'}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                isListening
                  ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-md shadow-rose-500/30 animate-pulse ring-2 ring-rose-300'
                  : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200/80 active:scale-95'
              }`}
            >
              {isListening ? (
                <>
                  <span className="flex h-2 w-2 relative">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-white"></span>
                  </span>
                  <MicOff className="w-3.5 h-3.5" />
                  <span>កំពុងស្ដាប់... (ចុចបញ្ឈប់)</span>
                </>
              ) : (
                <>
                  <Mic className="w-3.5 h-3.5 text-indigo-600" />
                  <span>និយាយបញ្ចូលសំឡេង (Voice)</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Live Interim Transcript Bubble while Dictating */}
        {isListening && (
          <div className="mb-3 p-3 rounded-xl bg-gradient-to-r from-indigo-50 via-blue-50 to-purple-50 border border-indigo-200/90 text-xs shadow-xs animate-in fade-in duration-150">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2 text-indigo-700 font-semibold">
                <Radio className="w-3.5 h-3.5 text-rose-500 animate-spin" />
                <span>កំពុងស្ដាប់សំឡេង ({speechLang === 'km-KH' ? 'ភាសាខ្មែរ' : 'English'})... សូមនិយាយ៖</span>
              </div>
              <button
                type="button"
                onClick={stopListening}
                className="text-[11px] text-slate-400 hover:text-slate-600 p-0.5"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="text-slate-800 font-medium pl-5 min-h-[20px] italic">
              {interimTranscript ? (
                <span className="text-blue-900 bg-white/70 px-2 py-0.5 rounded border border-blue-200/60 font-semibold">
                  "{interimTranscript}"
                </span>
              ) : (
                <span className="text-slate-400">សូមនិយាយខ្លឹមសារ... ពាក្យសម្ដីរបស់អ្នកនឹងបំលែងជាអក្សរដោយស្វ័យប្រវត្ត</span>
              )}
            </div>
          </div>
        )}

        {/* Voice Error Notification */}
        {voiceError && (
          <div className="mb-3 p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{voiceError}</span>
            </div>
            <button
              type="button"
              onClick={() => setVoiceError(null)}
              className="text-rose-500 hover:text-rose-800 p-1 rounded-md"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Textarea for Direct Editing */}
        <textarea
          ref={textareaRef}
          value={content}
          onChange={(e) => onChangeContent(e.target.value)}
          placeholder="បញ្ចូលខ្លឹមសារនៅទីនេះ, ចុច 'និយាយបញ្ចូលសំឡេង (Voice)', ឬប្រើប៊ូតុង 'សរសេរស្វ័យប្រវត្ត' ដើម្បីឱ្យ AI ជួយរៀបចំ..."
          rows={12}
          className="w-full p-4 text-sm leading-relaxed text-slate-800 bg-slate-50/30 hover:bg-slate-50/60 focus:bg-white border border-slate-200 rounded-xl outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/10 font-kantumruy transition-all resize-y shadow-inner"
        />
      </div>

      {/* Embedded Action Matrix Table for Section 5 */}
      {isActionChapter && (
        <div className="p-4 sm:p-5 border-t border-slate-200 bg-slate-50/40 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-slate-800 font-kantumruy">
                តារាងម៉ាទ្រីសសកម្មភាពអនុវត្ត (Chapter 5 Implementation Matrix)
              </h3>
              <p className="text-xs text-slate-500">
                តារាងលម្អិត ៧១ សកម្មភាពអនុវត្តតាមស្តង់ដាទាំង ៥ និងសកម្មភាពគន្លឹះ នៃក្រសួងអប់រំ យុវជន និងកីឡា
              </p>
            </div>

            <div className="flex items-center bg-white p-1 rounded-xl border border-slate-200 text-xs font-medium shadow-2xs">
              <button
                type="button"
                onClick={() => setActionViewType('dashboard')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors ${
                  actionViewType === 'dashboard'
                    ? 'bg-blue-600 text-white font-semibold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <BarChart3 className="w-3.5 h-3.5" />
                <span>ផ្ទាំងវឌ្ឍនភាព (Dashboard)</span>
              </button>
              <button
                type="button"
                onClick={() => setActionViewType('detailed71')}
                className={`px-3 py-1.5 rounded-lg transition-colors ${
                  actionViewType === 'detailed71'
                    ? 'bg-blue-600 text-white font-semibold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                តារាងផ្លូវការ ៧១ សកម្មភាព
              </button>
              <button
                type="button"
                onClick={() => setActionViewType('concise')}
                className={`px-3 py-1.5 rounded-lg transition-colors ${
                  actionViewType === 'concise'
                    ? 'bg-blue-600 text-white font-semibold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                តារាងសង្ខេប
              </button>
            </div>
          </div>

          {actionViewType === 'dashboard' ? (
            <ActionMatrixDashboard
              items={actionMatrix || []}
              onChangeItems={onChangeActionMatrix}
              onOpenTableEdit={() => setActionViewType('concise')}
            />
          ) : actionViewType === 'detailed71' && chapterFiveActions && onChangeChapterFiveActions ? (
            <ChapterFiveActionTable
              groups={chapterFiveActions}
              onChangeGroups={onChangeChapterFiveActions}
              onAiAutoAssign={() => {
                // Friendly AI auto-assignment toast or quick tweak
              }}
              isAiLoading={isLoadingAi}
            />
          ) : actionMatrix && onChangeActionMatrix ? (
            <ActionMatrixTable
              items={actionMatrix}
              onChange={onChangeActionMatrix}
              onGenerateAiRows={onGenerateAiRows || (() => {})}
              isGenerating={isLoadingAi}
              onOpenDashboard={() => setActionViewType('dashboard')}
            />
          ) : null}
        </div>
      )}

      {/* Embedded Official Standards & Indicators Budget Table for Section 4 */}
      {isStandardFourChapter && standardTargets && onChangeStandardTargets && (
        <div className="p-4 sm:p-5 border-t border-slate-200 bg-slate-50/40">
          <div className="mb-4">
            <h3 className="text-sm font-bold text-slate-800 font-kantumruy">
              តារាងស្តង់ដា និងសូចនាករគ្រោងថវិកា (ឆ្នាំ N+1) តាមនិយាមក្រសួងអប់រំ យុវជន និងកីឡា
            </h3>
            <p className="text-xs text-slate-500">
              តារាងគណនាសូចនាករស្តង់ដាទាំង ៥ និងថវិកាអនុវត្ត (ថវិការដ្ឋ និងថវិកាក្រៅពីរដ្ឋ) សរុប ១៣,៩០៣,១០០ រៀល
            </p>
          </div>
          <StandardFourTable
            standards={standardTargets}
            onChangeStandards={onChangeStandardTargets}
            onAiAutoFill={onAiAutoFillStandards}
            isAiLoading={isLoadingAi}
          />
        </div>
      )}
    </div>
  );
};
