import React, { useState } from 'react';
import { 
  X, 
  Download, 
  FileText, 
  ExternalLink, 
  Copy, 
  Printer, 
  CheckCircle2, 
  FileCode,
  AlertCircle,
  HelpCircle
} from 'lucide-react';
import { PlanData } from '../types/plan';
import { generatePlanHtmlDocument } from '../utils/documentGenerator';
import { 
  downloadFileUniversal,
  downloadBlob, 
  openHtmlInNewWindow, 
  copyRichHtmlToClipboard, 
  sanitizeFileName,
  printHtmlSafely
} from '../utils/fileDownloader';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  plan: PlanData;
  onPrint: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  plan,
  onPrint,
}) => {
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);
  const [copySuccess, setCopySuccess] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const safeSchoolName = sanitizeFileName(plan.schoolName || 'សាលាបឋមសិក្សា', 'សាលារៀន');
  const safeYear = sanitizeFileName(plan.academicYear || '២០២៤-២០២៥', '២០២៤-២០២៥');
  const docxFileName = `AOP_${safeYear}_${safeSchoolName}.doc`;
  const htmlFileName = `AOP_${safeYear}_${safeSchoolName}.html`;

  // 1. Direct Word (.doc) Download with Server-Backed Fallback
  const handleDownloadWord = async () => {
    try {
      setErrorMessage(null);
      const htmlContent = generatePlanHtmlDocument(plan);
      const success = await downloadFileUniversal({
        fileName: docxFileName,
        content: htmlContent,
        contentType: 'application/msword; charset=utf-8',
      });
      if (success) {
        setDownloadSuccess(true);
        setTimeout(() => setDownloadSuccess(false), 4000);
      } else {
        setErrorMessage('មិនអាចទាញយកដោយផ្ទាល់បានទេ។ សូមសាកល្បងជម្រើស «ចម្លងទម្រង់សម្រាប់ Word» ឬ «បោះពុម្ព» ខាងក្រោម។');
      }
    } catch (err) {
      console.error(err);
      setErrorMessage('មានបញ្ហាក្នុងការបង្កើតឯកសារ Word។ សូមសាកល្បងជម្រើស «ចម្លងទម្រង់» ខាងក្រោម។');
    }
  };

  // 2. Direct HTML Download
  const handleDownloadHtml = async () => {
    try {
      setErrorMessage(null);
      const htmlContent = generatePlanHtmlDocument(plan);
      await downloadFileUniversal({
        fileName: htmlFileName,
        content: htmlContent,
        contentType: 'text/html; charset=utf-8',
      });
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 4000);
    } catch (err) {
      console.error(err);
      setErrorMessage('មិនអាចទាញយក HTML បានទេ។');
    }
  };

  // 3. Open in New Tab (Immune to iframe restrictions)
  const handleOpenInNewTab = () => {
    try {
      setErrorMessage(null);
      const htmlContent = generatePlanHtmlDocument(plan);
      openHtmlInNewWindow(htmlContent, `${plan.title} - ${plan.schoolName}`);
    } catch (err) {
      console.error(err);
      setErrorMessage('មិនអាចបើកក្នុងផ្ទាំងថ្មីបានទេ។ សូមពិនិត្យមើល Popup Blocker ក្នុងកម្មវិធីរុករក។');
    }
  };

  // 4. Copy Rich HTML for Word / Google Docs
  const handleCopyRichText = async () => {
    try {
      setErrorMessage(null);
      const htmlContent = generatePlanHtmlDocument(plan);
      
      // Plain text fallback
      let plainText = `${plan.title}\n${plan.schoolName} - ${plan.academicYear}\n\n`;
      plan.sections.forEach(s => {
        plainText += `${s.code}. ${s.title}\n${s.content || ''}\n\n`;
      });

      const success = await copyRichHtmlToClipboard(htmlContent, plainText);
      if (success) {
        setCopySuccess(true);
        setTimeout(() => setCopySuccess(false), 3500);
      }
    } catch (err) {
      console.error(err);
      setErrorMessage('មិនអាចចម្លងទម្រង់អត្ថបទបានទេ។');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200 animate-in zoom-in-95 duration-200">
        
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white/10 rounded-xl backdrop-blur-xs">
              <Download className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base font-bold font-kantumruy">ទាញយក និងនាំចេញឯកសារផែនការ</h3>
              <p className="text-xs text-blue-100 font-kantumruy">ជ្រើសរើសជម្រើសនាំចេញដែលសមស្របសម្រាប់លោកអ្នក</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 font-kantumruy space-y-4 max-h-[80vh] overflow-y-auto">
          {errorMessage && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div>{errorMessage}</div>
            </div>
          )}

          {/* Primary Action: Word (.doc) Download */}
          <div className="p-4 bg-gradient-to-br from-blue-50 to-indigo-50/50 rounded-2xl border border-blue-200 shadow-xs">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-md shadow-blue-500/25 shrink-0">
                  <FileText className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                    ទាញយកជាឯកសារ Word (.doc)
                    <span className="text-[10px] bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-medium">ណែនាំ</span>
                  </h4>
                  <p className="text-xs text-slate-600 mt-0.5">
                    បើកកែសម្រួលបានពេញលេញក្នុង Microsoft Word & Google Docs
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-3.5">
              <button
                onClick={handleDownloadWord}
                className={`w-full py-2.5 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md ${
                  downloadSuccess 
                    ? 'bg-emerald-600 text-white shadow-emerald-500/25' 
                    : 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-500/25 hover:scale-[1.01] active:scale-[0.99]'
                }`}
              >
                {downloadSuccess ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-white" />
                    <span>ទាញយកជោគជ័យ! ({docxFileName})</span>
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4" />
                    <span>ទាញយកឯកសារ Word ឥឡូវនេះ</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Fallback & Alternative Options (Solves any browser download blocker) */}
          <div className="space-y-2.5">
            <div className="text-xs font-bold text-slate-700 px-1 flex items-center gap-1.5">
              <HelpCircle className="w-3.5 h-3.5 text-slate-400" />
              <span>ជម្រើសបន្ថែម (ប្រសិនបើ Browser រារាំងការទាញយក)</span>
            </div>

            {/* Option 2: Open in New Tab */}
            <div className="flex items-center justify-between p-3 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-50 text-indigo-700 rounded-lg shrink-0">
                  <ExternalLink className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-800">បើកមើលក្នុងផ្ទាំងថ្មី (New Tab)</div>
                  <div className="text-[11px] text-slate-500">បើកមើលទម្រង់ទាំងមូល រួចចុច Ctrl+S ដើម្បីរក្សាទុក</div>
                </div>
              </div>
              <button
                onClick={handleOpenInNewTab}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors shrink-0"
              >
                បើកផ្ទាំងថ្មី
              </button>
            </div>

            {/* Option 3: Copy Formatted Content */}
            <div className="flex items-center justify-between p-3 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-emerald-50 text-emerald-700 rounded-lg shrink-0">
                  {copySuccess ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-800">
                    {copySuccess ? 'បានចម្លងរួចរាល់!' : 'ចម្លងទម្រង់អត្ថបទពេញលេញ'}
                  </div>
                  <div className="text-[11px] text-slate-500">សម្រាប់ Paste (Ctrl+V) ចូល Word ដោយរក្សាពណ៌ និងតារាង</div>
                </div>
              </div>
              <button
                onClick={handleCopyRichText}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors shrink-0 ${
                  copySuccess 
                    ? 'bg-emerald-600 text-white' 
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {copySuccess ? 'បានចម្លង' : 'ចម្លងអត្ថបទ'}
              </button>
            </div>

            {/* Option 4: Print / Save as PDF */}
            <div className="flex items-center justify-between p-3 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-purple-50 text-purple-700 rounded-lg shrink-0">
                  <Printer className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-800">បោះពុម្ព ឬរក្សាទុកជា PDF</div>
                  <div className="text-[11px] text-slate-500">បើកប្រព័ន្ធបោះពុម្ព និង Print to PDF ផ្លូវការ</div>
                </div>
              </div>
              <button
                onClick={() => {
                  onClose();
                  onPrint();
                }}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors shrink-0"
              >
                បោះពុម្ព
              </button>
            </div>

            {/* Option 5: Download HTML file */}
            <div className="flex items-center justify-between p-3 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-slate-100 text-slate-700 rounded-lg shrink-0">
                  <FileCode className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-800">ទាញយកជាឯកសារ HTML (.html)</div>
                  <div className="text-[11px] text-slate-500">ឯកសារបណ្ដាញពេញលេញសម្រាប់រក្សាទុក ឬបើកក្នុង Word</div>
                </div>
              </div>
              <button
                onClick={handleDownloadHtml}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors shrink-0"
              >
                ទាញយក
              </button>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 px-5 py-3 border-t border-slate-200 flex items-center justify-between font-kantumruy">
          <div className="text-[11px] text-slate-500">
            គាំទ្រស្តង់ដា MoEYS AOP & ៥ ស្តង់ដារបឋមសិក្សា
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 font-semibold text-xs rounded-xl transition-colors shadow-2xs"
          >
            បិទ
          </button>
        </div>

      </div>
    </div>
  );
};
