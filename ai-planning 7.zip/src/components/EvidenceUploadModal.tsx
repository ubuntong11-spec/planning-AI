import React, { useState, useRef } from 'react';
import { 
  X, 
  Upload, 
  Camera, 
  Image as ImageIcon, 
  FileText, 
  Check, 
  AlertCircle,
  File,
  FileSpreadsheet,
  FileCheck,
  BookOpen,
  Calendar,
  Users,
  Award
} from 'lucide-react';
import { EvidenceItem, EvidenceType } from '../types/assessment';

interface EvidenceUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  indicatorCode: string;
  indicatorTitle: string;
  onSaveEvidence: (evidence: EvidenceItem) => void;
  initialEvidence?: EvidenceItem | null;
}

const EVIDENCE_TYPE_OPTIONS: { type: EvidenceType; label: string; icon: any; color: string }[] = [
  { type: 'report', label: 'របាយការណ៍', icon: FileText, color: 'text-blue-600 bg-blue-50 border-blue-200' },
  { type: 'photo', label: 'រូបភាពសកម្មភាព', icon: ImageIcon, color: 'text-emerald-600 bg-emerald-50 border-emerald-200' },
  { type: 'official_letter', label: 'លិខិតបទដ្ឋាន / បង្គាប់ការ', icon: FileCheck, color: 'text-indigo-600 bg-indigo-50 border-indigo-200' },
  { type: 'attendance', label: 'បញ្ជីវត្តមាន', icon: Users, color: 'text-purple-600 bg-purple-50 border-purple-200' },
  { type: 'agreement', label: 'កិច្ចព្រមព្រៀង / MOU', icon: Award, color: 'text-amber-600 bg-amber-50 border-amber-200' },
  { type: 'minutes', label: 'កំណត់ហេតុប្រជុំ', icon: Calendar, color: 'text-teal-600 bg-teal-50 border-teal-200' },
  { type: 'tracking_book', label: 'សៀវភៅតាមដាន', icon: BookOpen, color: 'text-sky-600 bg-sky-50 border-sky-200' },
  { type: 'curriculum_plan', label: 'កិច្ចតែងការ / ផែនការ', icon: FileSpreadsheet, color: 'text-rose-600 bg-rose-50 border-rose-200' },
  { type: 'other', label: 'ឯកសារផ្សេងៗ', icon: File, color: 'text-slate-600 bg-slate-50 border-slate-200' },
];

export const EvidenceUploadModal: React.FC<EvidenceUploadModalProps> = ({
  isOpen,
  onClose,
  indicatorCode,
  indicatorTitle,
  onSaveEvidence,
  initialEvidence,
}) => {
  const [selectedType, setSelectedType] = useState<EvidenceType>(initialEvidence?.type || 'report');
  const [title, setTitle] = useState<string>(initialEvidence?.title || '');
  const [fileName, setFileName] = useState<string>(initialEvidence?.fileName || '');
  const [fileData, setFileData] = useState<string | undefined>(initialEvidence?.fileData);
  const [fileType, setFileType] = useState<string | undefined>(initialEvidence?.fileType);
  const [fileSize, setFileSize] = useState<number | undefined>(initialEvidence?.fileSize);
  const [error, setError] = useState<string | null>(null);

  const cameraInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check size limit: max 15MB for base64 storage
    if (file.size > 15 * 1024 * 1024) {
      setError('ឯកសារមានទំហំធំពេក (លើសពី 15MB)។ សូមជ្រើសរើសឯកសារតូចជាងនេះ។');
      return;
    }

    setError(null);
    setFileName(file.name);
    setFileType(file.type || 'application/octet-stream');
    setFileSize(file.size);

    // Auto-fill title if empty
    if (!title.trim()) {
      const cleanName = file.name.replace(/\.[^/.]+$/, '');
      setTitle(cleanName);
    }

    const reader = new FileReader();
    reader.onload = (loadEvt) => {
      const base64 = loadEvt.target?.result as string;
      setFileData(base64);
    };
    reader.onerror = () => {
      setError('មានបញ្ហាក្នុងការអានឯកសារ។ សូមព្យាយាមម្តងទៀត។');
    };
    reader.readAsDataURL(file);
  };

  const handleSave = () => {
    if (!title.trim()) {
      setError('សូមសរសេរឈ្មោះឯកសារភស្តុតាង');
      return;
    }

    const finalFileName = fileName || `${title}.pdf`;
    const newItem: EvidenceItem = {
      id: initialEvidence?.id || `ev-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      type: selectedType,
      title: title.trim(),
      fileName: finalFileName,
      fileData: fileData || '',
      fileType: fileType || (finalFileName.endsWith('.pdf') ? 'application/pdf' : 'image/jpeg'),
      fileSize: fileSize || 102400,
      uploadedAt: new Date().toLocaleDateString('km-KH'),
    };

    onSaveEvidence(newItem);
    onClose();
  };

  const formatFileSize = (bytes?: number) => {
    if (!bytes) return '';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto font-kantumruy">
      <div className="bg-white w-full max-w-xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 text-white flex items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-md bg-white/20 text-xs font-mono font-bold tracking-wider">
                {indicatorCode}
              </span>
              <h3 className="font-bold text-base sm:text-lg">
                {initialEvidence ? 'កែសម្រួលភស្តុតាង' : 'ផ្ទុកឯកសារភស្តុតាងថ្មី'}
              </h3>
            </div>
            <p className="text-xs text-blue-100 mt-1 line-clamp-1">
              {indicatorTitle}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-5 space-y-5 max-h-[75vh] overflow-y-auto text-xs sm:text-sm">
          {error && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* 1. Select Document Type (+ ជ្រើសរើសប្រភេទឯកសារ) */}
          <div className="space-y-2">
            <label className="block font-bold text-slate-800">
              ១. ជ្រើសរើសប្រភេទឯកសារ <span className="text-rose-500">*</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {EVIDENCE_TYPE_OPTIONS.map((opt) => {
                const Icon = opt.icon;
                const isSelected = selectedType === opt.type;
                return (
                  <button
                    key={opt.type}
                    type="button"
                    onClick={() => setSelectedType(opt.type)}
                    className={`flex items-center gap-2 p-2.5 rounded-xl border text-left transition-all text-xs ${
                      isSelected
                        ? 'border-blue-600 bg-blue-50/70 text-blue-900 font-bold ring-2 ring-blue-500/20 shadow-xs'
                        : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className={`p-1.5 rounded-lg border shrink-0 ${opt.color}`}>
                      <Icon className="w-3.5 h-3.5" />
                    </div>
                    <span className="truncate">{opt.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. Document Title Input (សរសេរឈ្មោះឯកសារ) */}
          <div className="space-y-1.5">
            <label className="block font-bold text-slate-800">
              ២. សរសេរឈ្មោះឯកសារ <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="ឧ. របាយការណ៍ចុះឈ្មោះកុមារថ្នាក់ទី១ ឆ្នាំ២០២៥"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-slate-800 placeholder:text-slate-400 text-xs sm:text-sm transition-all"
            />
          </div>

          {/* 3. Upload Buttons (ថតរូបភ្លាម, រូបភាព, File) */}
          <div className="space-y-2">
            <label className="block font-bold text-slate-800">
              ៣. ជ្រើសរើសវិធីសាស្ត្រ Upload ឯកសារ
            </label>

            {/* Hidden Inputs */}
            <input
              ref={cameraInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleFileChange}
              className="hidden"
            />
            <input
              ref={imageInputRef}
              type="file"
              accept="image/jpeg,image/png,image/webp,image/gif"
              onChange={handleFileChange}
              className="hidden"
            />
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.csv,.zip"
              onChange={handleFileChange}
              className="hidden"
            />

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {/* Option A: ថតរូបភ្លាម */}
              <button
                type="button"
                onClick={() => cameraInputRef.current?.click()}
                className="flex flex-col items-center justify-center p-3.5 rounded-xl border-2 border-dashed border-emerald-300 hover:border-emerald-500 bg-emerald-50/60 hover:bg-emerald-50 text-emerald-800 transition-all group"
              >
                <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mb-1.5 group-hover:scale-110 transition-transform shadow-xs">
                  <Camera className="w-5 h-5" />
                </div>
                <span className="font-bold text-xs text-emerald-900">ថតរូបភ្លាម</span>
                <span className="text-[10px] text-emerald-600 mt-0.5">ប្រើកាមេរ៉ាទូរស័ព្ទ</span>
              </button>

              {/* Option B: រូបភាព */}
              <button
                type="button"
                onClick={() => imageInputRef.current?.click()}
                className="flex flex-col items-center justify-center p-3.5 rounded-xl border-2 border-dashed border-blue-300 hover:border-blue-500 bg-blue-50/60 hover:bg-blue-50 text-blue-800 transition-all group"
              >
                <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center mb-1.5 group-hover:scale-110 transition-transform shadow-xs">
                  <ImageIcon className="w-5 h-5" />
                </div>
                <span className="font-bold text-xs text-blue-900">រូបភាព</span>
                <span className="text-[10px] text-blue-600 mt-0.5">JPG, PNG ពីវិចិត្រសាល</span>
              </button>

              {/* Option C: ឯកសារ File */}
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex flex-col items-center justify-center p-3.5 rounded-xl border-2 border-dashed border-indigo-300 hover:border-indigo-500 bg-indigo-50/60 hover:bg-indigo-50 text-indigo-800 transition-all group"
              >
                <div className="w-10 h-10 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center mb-1.5 group-hover:scale-110 transition-transform shadow-xs">
                  <FileText className="w-5 h-5" />
                </div>
                <span className="font-bold text-xs text-indigo-900">ឯកសារ File</span>
                <span className="text-[10px] text-indigo-600 mt-0.5">PDF, Word, Excel</span>
              </button>
            </div>
          </div>

          {/* Uploaded File Indicator / Preview */}
          {fileName && (
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3 animate-in fade-in duration-150">
              <div className="flex items-center gap-3 min-w-0">
                {fileType?.startsWith('image/') && fileData ? (
                  <img
                    src={fileData}
                    alt="Preview"
                    className="w-12 h-12 object-cover rounded-lg border border-slate-300 shadow-2xs shrink-0"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center shrink-0 border border-blue-200">
                    <FileText className="w-6 h-6" />
                  </div>
                )}
                <div className="min-w-0">
                  <div className="font-bold text-slate-800 text-xs truncate">
                    {fileName}
                  </div>
                  <div className="text-[11px] text-slate-500 flex items-center gap-2 mt-0.5">
                    <span>{formatFileSize(fileSize)}</span>
                    <span>•</span>
                    <span className="text-emerald-600 font-medium flex items-center gap-1">
                      <Check className="w-3 h-3" /> បានផ្ទុកឡើងរួចរាល់
                    </span>
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setFileName('');
                  setFileData(undefined);
                  setFileType(undefined);
                  setFileSize(undefined);
                }}
                className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                title="លុបឯកសារដែលបានជ្រើស"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="px-5 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-slate-600 hover:text-slate-800 hover:bg-slate-200/60 font-semibold text-xs sm:text-sm transition-colors"
          >
            បោះបង់
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="flex items-center gap-2 px-5 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-xs sm:text-sm shadow-md shadow-blue-500/25 transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <Check className="w-4 h-4" />
            <span>រក្សាទុកភស្តុតាង</span>
          </button>
        </div>

      </div>
    </div>
  );
};
