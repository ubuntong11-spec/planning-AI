import React, { useState } from 'react';
import { 
  Sparkles, 
  X, 
  School, 
  Calendar, 
  MapPin, 
  Target, 
  AlertCircle, 
  Layers, 
  Check, 
  RefreshCw,
  Building2,
  Upload
} from 'lucide-react';
import { PlanGeneratorParams, SchoolContextProfile } from '../types/plan';

interface PlanGeneratorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGenerate: (params: PlanGeneratorParams) => Promise<void>;
  isGenerating: boolean;
  initialSchoolProfile?: SchoolContextProfile;
  onOpenSchoolContext?: () => void;
}

const PRESETS = [
  {
    label: 'សាលាបឋមសិក្សា (Primary School)',
    schoolName: 'សាលាបឋមសិក្សាគំរូ',
    schoolType: 'សាលាបឋមសិក្សា',
    academicYear: 'ឆ្នាំសិក្សា ២០២៤-២០២៥',
    location: 'រាជធានីភ្នំពេញ',
    priorities: 'លើកកម្ពស់បំណិនអាន និងគណិតវិទ្យាថ្នាក់ដំបូង (EGRA/EGMA), ការអភិវឌ្ឍបណ្ណាល័យស្ដង់ដារ, និងការចូលរួមរបស់សហគមន៍',
    challenges: 'កង្វះសម្ភារឧបទេសបង្រៀន, មាតាបិតាមួយចំនួនខ្វះការតាមដានការរៀនសូត្ររបស់កូននៅផ្ទះ',
    targetGoals: 'បង្កើនអត្រាសិស្សចេះអានស្ទាត់ដល់ ៨៥%, អត្រាជាប់ថ្នាក់ ៩៥%, អត្រាបោះបង់ក្រោម ២%',
  },
  {
    label: 'អនុវិទ្យាល័យ / វិទ្យាល័យ (High School)',
    schoolName: 'វិទ្យាល័យចំណេះទូទៅ និងបច្ចេកទេស',
    schoolType: 'វិទ្យាល័យ',
    academicYear: 'ឆ្នាំសិក្សា ២០២៤-២០២៥',
    location: 'ខេត្តកណ្តាល',
    priorities: 'ពង្រឹងការអប់រំបែបស្ទែម (STEM), ការគ្រប់គ្រងវិន័យសីលធម៌, ការប្រើប្រាស់បច្ចេកវិទ្យាឌីជីថលក្នុងការរៀន និងបង្រៀន',
    challenges: 'កង្វះបន្ទប់ពិសោធន៍វិទ្យាសាស្ត្រទំនើប, សិស្សរៀនយឺតលើមុខវិជ្ជាវិទ្យាសាស្ត្រពិត',
    targetGoals: 'អត្រាប្រឡងជាប់សញ្ញាបត្រមធ្យមសិក្សាទុតិយភូមិ (បាក់ឌុប) សម្រេចបានយ៉ាងតិច ៨៥% និងនិទ្ទេស A, B, C កើនឡើង ១៥%',
  },
  {
    label: 'គម្រោងអប់រំ / អង្គការ (NGO/Project)',
    schoolName: 'គម្រោងលើកកម្ពស់ការអប់រំបរិយាបន្ន',
    schoolType: 'អង្គការមិនមែនរដ្ឋាភិបាល (NGO)',
    academicYear: 'ឆ្នាំ ២០២៥',
    location: 'ខេត្តសៀមរាប',
    priorities: 'គាំទ្រកុមារងាយរងគ្រោះ និងកុមារមានពិការភាពឱ្យទទួលបានការអប់រំប្រកបដោយសមធម៌ និងការកសាងសមត្ថភាពគ្រូ',
    challenges: 'ឧបសគ្គនៃការធ្វើដំណើររបស់កុមាររស់នៅតំបន់ដាច់ស្រយាល និងការយល់ដឹងរបស់អាណាព្យាបាល',
    targetGoals: 'កុមារងាយរងគ្រោះចំនួន ៥០០ នាក់ត្រូវបានគាំទ្រចូលរៀនពេញលេញ និងគ្រូបង្រៀន ៥០ នាក់ទទួលបានការបណ្តុះបណ្តាលគរុកោសល្យបរិយាបន្ន',
  },
];

export const PlanGeneratorModal: React.FC<PlanGeneratorModalProps> = ({
  isOpen,
  onClose,
  onGenerate,
  isGenerating,
  initialSchoolProfile,
  onOpenSchoolContext,
}) => {
  const [params, setParams] = useState<PlanGeneratorParams>({
    schoolName: 'សាលាបឋមសិក្សា អនុវត្តគំរូ',
    academicYear: 'ឆ្នាំសិក្សា ២០២៤-២០២៥',
    location: 'រាជធានីភ្នំពេញ',
    schoolType: 'សាលាបឋមសិក្សា',
    priorities: 'លើកកម្ពស់បំណិនអាន និងគណិតវិទ្យាថ្នាក់ដំបូង, ពង្រឹងការគ្រប់គ្រងតាមសាលារៀន (SBM), និងការកែលម្អបរិស្ថានសាលាស្អាត',
    challenges: initialSchoolProfile?.challenges || 'កង្វះសម្ភារឧបទេសបច្ចេកវិទ្យា, មាតាបិតាសិស្សមួយចំនួនខ្វះពេលវេលាជួយបង្រៀនកូន',
    targetGoals: 'សិស្សជាប់ថ្នាក់ ៩៥%, អត្រាបោះបង់ការសិក្សាថយក្រោម ១.៥%, និងកៀរគរការចូលរួមពីសហគមន៍បានពេញលេញ',
    schoolContextProfile: initialSchoolProfile,
  });

  if (!isOpen) return null;

  const handleApplyPreset = (preset: typeof PRESETS[0]) => {
    setParams({
      schoolName: preset.schoolName,
      academicYear: preset.academicYear,
      location: preset.location,
      schoolType: preset.schoolType,
      priorities: preset.priorities,
      challenges: preset.challenges,
      targetGoals: preset.targetGoals,
      schoolContextProfile: initialSchoolProfile,
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onGenerate(params);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-blue-700 via-indigo-600 to-sky-600 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 backdrop-blur-xs flex items-center justify-center border border-white/20">
              <Sparkles className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold font-kantumruy">
                បង្កើតផែនការប្រតិបត្តិដោយ AI
              </h3>
              <p className="text-xs text-blue-100">
                បំពេញព័ត៌មានស្ថាប័នរបស់អ្នកដើម្បីឱ្យ AI រៀបចំឯកសារពេញលេញតាមស្តង់ដារ
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Preset Selector */}
        <div className="px-6 pt-4 pb-2 border-b border-slate-100 bg-slate-50/70">
          <label className="block text-xs font-semibold text-slate-600 mb-2 font-kantumruy">
            ជ្រើសរើសគំរូរហ័ស (Quick Presets)៖
          </label>
          <div className="flex flex-wrap gap-2">
            {PRESETS.map((p, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleApplyPreset(p)}
                className="px-3 py-1.5 rounded-lg text-xs font-medium bg-white hover:bg-blue-50 hover:text-blue-700 text-slate-700 border border-slate-200 hover:border-blue-300 transition-all font-kantumruy shadow-2xs"
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1 font-kantumruy">
                ឈ្មោះសាលារៀន / ស្ថាប័ន *
              </label>
              <div className="relative">
                <School className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  value={params.schoolName}
                  onChange={(e) => setParams({ ...params, schoolName: e.target.value })}
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-blue-500 focus:bg-white font-kantumruy"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1 font-kantumruy">
                ឆ្នាំសិក្សា / កាលបរិច្ឆេទអនុវត្ត *
              </label>
              <div className="relative">
                <Calendar className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  value={params.academicYear}
                  onChange={(e) => setParams({ ...params, academicYear: e.target.value })}
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-blue-500 focus:bg-white font-kantumruy"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1 font-kantumruy">
                រាជធានី / ខេត្ត / ទីតាំង
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={params.location}
                  onChange={(e) => setParams({ ...params, location: e.target.value })}
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-blue-500 focus:bg-white font-kantumruy"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1 font-kantumruy">
                កម្រិតអប់រំ / ប្រភេទស្ថាប័ន
              </label>
              <div className="relative">
                <Layers className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={params.schoolType}
                  onChange={(e) => setParams({ ...params, schoolType: e.target.value })}
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-blue-500 focus:bg-white font-kantumruy"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1 font-kantumruy">
              ទិសដៅអាទិភាពក្នុងឆ្នាំនេះ (Strategic Priorities)
            </label>
            <textarea
              rows={2}
              value={params.priorities}
              onChange={(e) => setParams({ ...params, priorities: e.target.value })}
              className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-blue-500 focus:bg-white font-kantumruy"
              placeholder="បញ្ជាក់ពីចំណុចអាទិភាព..."
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1 font-kantumruy">
              បញ្ហាប្រឈមចម្បងដែលត្រូវដោះស្រាយ (Key Challenges)
            </label>
            <textarea
              rows={2}
              value={params.challenges}
              onChange={(e) => setParams({ ...params, challenges: e.target.value })}
              className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-blue-500 focus:bg-white font-kantumruy"
              placeholder="បញ្ជាក់ពីបញ្ហាប្រឈម..."
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1 font-kantumruy">
              គោលដៅ និងលទ្ធផលរំពឹងទុក (Expected Targets & KPIs)
            </label>
            <textarea
              rows={2}
              value={params.targetGoals}
              onChange={(e) => setParams({ ...params, targetGoals: e.target.value })}
              className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-blue-500 focus:bg-white font-kantumruy"
              placeholder="បញ្ជាក់ពីសូចនាករ ឬលទ្ធផលរំពឹងទុក..."
            />
          </div>

          {/* School Unique Context & Strengths/Challenges Box */}
          <div className="p-3.5 rounded-xl bg-gradient-to-r from-blue-50/90 to-indigo-50/70 border border-blue-200 text-xs">
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-2 font-bold text-blue-900">
                <Building2 className="w-4 h-4 text-blue-700" />
                <span>បរិបទ និងចំណុចខ្លាំង-ប្រឈមជាក់ស្តែងរបស់សាលា</span>
              </div>
              {onOpenSchoolContext && (
                <button
                  type="button"
                  onClick={() => {
                    onOpenSchoolContext();
                  }}
                  className="flex items-center gap-1 text-[11px] font-bold text-blue-700 hover:text-blue-900 bg-white px-2 py-1 rounded-lg border border-blue-200 shadow-2xs hover:bg-blue-50 transition-colors"
                >
                  <Upload className="w-3 h-3 text-blue-600" />
                  <span>ផ្ទុកឡើង/កែប្រែ</span>
                </button>
              )}
            </div>

            {params.schoolContextProfile && (params.schoolContextProfile.strengths || params.schoolContextProfile.challenges) ? (
              <div className="space-y-1 text-slate-700 text-[11px] bg-white/70 p-2.5 rounded-lg border border-blue-100">
                <p className="line-clamp-2">
                  <span className="font-semibold text-emerald-800">ចំណុចខ្លាំង៖ </span>
                  {params.schoolContextProfile.strengths.slice(0, 120)}...
                </p>
                <p className="line-clamp-2">
                  <span className="font-semibold text-rose-800">បញ្ហាប្រឈម៖ </span>
                  {params.schoolContextProfile.challenges.slice(0, 120)}...
                </p>
                <p className="text-[10px] text-emerald-700 font-semibold pt-0.5 flex items-center gap-1">
                  <Check className="w-3 h-3 text-emerald-600" />
                  <span>AI នឹងប្រើប្រាស់ទិន្នន័យជាក់ស្តែងនេះ ដើម្បីរៀបចំផែនការឱ្យត្រូវនឹងសាលារបស់អ្នក</span>
                </p>
              </div>
            ) : (
              <p className="text-slate-500 text-[11px]">
                មិនទាន់បានផ្ទុកឡើងឯកសារស្ថានភាពសាលាឡើយ។ អ្នកអាចចុច 'ផ្ទុកឡើង/កែប្រែ' ដើម្បីបញ្ចូលរបាយការណ៍សង្ខេបចំណុចខ្លាំង និងប្រឈម។
              </p>
            )}
          </div>

          {/* Footer Actions */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={isGenerating}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-colors"
            >
              បោះបង់
            </button>
            <button
              type="submit"
              disabled={isGenerating}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-sky-600 hover:from-blue-700 hover:to-indigo-700 text-white text-xs sm:text-sm font-bold shadow-md shadow-blue-500/30 transition-all disabled:opacity-50"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>AI កំពុងបង្កើតផែនការពេញលេញ...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>ចាប់ផ្តើមបង្កើតឯកសារទាំងមូល</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
