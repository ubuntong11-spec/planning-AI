import React, { useState } from 'react';
import { 
  Building2, 
  TrendingUp, 
  Coins, 
  PieChart, 
  Share2, 
  Plus, 
  Trash2, 
  Edit3, 
  CheckCircle2, 
  Clock, 
  FileText, 
  ArrowRight, 
  ArrowLeft,
  HelpCircle, 
  AlertCircle, 
  ChevronDown, 
  ChevronUp, 
  Printer,
  Download,
  Presentation,
  Save,
  RotateCcw,
  Sparkles,
  Award,
  Users,
  Calculator,
  Minus,
  Check,
  Copy,
  FileCode,
  Eye,
  EyeOff
} from 'lucide-react';
import { 
  ThreeYearBspPlan, 
  BudgetRequirementPlan, 
  StandardBudgetSummaryItem,
  CommuneInvestmentAsk 
} from '../types/bsp';
import { 
  OFFICIAL_BSP_STANDARDS, 
  OFFICIAL_BSP_STRUCTURED_STANDARDS,
  BspTableRow,
  BspStandardStructured,
  OFFICIAL_BSP_HEADER_HTML, 
  OFFICIAL_BSP_TOTAL_TR_HTML,
  DEFAULT_BUDGET_REQUIREMENT_PLAN 
} from '../data/officialBspTableData';
import { generateBspFullHtmlDocument } from '../utils/documentGenerator';
import { 
  downloadFileUniversal, 
  downloadBlob, 
  sanitizeFileName,
  printHtmlSafely,
  copyRichHtmlToClipboard 
} from '../utils/fileDownloader';

interface ThreeYearBspViewProps {
  bspPlan: ThreeYearBspPlan;
  onChangeBspPlan: (updatedPlan: ThreeYearBspPlan) => void;
  onSyncYear1ToAop: () => void;
  onStartMeetingWalkthrough: () => void;
}

export const ThreeYearBspView: React.FC<ThreeYearBspViewProps> = ({
  bspPlan,
  onChangeBspPlan,
  onSyncYear1ToAop,
  onStartMeetingWalkthrough,
}) => {
  // Navigation tabs: Slide view (one standard at a time), Full official table, Commune CIP asks, Summary
  const [activeTab, setActiveTab] = useState<'slides' | 'full_table' | 'commune_asks' | 'budget_summary'>('slides');
  const [activeStandardIndex, setActiveStandardIndex] = useState<number>(0); // 0 to 4 for Standards 1-5
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Top Overview sections visibility (Banner + 4 KPI cards) - can be hidden so table slides up
  const [showTopOverview, setShowTopOverview] = useState<boolean>(true);

  // Structured table data with 26 key categories and 70 sub-indicators
  const [tableStandards, setTableStandards] = useState<BspStandardStructured[]>(OFFICIAL_BSP_STRUCTURED_STANDARDS);

  // Row Filter Visibility Toggles (user request: ស្រី-ប្រុស, សូចនាករគន្លឹះ ២៦, សូចនាកររង ៧០)
  const [showGenderRows, setShowGenderRows] = useState<boolean>(true);
  const [showKeyIndicators, setShowKeyIndicators] = useState<boolean>(true);
  const [showSubIndicators, setShowSubIndicators] = useState<boolean>(true);

  // Interactive Editable Mode (user request: មុខងារកែសម្រួលបានសម្រាប់វិនិយោគ)
  const [isEditMode, setIsEditMode] = useState<boolean>(false);

  // Update a single table cell dynamically
  const handleUpdateTableCell = (
    standardNumber: number,
    rowId: string,
    field: keyof BspTableRow,
    value: any
  ) => {
    setTableStandards(prev => prev.map(std => {
      if (std.standardNumber !== standardNumber) return std;
      const updatedRows = std.rows.map(row => {
        if (row.id !== rowId) return row;
        return { ...row, [field]: value };
      });
      return { ...std, rows: updatedRows };
    }));
  };

  // Reset table data to official defaults
  const handleResetTableData = () => {
    setTableStandards(OFFICIAL_BSP_STRUCTURED_STANDARDS);
    showToast('បានកំណត់ទិន្នន័យតារាងឡើងវិញទៅទម្រង់ដើម');
  };

  // Dynamically calculate standard total N+1
  const getStandardTotalNplus1 = (std: BspStandardStructured) => {
    const subRows = std.rows.filter(r => r.rowType === 'sub_indicator');
    if (subRows.length > 0) {
      return subRows.reduce((sum, r) => sum + (Number(r.budgetNplus1) || 0), 0);
    }
    return std.rows.filter(r => r.rowType === 'key_indicator').reduce((sum, r) => sum + (Number(r.budgetNplus1) || 0), 0);
  };

  // Dynamically calculate Grand Total N+1
  const calculatedGrandTotalNplus1 = tableStandards.reduce((sum, s) => sum + getStandardTotalNplus1(s), 0);

  // Collapsed standards in Full Table view (standardNumber -> boolean)
  // Standards 2-5 are collapsed by default so user is not overwhelmed by 129 rows
  const [collapsedStandards, setCollapsedStandards] = useState<Record<number, boolean>>({
    2: true,
    3: true,
    4: true,
    5: true,
  });

  // Teaching / Presentation Step-by-Step Mode in Full Table
  const [teachingModeActive, setTeachingModeActive] = useState<boolean>(true);
  const [focusedStandardNumber, setFocusedStandardNumber] = useState<number>(1);

  // Toggle standard collapse individually
  const toggleStandardCollapse = (standardNumber: number) => {
    setCollapsedStandards(prev => ({
      ...prev,
      [standardNumber]: !prev[standardNumber]
    }));
  };

  // Select standard in Accordion Stepper Mode:
  // Fulfills user request: When user clicks next standard, the previous standard collapses/hides,
  // the new standard expands, and it pulls/scrolls smoothly to the top of the viewport!
  const handleSelectStandardAccordion = (standardNumber: number) => {
    const isCurrentlyOpen = !collapsedStandards[standardNumber];
    if (isCurrentlyOpen) {
      // If clicked on an already open standard, collapse it
      setCollapsedStandards(prev => ({
        ...prev,
        [standardNumber]: true
      }));
      showToast(`បានបង្រួម${OFFICIAL_BSP_STANDARDS.find(s => s.standardNumber === standardNumber)?.code || 'ស្តង់ដា'}`);
      return;
    }

    // Otherwise collapse all other standards and open only this target standard
    const updatedCollapsed: Record<number, boolean> = {
      1: true,
      2: true,
      3: true,
      4: true,
      5: true,
    };
    updatedCollapsed[standardNumber] = false; // Open target standard
    setCollapsedStandards(updatedCollapsed);
    setFocusedStandardNumber(standardNumber);

    showToast(`កំពុងបង្ហាញ៖ ស្តង់ដាទី ${standardNumber}`);

    // Smoothly scroll the opened standard up to the top of the viewport
    setTimeout(() => {
      const el = document.getElementById(`standard-row-anchor-${standardNumber}`);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 120);
  };

  // Collapse all standards
  const collapseAllStandards = () => {
    const allCollapsed: Record<number, boolean> = {};
    OFFICIAL_BSP_STANDARDS.forEach(s => {
      allCollapsed[s.standardNumber] = true;
    });
    setCollapsedStandards(allCollapsed);
    showToast('បានលាក់ខ្លឹមសារស្តង់ដាទាំងអស់ (សល់តែចំណងជើង)');
  };

  // Expand all standards
  const expandAllStandards = () => {
    setCollapsedStandards({});
    showToast('បានពន្លាតស្តង់ដាទាំងអស់ (បង្ហាញ ១២៩ ជួរ)');
  };

  // Focus standard for teaching/presentation
  const handleFocusStandardTeaching = (standardNumber: number) => {
    handleSelectStandardAccordion(standardNumber);
  };

  // Budget Requirement & Gap state
  const budgetReq: BudgetRequirementPlan = bspPlan.budgetRequirement || DEFAULT_BUDGET_REQUIREMENT_PLAN;

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const formatRiel = (amount: number) => {
    return (amount || 0).toLocaleString('km-KH') + ' ៛';
  };

  // State PB Calculation: studentCount * perStudentRateRiel
  const calculatedStateBudget = (budgetReq.studentCount || 0) * (budgetReq.perStudentRateRiel || 0);

  // Totals of all 5 standards in the requirement summary
  const totalBudgetNminus1 = budgetReq.standardsSummary.reduce((acc, s) => acc + (s.budgetNminus1 || 0), 0);
  const totalBudgetN = budgetReq.standardsSummary.reduce((acc, s) => acc + (s.budgetN || 0), 0);
  const totalBudgetNplus1 = budgetReq.standardsSummary.reduce((acc, s) => acc + (s.budgetNplus1 || 0), 0);
  const totalBudgetNplus2 = budgetReq.standardsSummary.reduce((acc, s) => acc + (s.budgetNplus2 || 0), 0);
  const totalBudgetNplus3 = budgetReq.standardsSummary.reduce((acc, s) => acc + (s.budgetNplus3 || 0), 0);

  // Funding gap for Year N+1 (Total Needed - State PB)
  const fundingGapYear1 = Math.max(0, totalBudgetNplus1 - calculatedStateBudget);
  const totalFundingAsked = (budgetReq.communeCipAskTotal || 0) + (budgetReq.communityContributionTotal || 0);
  const remainingShortfall = fundingGapYear1 - totalFundingAsked;

  // Handler to update Budget Requirement Plan
  const handleUpdateBudgetReq = (updated: Partial<BudgetRequirementPlan>) => {
    const newBudgetReq: BudgetRequirementPlan = {
      ...budgetReq,
      ...updated,
    };
    onChangeBspPlan({
      ...bspPlan,
      budgetRequirement: newBudgetReq,
      updatedAt: new Date().toISOString(),
    });
  };

  // Handler to adjust standard row amount in the summary table
  const handleUpdateStandardAmount = (stdId: string, field: keyof StandardBudgetSummaryItem, value: number) => {
    const updatedSummary = budgetReq.standardsSummary.map(item => {
      if (item.id === stdId) {
        return { ...item, [field]: value };
      }
      return item;
    });
    handleUpdateBudgetReq({ standardsSummary: updatedSummary });
  };

  // Current Standard Section for Slide View
  const currentStd = tableStandards[activeStandardIndex] || tableStandards[0];

  // Helper to build live table rows HTML from current tableStandards (including user edits and filter status)
  const buildLiveTableRowsHtml = () => {
    return tableStandards.map(s => {
      const stdTotal = getStandardTotalNplus1(s);
      
      const visibleRows = s.rows.filter(r => {
        if (r.rowType === 'gender_breakdown' && !showGenderRows) return false;
        if (r.rowType === 'key_indicator' && !showKeyIndicators) return false;
        if (r.rowType === 'sub_indicator' && !showSubIndicators) return false;
        return true;
      });

      const headerTrHtml = `
        <tr style="background-color: #1e3a8a; color: #ffffff; font-weight: bold; font-family: 'Kantumruy Pro', 'Khmer OS Siemreap', sans-serif;">
          <td colspan="2" style="border: 1px solid #334155; padding: 6px 8px; text-align: left;">
            ${s.code}៖ ${s.title}
          </td>
          <td style="border: 1px solid #334155; padding: 6px 8px; text-align: right; background-color: #1d4ed8; color: #ffffff;">
            ${stdTotal > 0 ? stdTotal.toLocaleString('km-KH') : ''}
          </td>
          <td style="border: 1px solid #334155; text-align: center;">-</td>
          <td style="border: 1px solid #334155; text-align: center;">-</td>
          <td style="border: 1px solid #334155; padding: 6px 8px; text-align: right; background-color: #1d4ed8; color: #ffffff;">
            ${stdTotal > 0 ? stdTotal.toLocaleString('km-KH') : ''}
          </td>
          <td style="border: 1px solid #334155; text-align: center;">-</td>
          <td style="border: 1px solid #334155; text-align: center;">-</td>
          <td style="border: 1px solid #334155; text-align: center;">-</td>
        </tr>
      `;

      const rowsHtml = visibleRows.map(r => {
        const isKey = r.rowType === 'key_indicator';
        const isGender = r.rowType === 'gender_breakdown';
        const bg = isKey ? '#f1f5f9' : isGender ? '#f8fafc' : '#ffffff';
        const fw = isKey ? 'bold' : 'normal';
        const fontStyle = isGender ? 'italic' : 'normal';
        const pl = isGender ? '24px' : isKey ? '4px' : '10px';

        return `
          <tr style="background-color: ${bg}; font-family: 'Kantumruy Pro', 'Khmer OS Siemreap', sans-serif;">
            <td style="border: 1px solid #94a3b8; text-align: center; padding: 4px; font-weight: ${fw};">${r.code}</td>
            <td style="border: 1px solid #94a3b8; padding: 4px 6px; padding-left: ${pl}; font-weight: ${fw}; font-style: ${fontStyle};">${r.title}</td>
            <td style="border: 1px solid #94a3b8; text-align: right; padding: 4px 6px; font-weight: ${r.budgetNplus1 > 0 ? 'bold' : 'normal'};">
              ${r.budgetNplus1 > 0 ? r.budgetNplus1.toLocaleString('km-KH') : ''}
            </td>
            <td style="border: 1px solid #94a3b8; text-align: center; padding: 4px;">${r.targetNminus1 || ''}</td>
            <td style="border: 1px solid #94a3b8; text-align: center; padding: 4px;">${r.targetN || ''}</td>
            <td style="border: 1px solid #94a3b8; text-align: right; padding: 4px 6px; font-weight: ${r.targetNplus1Budget > 0 ? 'bold' : 'normal'};">
              ${r.targetNplus1Budget > 0 ? r.targetNplus1Budget.toLocaleString('km-KH') : ''}
            </td>
            <td style="border: 1px solid #94a3b8; padding: 4px 6px; font-size: 8pt; white-space: pre-line;">${r.reasonOrActivities || ''}</td>
            <td style="border: 1px solid #94a3b8; text-align: center; padding: 4px;">${r.targetNplus2 || ''}</td>
            <td style="border: 1px solid #94a3b8; text-align: center; padding: 4px;">${r.targetNplus3 || ''}</td>
          </tr>
        `;
      }).join('\n');

      return headerTrHtml + '\n' + rowsHtml;
    }).join('\n');
  };

  // Helper to get complete HTML document for BSP
  const getFullBspHtmlDocument = () => {
    const allStandardsBodyHtml = buildLiveTableRowsHtml();

    const dynamicGrandTotalTr = `
      <tr style="background-color: #dbeafe; font-weight: bold; font-family: 'Kantumruy Pro', 'Khmer OS Siemreap', sans-serif;">
        <td colspan="2" style="border: 1px solid #3b82f6; padding: 6px 8px; text-align: left;">
          សរុបរួម (Grand Total) - ៥ ស្តង់ដាសាលារៀន (២៦ សូចនាករគន្លឹះ និង ៧០ សូចនាកររង)
        </td>
        <td style="border: 1px solid #3b82f6; padding: 6px 8px; text-align: right; color: #1e3a8a;">
          ${calculatedGrandTotalNplus1.toLocaleString('km-KH')}
        </td>
        <td style="border: 1px solid #3b82f6; text-align: center;">-</td>
        <td style="border: 1px solid #3b82f6; text-align: center;">-</td>
        <td style="border: 1px solid #3b82f6; padding: 6px 8px; text-align: right; color: #1e3a8a;">
          ${calculatedGrandTotalNplus1.toLocaleString('km-KH')}
        </td>
        <td style="border: 1px solid #3b82f6; text-align: center;">-</td>
        <td style="border: 1px solid #3b82f6; text-align: center;">-</td>
        <td style="border: 1px solid #3b82f6; text-align: center;">-</td>
      </tr>
    `;

    const fullTableInnerHtml = `
      <tbody>
        ${OFFICIAL_BSP_HEADER_HTML}
        ${dynamicGrandTotalTr}
        ${allStandardsBodyHtml}
      </tbody>
    `;

    const summaryTableHtml = `
      <div style="margin-top: 25px; page-break-inside: avoid;">
        <h3 style="font-size: 11pt; color: #1e3a8a; border-bottom: 2px solid #2563eb; padding-bottom: 4px; margin-bottom: 8px;">
          តារាងតម្រូវការថវិកា ៣ ឆ្នាំ (Budget Requirements & Gap Analysis Summary)
        </h3>
        <table style="width: 100%; border-collapse: collapse; font-size: 8.5pt;">
          <thead>
            <tr style="background-color: #f1f5f9;">
              <th style="border: 1px solid #475569; padding: 4px;">ល.រ</th>
              <th style="border: 1px solid #475569; padding: 4px;">ស្តង់ដាគន្លឹះទាំង ៥</th>
              <th style="border: 1px solid #475569; padding: 4px;">ឆ្នាំ N-1</th>
              <th style="border: 1px solid #475569; padding: 4px;">ឆ្នាំ N</th>
              <th style="border: 1px solid #475569; padding: 4px; background-color: #dbeafe;">ឆ្នាំ N+1</th>
              <th style="border: 1px solid #475569; padding: 4px;">ឆ្នាំ N+2</th>
              <th style="border: 1px solid #475569; padding: 4px;">ឆ្នាំ N+3</th>
            </tr>
          </thead>
          <tbody>
            ${budgetReq.standardsSummary.map((s, idx) => `
              <tr>
                <td style="border: 1px solid #475569; text-align: center;">${idx + 1}</td>
                <td style="border: 1px solid #475569;">${s.standardCode}៖ ${s.standardTitle}</td>
                <td style="border: 1px solid #475569; text-align: right;">${s.budgetNminus1.toLocaleString('km-KH')} ៛</td>
                <td style="border: 1px solid #475569; text-align: right;">${s.budgetN.toLocaleString('km-KH')} ៛</td>
                <td style="border: 1px solid #475569; text-align: right; background-color: #eff6ff;"><strong>${s.budgetNplus1.toLocaleString('km-KH')} ៛</strong></td>
                <td style="border: 1px solid #475569; text-align: right;">${s.budgetNplus2.toLocaleString('km-KH')} ៛</td>
                <td style="border: 1px solid #475569; text-align: right;">${s.budgetNplus3.toLocaleString('km-KH')} ៛</td>
              </tr>
            `).join('')}
            <tr style="background-color: #e2e8f0; font-weight: bold;">
              <td colspan="2" style="border: 1px solid #475569; text-align: center;">សរុបរួម (Grand Total)</td>
              <td style="border: 1px solid #475569; text-align: right;">${totalBudgetNminus1.toLocaleString('km-KH')} ៛</td>
              <td style="border: 1px solid #475569; text-align: right;">${totalBudgetN.toLocaleString('km-KH')} ៛</td>
              <td style="border: 1px solid #475569; text-align: right; color: #1d4ed8;">${totalBudgetNplus1.toLocaleString('km-KH')} ៛</td>
              <td style="border: 1px solid #475569; text-align: right;">${totalBudgetNplus2.toLocaleString('km-KH')} ៛</td>
              <td style="border: 1px solid #475569; text-align: right;">${totalBudgetNplus3.toLocaleString('km-KH')} ៛</td>
            </tr>
          </tbody>
        </table>

        <div style="background-color: #f8fafc; border: 1px solid #cbd5e1; padding: 10px; border-radius: 6px; font-size: 9pt; margin-top: 8px;">
          <div style="display: flex; justify-content: space-between; margin-bottom: 3px;">
            <span><strong>១. ថវិការដ្ឋទទួលបាន (PB)៖</strong> (សិស្ស ${budgetReq.studentCount} នាក់ × ${budgetReq.perStudentRateRiel.toLocaleString('km-KH')}៛)</span>
            <strong>${calculatedStateBudget.toLocaleString('km-KH')} ៛</strong>
          </div>
          <div style="display: flex; justify-content: space-between; margin-bottom: 3px;">
            <span><strong>២. តម្រូវការថវិកាសរុបជាក់ស្តែង (ឆ្នាំ N+1)៖</strong></span>
            <strong>${totalBudgetNplus1.toLocaleString('km-KH')} ៛</strong>
          </div>
          <div style="display: flex; justify-content: space-between; margin-bottom: 3px; color: #b91c1c;">
            <span><strong>៣. ផលខ្វះខាតដែលត្រូវស្វែងរកបន្ថែមពីមូលដ្ឋាន៖</strong></span>
            <strong>${fundingGapYear1.toLocaleString('km-KH')} ៛</strong>
          </div>
          <div style="display: flex; justify-content: space-between; margin-bottom: 3px; color: #047857;">
            <span><strong>៤. ស្នើសុំវិនិយោគពីឃុំ-សង្កាត់ (គម្រោង CIP)៖</strong></span>
            <strong>${budgetReq.communeCipAskTotal.toLocaleString('km-KH')} ៛</strong>
          </div>
          <div style="display: flex; justify-content: space-between; color: #d97706;">
            <span><strong>៥. ការចូលរួមរបស់សហគមន៍ មាតាបិតា និងសប្បុរសជន៖</strong></span>
            <strong>${budgetReq.communityContributionTotal.toLocaleString('km-KH')} ៛</strong>
          </div>
        </div>
      </div>
    `;

    return generateBspFullHtmlDocument(
      bspPlan.schoolName,
      bspPlan.academicYearsLabel,
      fullTableInnerHtml,
      summaryTableHtml
    );
  };

  // Print Full Official BSP Document
  const handlePrintFullBsp = () => {
    const htmlDoc = getFullBspHtmlDocument();
    printHtmlSafely(htmlDoc, () => {
      showToast('បានបើកផ្ទាំងបោះពុម្ព A4 Landscape រួចរាល់!');
    });
  };

  // Export to Word (.doc) with Server-Backed Fallback (prevents "Failed to download file")
  const handleExportWordBsp = async () => {
    try {
      const htmlDoc = getFullBspHtmlDocument();
      const safeSchool = sanitizeFileName(bspPlan.schoolName || 'សាលារៀន');
      const safeYears = sanitizeFileName(bspPlan.academicYearsLabel || '២០២៤-២០២៧');
      const fileName = `BSP_${safeYears}_${safeSchool}.doc`;

      const success = await downloadFileUniversal({
        fileName,
        content: htmlDoc,
        contentType: 'application/msword; charset=utf-8',
      });

      if (success) {
        showToast('បានទាញយកឯកសារ Word ផ្លូវការរួចរាល់!');
      } else {
        showToast('មិនអាចទាញយកដោយផ្ទាល់។ សូមប្រើប៊ូតុង «ចម្លងសម្រាប់ Word» ឬ «បោះពុម្ព»');
      }
    } catch (e) {
      console.error(e);
      showToast('មានបញ្ហាក្នុងការបង្កើតឯកសារ Word');
    }
  };

  // Export to HTML (.html)
  const handleExportHtmlBsp = async () => {
    try {
      const htmlDoc = getFullBspHtmlDocument();
      const safeSchool = sanitizeFileName(bspPlan.schoolName || 'សាលារៀន');
      const safeYears = sanitizeFileName(bspPlan.academicYearsLabel || '២០២៤-២០២៧');
      const fileName = `BSP_${safeYears}_${safeSchool}.html`;

      await downloadFileUniversal({
        fileName,
        content: htmlDoc,
        contentType: 'text/html; charset=utf-8',
      });

      showToast('បានទាញយកឯកសារ HTML ផ្លូវការរួចរាល់!');
    } catch (e) {
      console.error(e);
      showToast('មានបញ្ហាក្នុងការទាញយក HTML');
    }
  };

  // Copy Complete Document Rich HTML to Clipboard (for Word / Google Docs)
  const handleCopyRichBsp = async () => {
    try {
      const htmlDoc = getFullBspHtmlDocument();
      const plainText = `ផែនការយុទ្ធសាស្ត្រថវិកា ៣ ឆ្នាំ (BSP) - ${bspPlan.schoolName} (${bspPlan.academicYearsLabel})`;
      const success = await copyRichHtmlToClipboard(htmlDoc, plainText);
      if (success) {
        showToast('បានចម្លងតារាងទាំងអស់រួចរាល់! លោកគ្រូអាចបើក Word ឬ Google Docs រួចចុច Ctrl+V ដើម្បីបិទភ្ជាប់');
      } else {
        showToast('មិនអាចចម្លងទៅ Clipboard បានទេ។ សូមប្រើប៊ូតុងបោះពុម្ព ឬ Word');
      }
    } catch (e) {
      console.error(e);
      showToast('បរាជ័យក្នុងការចម្លង');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-6 space-y-6 font-kantumruy">
      
      {/* Top Banner / Master Framework Intro & KPI Cards (Collapsible) */}
      {showTopOverview ? (
        <div className="space-y-6 animate-in fade-in duration-200">
          <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 rounded-3xl text-white p-6 shadow-xl border border-blue-700/40 relative overflow-hidden">
            <div className="absolute right-0 top-0 bottom-0 w-96 bg-[radial-gradient(circle_at_top_right,rgba(59,130,246,0.3),transparent_70%)] pointer-events-none" />
            
            <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
              <div className="space-y-2 max-w-3xl">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 rounded-full bg-blue-500/30 text-blue-200 border border-blue-400/30 text-xs font-bold tracking-wide">
                    ផែនការយុទ្ធសាស្ត្រថវិកា ៣ ឆ្នាំ (BSP)
                  </span>
                  <span className="text-xs text-indigo-200">
                    ឆ្នាំ {bspPlan.academicYearsLabel} • ៥ ស្តង់ដាសាលារៀន
                  </span>
                </div>
                <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
                  ផែនការយុទ្ធសាស្ត្រថវិកា ៣ ឆ្នាំរំកិល - ផែនការមេសម្រាប់វិនិយោគជាមួយឃុំ & សហគមន៍
                </h2>
                <p className="text-xs sm:text-sm text-indigo-100/90 leading-relaxed">
                  រដ្ឋបាលឃុំ-ស្រុក និងសហគមន៍ត្រូវការមើលឃើញច្បាស់ថាតើសាលារៀបចំធ្វើអ្វីខ្លះ និងត្រូវការថវិកាប៉ុន្មាន។ ថវិការដ្ឋបានពីសិស្ស (~១៦,០០០៛/នាក់) មិនគ្រប់គ្រាន់ទេ ទើបត្រូវមានផែនការ ៣ ឆ្នាំនេះ ដើម្បីសុំការចូលរួមវិនិយោគក្នុងវិស័យអប់រំពីឃុំ (CIP) និងសហគមន៍។
                </p>
              </div>

              {/* Action Toolbar */}
              <div className="flex flex-wrap lg:flex-col gap-2.5 shrink-0">
                {/* Paperless Walkthrough Presentation Button */}
                <button
                  onClick={onStartMeetingWalkthrough}
                  className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/25 transition-all hover:scale-[1.02] active:scale-[0.98]"
                >
                  <Presentation className="w-4 h-4 text-slate-950" />
                  <span>របៀបបង្ហាញសហគមន៍/ឃុំ (មិនប្រើក្រដាស)</span>
                </button>

                {/* Hide Top Overview Button (Focus Mode) */}
                <button
                  onClick={() => {
                    setShowTopOverview(false);
                    showToast('បានលាក់ផ្នែកខាងលើ! តារាងបានរំកិលឡើងទៅលើបង្អស់នៃអេក្រង់');
                  }}
                  className="flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs border border-white/20 transition-all hover:bg-white/25 active:scale-[0.98]"
                  title="លាក់ផ្នែកខាងលើ (បដា និងកាតសង្ខេប) ដើម្បីឱ្យតារាងឡើងមកលើបង្អស់"
                >
                  <EyeOff className="w-4 h-4 text-amber-300" />
                  <span>លាក់ផ្នែកខាងលើ (Focus Table)</span>
                </button>

                {/* Sync Year 1 to AOP */}
                <button
                  onClick={() => {
                    onSyncYear1ToAop();
                    showToast('បានបញ្ជូនទិន្នន័យឆ្នាំទី១ ទៅជាផែនការប្រតិបត្តិ (AOP) រួចរាល់!');
                  }}
                  className="flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md shadow-blue-500/30 transition-all hover:scale-[1.02] active:scale-[0.98]"
                >
                  <ArrowRight className="w-4 h-4 text-blue-200" />
                  <span>បញ្ជូនឆ្នាំទី១ ទៅ AOP</span>
                </button>

                {/* Print Official Government Table */}
                <button
                  onClick={handlePrintFullBsp}
                  className="flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs border border-white/20 transition-colors"
                >
                  <Printer className="w-4 h-4 text-indigo-300" />
                  <span>បោះពុម្ពទម្រង់រដ្ឋបាលពេញលេញ</span>
                </button>
              </div>
            </div>
          </div>

          {/* KPI Financial Overview Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Total Budget Year N+1 */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500">តម្រូវការថវិកាឆ្នាំ N+1</span>
                <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
                  <TrendingUp className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-2">
                <div className="text-lg font-bold text-slate-900">{formatRiel(totalBudgetNplus1)}</div>
                <div className="text-[11px] text-blue-600 mt-0.5">
                  សរុប ៥ ស្តង់ដាសាលារៀន
                </div>
              </div>
            </div>

            {/* State PB Budget (~16,400 Riel per student) */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500">ថវិការដ្ឋទទួលបាន (PB)</span>
                <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
                  <Coins className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-2">
                <div className="text-lg font-bold text-emerald-800">{formatRiel(calculatedStateBudget)}</div>
                <div className="text-[11px] text-slate-500 mt-0.5">
                  សិស្ស {budgetReq.studentCount} នាក់ × {budgetReq.perStudentRateRiel.toLocaleString('km-KH')}៛
                </div>
              </div>
            </div>

            {/* Funding Gap to Seek from Commune & Community */}
            <div className="bg-white p-4 rounded-2xl border border-rose-200 bg-rose-50/20 shadow-xs hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-rose-800">ផលខ្វះខាតត្រូវកៀរគរ (Gap)</span>
                <div className="w-8 h-8 rounded-lg bg-rose-600 text-white flex items-center justify-center shadow-xs">
                  <AlertCircle className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-2">
                <div className="text-lg font-bold text-rose-900">{formatRiel(fundingGapYear1)}</div>
                <div className="text-[11px] text-rose-700 mt-0.5">
                  ត្រូវសុំការវិនិយោគពីឃុំ & សហគមន៍
                </div>
              </div>
            </div>

            {/* Commune CIP Ask Package */}
            <div className="bg-white p-4 rounded-2xl border border-emerald-200 bg-emerald-50/20 shadow-xs hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-emerald-800">ស្នើវិនិយោគឃុំ (CIP)</span>
                <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center shadow-xs">
                  <Building2 className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-2">
                <div className="text-lg font-bold text-emerald-900">{formatRiel(budgetReq.communeCipAskTotal)}</div>
                <div className="text-[11px] text-emerald-700 mt-0.5 flex justify-between">
                  <span>សហគមន៍៖ {formatRiel(budgetReq.communityContributionTotal)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Compact Slim Bar when Top Overview is Hidden */
        <div className="bg-white border border-slate-200 rounded-2xl p-3 px-4 shadow-xs flex flex-wrap items-center justify-between gap-3 animate-in fade-in duration-200">
          <div className="flex items-center gap-2.5">
            <span className="px-2.5 py-1 rounded-full bg-blue-100 text-blue-800 text-xs font-bold">
              ផែនការ ៣ ឆ្នាំ (BSP)
            </span>
            <span className="text-xs text-slate-700 font-semibold">
              {bspPlan.schoolName} ({bspPlan.academicYearsLabel})
            </span>
            <span className="text-xs text-slate-400 hidden sm:inline">
              • ថវិកា N+1៖ <strong className="text-blue-700">{formatRiel(totalBudgetNplus1)}</strong>
            </span>
            <span className="text-xs text-emerald-700 font-semibold hidden md:inline">
              • ស្នើឃុំ (CIP)៖ {formatRiel(budgetReq.communeCipAskTotal)}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setShowTopOverview(true);
                showToast('បានបង្ហាញផ្នែកខាងលើឡើងវិញ');
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 text-xs font-bold transition-all hover:scale-[1.02]"
              title="បង្ហាញបដា និងកាតហិរញ្ញវត្ថុ ៤ ខាងលើឡើងវិញ"
            >
              <Eye className="w-3.5 h-3.5 text-blue-600" />
              <span>បង្ហាញផ្នែកខាងលើ (បដា & កាតសង្ខេប)</span>
            </button>
            <button
              onClick={onStartMeetingWalkthrough}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold shadow-xs transition-all"
            >
              <Presentation className="w-3.5 h-3.5" />
              <span>របៀបបង្ហាញសហគមន៍</span>
            </button>
          </div>
        </div>
      )}

      {/* Main View Mode Tabs */}
      <div className="flex flex-wrap border-b border-slate-200 bg-white rounded-t-2xl px-4 pt-2 shadow-2xs gap-3">
        {/* Tab 1: Slide Presentation of 5 Standards */}
        <button
          onClick={() => setActiveTab('slides')}
          className={`pb-3 px-3 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 ${
            activeTab === 'slides'
              ? 'border-blue-600 text-blue-700'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <Presentation className="w-4 h-4 text-blue-600" />
          <span>បង្ហាញម្តងមួយស្តង់ដា (Slide View)</span>
        </button>

        {/* Tab 2: Full Official MoEYS Table */}
        <button
          onClick={() => setActiveTab('full_table')}
          className={`pb-3 px-3 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 ${
            activeTab === 'full_table'
              ? 'border-blue-600 text-blue-700'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <FileText className="w-4 h-4 text-slate-600" />
          <span>តារាងរដ្ឋបាលពេញលេញ (Full Table)</span>
          <span className="text-[11px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
            {tableStandards.reduce((a, s) => a + s.rows.length, 0)} ជួរ (២៦ គន្លឹះ • ៧០ រង)
          </span>
        </button>

        {/* Tab 3: Budget Requirements & Projections Summary (At Bottom) */}
        <button
          onClick={() => setActiveTab('budget_summary')}
          className={`pb-3 px-3 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 ${
            activeTab === 'budget_summary'
              ? 'border-blue-600 text-blue-700'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <Calculator className="w-4 h-4 text-emerald-600" />
          <span>តម្រូវការថវិកា & គម្លាតវិនិយោគ (Budget Gap)</span>
        </button>

        {/* Tab 4: Commune CIP Asks */}
        <button
          onClick={() => setActiveTab('commune_asks')}
          className={`pb-3 px-3 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 ${
            activeTab === 'commune_asks'
              ? 'border-blue-600 text-blue-700'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <Building2 className="w-4 h-4 text-emerald-600" />
          <span>គម្រោងស្នើឃុំ (CIP Asks)</span>
          <span className="text-[11px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
            {bspPlan.communeAsks.length}
          </span>
        </button>
      </div>

      {/* =========================================================================
          TAB 1: SLIDE VIEW (បង្ហាញម្តងមួយស្តង់ដា ដូចស្លាយ មិនឱ្យរារែក)
         ========================================================================= */}
      {activeTab === 'slides' && (() => {
        const slideStd = tableStandards[activeStandardIndex] || tableStandards[0];
        const slideStdTotal = getStandardTotalNplus1(slideStd);
        const visibleSlideRows = slideStd.rows.filter((r) => {
          if (r.rowType === 'gender_breakdown' && !showGenderRows) return false;
          if (r.rowType === 'key_indicator' && !showKeyIndicators) return false;
          if (r.rowType === 'sub_indicator' && !showSubIndicators) return false;
          return true;
        });

        return (
          <div className="space-y-5 animate-in fade-in duration-200">
            
            {/* Standard Selector Bar (Slide buttons) */}
            <div className="bg-white p-3 rounded-2xl border border-slate-200 flex flex-wrap items-center justify-between gap-3 shadow-2xs">
              <div className="flex flex-wrap items-center gap-2">
                {tableStandards.map((std, idx) => (
                  <button
                    key={std.standardNumber}
                    onClick={() => setActiveStandardIndex(idx)}
                    className={`px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                      activeStandardIndex === idx
                        ? 'bg-blue-600 text-white shadow-md shadow-blue-500/25 scale-102'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                  >
                    <span className="w-5 h-5 rounded-full bg-black/10 flex items-center justify-center text-[10px]">
                      {idx + 1}
                    </span>
                    <span>{std.code}</span>
                  </button>
                ))}
              </div>

              {/* Prev / Next Slide Controls */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveStandardIndex(Math.max(0, activeStandardIndex - 1))}
                  disabled={activeStandardIndex === 0}
                  className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                  title="ស្តង់ដាមុន"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <span className="text-xs font-semibold text-slate-600 px-1">
                  ស្តង់ដាទី {activeStandardIndex + 1} / {tableStandards.length}
                </span>
                <button
                  onClick={() => setActiveStandardIndex(Math.min(tableStandards.length - 1, activeStandardIndex + 1))}
                  disabled={activeStandardIndex === tableStandards.length - 1}
                  className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                  title="ស្តង់ដាបន្ទាប់"
                >
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Current Standard Card & Table */}
            <div className="bg-white rounded-3xl border border-slate-200 shadow-md overflow-hidden">
              <div className="p-5 bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <span className="w-9 h-9 rounded-xl bg-blue-500 text-white font-bold flex items-center justify-center text-sm shadow-xs shrink-0">
                    {slideStd.standardNumber}
                  </span>
                  <div>
                    <h3 className="text-base sm:text-lg font-bold text-white">
                      {slideStd.title}
                    </h3>
                    <p className="text-xs text-indigo-200 mt-0.5">
                      {slideStd.keyIndicatorCount} សូចនាករគន្លឹះ • {slideStd.subIndicatorCount} សូចនាកររង ({visibleSlideRows.length} ជួរបានបង្ហាញ)
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="text-[11px] block font-medium text-indigo-200">ថវិកា N+1</span>
                    <span className="text-sm font-bold text-white">{formatRiel(slideStdTotal)}</span>
                  </div>
                </div>
              </div>

              {/* Table for this Standard */}
              <div className="overflow-x-auto p-4">
                <table className="w-full text-xs border-collapse bsp-official-table">
                  <thead dangerouslySetInnerHTML={{ __html: OFFICIAL_BSP_HEADER_HTML }} />
                  <tbody className="bg-indigo-50/90 font-bold text-indigo-950 border-b border-indigo-200">
                    <tr>
                      <td colSpan={2} className="py-2 px-3 font-bold text-left">
                        {slideStd.code}៖ សរុបថវិកា និងគោលដៅ
                      </td>
                      <td className="py-2 px-3 text-right font-bold text-indigo-900 bg-indigo-100/50">
                        {formatRiel(slideStdTotal)}
                      </td>
                      <td className="py-2 px-2 text-center text-slate-400">-</td>
                      <td className="py-2 px-2 text-center text-slate-400">-</td>
                      <td className="py-2 px-3 text-right font-bold text-indigo-900 bg-indigo-100/50">
                        {formatRiel(slideStdTotal)}
                      </td>
                      <td className="py-2 px-2 text-center text-slate-400">-</td>
                      <td className="py-2 px-2 text-center text-slate-400">-</td>
                      <td className="py-2 px-2 text-center text-slate-400">-</td>
                    </tr>
                  </tbody>
                  <tbody className="divide-y divide-slate-200">
                    {visibleSlideRows.map((row) => {
                      const isKey = row.rowType === 'key_indicator';
                      const isGender = row.rowType === 'gender_breakdown';
                      const trClass = isKey
                        ? 'bg-slate-50 font-bold text-slate-900 border-t border-slate-300'
                        : isGender
                        ? 'bg-slate-50/40 text-slate-600 italic'
                        : 'bg-white hover:bg-blue-50/30 text-slate-800 transition-colors';

                      return (
                        <tr key={row.id} className={trClass}>
                          <td className={`py-2 px-2 text-center align-top ${isKey ? 'font-bold text-slate-900' : ''}`}>
                            {row.code}
                          </td>
                          <td className={`py-2 px-3 align-top ${isKey ? 'font-bold text-slate-900' : isGender ? 'pl-6 text-slate-500' : 'text-slate-800'}`}>
                            {isEditMode && !isGender ? (
                              <input
                                type="text"
                                value={row.title}
                                onChange={(e) => handleUpdateTableCell(slideStd.standardNumber, row.id, 'title', e.target.value)}
                                className="w-full px-2 py-1 text-xs border border-amber-300 rounded bg-amber-50/50 font-medium focus:bg-white focus:outline-blue-500"
                              />
                            ) : (
                              <span>{row.title}</span>
                            )}
                          </td>
                          <td className="py-2 px-2 text-right align-top">
                            {isEditMode && !isGender ? (
                              <input
                                type="number"
                                value={row.budgetNplus1}
                                onChange={(e) => {
                                  const val = Number(e.target.value) || 0;
                                  handleUpdateTableCell(slideStd.standardNumber, row.id, 'budgetNplus1', val);
                                  handleUpdateTableCell(slideStd.standardNumber, row.id, 'targetNplus1Budget', val);
                                }}
                                className="w-24 px-1.5 py-1 text-xs text-right border border-amber-400 rounded bg-amber-50 focus:bg-white font-bold"
                              />
                            ) : (
                              <span className={row.budgetNplus1 > 0 ? 'font-semibold text-slate-900' : 'text-slate-400'}>
                                {row.budgetNplus1 > 0 ? formatRiel(row.budgetNplus1) : '-'}
                              </span>
                            )}
                          </td>
                          <td className="py-2 px-2 text-center align-top">{row.targetNminus1 || '-'}</td>
                          <td className="py-2 px-2 text-center align-top">{row.targetN || '-'}</td>
                          <td className="py-2 px-2 text-right align-top">
                            {row.targetNplus1Budget > 0 ? formatRiel(row.targetNplus1Budget) : '-'}
                          </td>
                          <td className="py-2 px-3 align-top whitespace-pre-line text-[11px] text-slate-700">
                            {row.reasonOrActivities || '-'}
                          </td>
                          <td className="py-2 px-2 text-center align-top">{row.targetNplus2 || '-'}</td>
                          <td className="py-2 px-2 text-center align-top">{row.targetNplus3 || '-'}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Bottom Budget Requirements Summary Section */}
            <div className="mt-8">
              <BudgetRequirementsTable
                budgetReq={budgetReq}
                formatRiel={formatRiel}
                onUpdateAmount={handleUpdateStandardAmount}
                onUpdatePlan={handleUpdateBudgetReq}
              />
            </div>

          </div>
        );
      })()}

      {/* =========================================================================
          TAB 2: FULL OFFICIAL MOEYS TABLE (តារាងពេញផ្លូវការ ១២៩ ជួរ)
         ========================================================================= */}
      {activeTab === 'full_table' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-md space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
            <div>
              <h3 className="text-lg font-bold text-slate-900">
                តារាងផែនការយុទ្ធសាស្ត្រថវិកា ៣ ឆ្នាំ (ទម្រង់រដ្ឋបាលផ្លូវការពេញលេញ)
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                ឯកសារសម្រាប់ដាក់ជូនរដ្ឋបាលឃុំ/ស្រុក ស្របតាមទម្រង់ក្រសួងអប់រំ យុវជន និងកីឡា
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={handlePrintFullBsp}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-500/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
                title="បោះពុម្ពជាក្រដាស A4 ឬរក្សាទុកជា PDF"
              >
                <Printer className="w-4 h-4" />
                <span>បោះពុម្ព (Print/PDF)</span>
              </button>
              <button
                onClick={handleExportWordBsp}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-500/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
                title="ទាញយកឯកសារ Word (.doc)"
              >
                <Download className="w-4 h-4 text-indigo-100" />
                <span>Word (.doc)</span>
              </button>
              <button
                onClick={handleExportHtmlBsp}
                className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 rounded-xl text-xs font-semibold transition-all"
                title="ទាញយកឯកសារ HTML"
              >
                <FileCode className="w-4 h-4 text-slate-600" />
                <span>HTML (.html)</span>
              </button>
              <button
                onClick={handleCopyRichBsp}
                className="flex items-center gap-1.5 px-3 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-xl text-xs font-bold transition-all hover:scale-[1.02] active:scale-[0.98]"
                title="ចម្លងតារាងទាំងអស់រួចយកទៅ Paste ក្នុង Word ឬ Google Docs ដោយរក្សាទុកម៉ូតនិងពុម្ពអក្សរខ្មែរ ១០០%"
              >
                <Copy className="w-4 h-4 text-emerald-600" />
                <span>ចម្លងសម្រាប់ Word</span>
              </button>
            </div>
          </div>

          {/* Row Visibility Filters & Edit Controls Toolbar */}
          <div className="bg-white border border-slate-200 rounded-2xl p-3.5 sm:p-4 shadow-xs space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
                  <Presentation className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs sm:text-sm font-bold text-slate-900">
                      របៀបបង្រៀន & បង្ហាញម្តងមួយស្តង់ដា (Accordion Stepper)
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold">
                      ទប់ភ្នែក • មិនរារែក
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500">
                    ចុចលើជួរស្ដង់ដារណាមួយដើម្បីទម្លាក់ទិន្នន័យមើល។ ពេលចុចស្តង់ដាបន្ទាប់ វានឹងរំកិលឡើងលើ និងលាក់ស្តង់ដាចាស់ដោយស្វ័យប្រវត្តិ។
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {/* Quick jump to Standard 1-5 */}
                <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-200">
                  <span className="text-[11px] text-slate-400 font-medium px-1.5 hidden sm:inline">ស្តង់ដា៖</span>
                  {[1, 2, 3, 4, 5].map((num) => {
                    const isOpen = !collapsedStandards[num];
                    return (
                      <button
                        key={num}
                        type="button"
                        onClick={() => handleSelectStandardAccordion(num)}
                        className={`w-7 h-7 rounded-lg text-xs font-bold transition-all ${
                          isOpen
                            ? 'bg-blue-600 text-white shadow-xs scale-105'
                            : 'text-slate-600 hover:bg-slate-100'
                        }`}
                        title={`ចុចដើម្បីបង្ហាញតែស្តង់ដាទី ${num}`}
                      >
                        {num}
                      </button>
                    );
                  })}
                </div>

                {/* Collapse All */}
                <button
                  type="button"
                  onClick={collapseAllStandards}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-xl text-xs font-semibold shadow-2xs transition-colors"
                  title="លាក់ខ្លឹមសារស្តង់ដាទាំងអស់ (សល់តែចំណងជើងជួរ)"
                >
                  <EyeOff className="w-3.5 h-3.5 text-slate-500" />
                  <span>លាក់ទាំងអស់</span>
                </button>

                {/* Expand All */}
                <button
                  type="button"
                  onClick={expandAllStandards}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-100 text-blue-700 border border-blue-200 rounded-xl text-xs font-semibold shadow-2xs transition-colors"
                  title="ពន្លាតស្តង់ដាទាំង ៥ ឡើងវិញទាំងអស់"
                >
                  <Eye className="w-3.5 h-3.5 text-blue-600" />
                  <span>ពន្លាតទាំងអស់</span>
                </button>
              </div>
            </div>

            {/* Row Display Filters & In-Place Editing Toolbar */}
            <div className="flex flex-wrap items-center justify-between gap-2.5 pt-2.5 border-t border-slate-100">
              {/* Row Filter Toggle Pills */}
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-bold text-slate-700 mr-1 hidden md:inline">
                  តម្រងជួរដេក៖
                </span>

                {/* 1. Toggle Gender breakdown rows */}
                <button
                  type="button"
                  onClick={() => {
                    setShowGenderRows(!showGenderRows);
                    showToast(!showGenderRows ? 'បានបង្ហាញជួរដេក (ស្រី - ប្រុស)' : 'បានលាក់ជួរដេក (ស្រី - ប្រុស)');
                  }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                    showGenderRows
                      ? 'bg-blue-50 text-blue-800 border-blue-300 shadow-2xs'
                      : 'bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-100'
                  }`}
                  title="លាក់ ឬបង្ហាញ ជួរដេកបែងចែកភេទ (ស្រី - ប្រុស)"
                >
                  {showGenderRows ? <Eye className="w-3.5 h-3.5 text-blue-600" /> : <EyeOff className="w-3.5 h-3.5 text-slate-400" />}
                  <span>ជួរដេក (ស្រី - ប្រុស)</span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                    showGenderRows ? 'bg-blue-200 text-blue-900' : 'bg-slate-200 text-slate-600'
                  }`}>
                    {showGenderRows ? 'បង្ហាញ' : 'លាក់'}
                  </span>
                </button>

                {/* 2. Toggle Key indicators 26 rows */}
                <button
                  type="button"
                  onClick={() => {
                    setShowKeyIndicators(!showKeyIndicators);
                    showToast(!showKeyIndicators ? 'បានបង្ហាញជួរដេកសូចនាករគន្លឹះ (២៦)' : 'បានលាក់ជួរដេកសូចនាករគន្លឹះ (២៦)');
                  }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                    showKeyIndicators
                      ? 'bg-indigo-50 text-indigo-800 border-indigo-300 shadow-2xs'
                      : 'bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-100'
                  }`}
                  title="លាក់ ឬបង្ហាញ ជួរដេកសូចនាករគន្លឹះទាំង ២៦"
                >
                  {showKeyIndicators ? <Eye className="w-3.5 h-3.5 text-indigo-600" /> : <EyeOff className="w-3.5 h-3.5 text-slate-400" />}
                  <span>សូចនាករគន្លឹះ (២៦)</span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                    showKeyIndicators ? 'bg-indigo-200 text-indigo-900' : 'bg-slate-200 text-slate-600'
                  }`}>
                    {showKeyIndicators ? 'បង្ហាញ' : 'លាក់'}
                  </span>
                </button>

                {/* 3. Toggle Sub-indicators 70 rows */}
                <button
                  type="button"
                  onClick={() => {
                    setShowSubIndicators(!showSubIndicators);
                    showToast(!showSubIndicators ? 'បានបង្ហាញជួរដេកសូចនាកររង (៧០)' : 'បានលាក់ជួរដេកសូចនាកររង (៧០)');
                  }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                    showSubIndicators
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-300 shadow-2xs'
                      : 'bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-100'
                  }`}
                  title="លាក់ ឬបង្ហាញ ជួរដេកសូចនាកររងទាំង ៧០"
                >
                  {showSubIndicators ? <Eye className="w-3.5 h-3.5 text-emerald-600" /> : <EyeOff className="w-3.5 h-3.5 text-slate-400" />}
                  <span>សូចនាកររង (៧០)</span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                    showSubIndicators ? 'bg-emerald-200 text-emerald-900' : 'bg-slate-200 text-slate-600'
                  }`}>
                    {showSubIndicators ? 'បង្ហាញ' : 'លាក់'}
                  </span>
                </button>
              </div>

              {/* Edit Mode & Reset Action Buttons */}
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsEditMode(!isEditMode);
                    showToast(!isEditMode ? 'បានបើករបៀបកែសម្រួលទិន្នន័យតារាង (Edit Mode)' : 'បានរក្សាទុក និងបិទរបៀបកែសម្រួល');
                  }}
                  className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all border shadow-xs ${
                    isEditMode
                      ? 'bg-amber-500 hover:bg-amber-600 text-slate-950 border-amber-600 scale-[1.02]'
                      : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-300'
                  }`}
                  title="ចុចដើម្បីកែប្រែថវិកា ភាគរយ និងទិន្នន័យជាក់ស្តែងពេលចុះវិនិយោគជាមួយឃុំ/សហគមន៍"
                >
                  {isEditMode ? <Check className="w-3.5 h-3.5 font-bold" /> : <Edit3 className="w-3.5 h-3.5 text-amber-600" />}
                  <span>{isEditMode ? 'បញ្ចប់ការកែ (Done Editing)' : 'កែសម្រួលទិន្នន័យតារាង (Edit Mode)'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleResetTableData}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-medium text-slate-500 hover:text-slate-800 hover:bg-slate-100 border border-transparent transition-colors"
                  title="កំណត់ទិន្នន័យឡើងវិញទៅតាមគំរូដើម"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
                  <span>កំណត់ឡើងវិញ</span>
                </button>
              </div>
            </div>
          </div>

          {/* Full Official Table with Interactive React Rows & Accordion Standard Headers */}
          <div className="overflow-x-auto rounded-2xl border border-slate-200 shadow-xs bg-white">
            <table className="w-full text-xs border-collapse bsp-official-table">
              {/* Official 3-Row Header */}
              <thead dangerouslySetInnerHTML={{ __html: OFFICIAL_BSP_HEADER_HTML }} />

              {/* Grand Total Row (Dynamically calculated based on current numbers) */}
              <tbody className="bg-blue-50/90 font-bold text-blue-950 border-b-2 border-blue-200">
                <tr>
                  <td colSpan={2} className="py-2.5 px-3 font-bold text-left">
                    <div className="flex items-center justify-between">
                      <span>សរុបរួម (Grand Total) - ៥ ស្តង់ដាសាលារៀន</span>
                      <span className="text-[11px] font-normal text-blue-700">
                        (២៦ សូចនាករគន្លឹះ និង ៧០ សូចនាកររង)
                      </span>
                    </div>
                  </td>
                  <td className="py-2.5 px-3 text-right font-bold text-blue-900 bg-blue-100/60">
                    {formatRiel(calculatedGrandTotalNplus1)}
                  </td>
                  <td className="py-2.5 px-2 text-center text-slate-400">-</td>
                  <td className="py-2.5 px-2 text-center text-slate-400">-</td>
                  <td className="py-2.5 px-3 text-right font-bold text-blue-900 bg-blue-100/60">
                    {formatRiel(calculatedGrandTotalNplus1)}
                  </td>
                  <td className="py-2.5 px-2 text-center text-slate-400">-</td>
                  <td className="py-2.5 px-2 text-center text-slate-400">-</td>
                  <td className="py-2.5 px-2 text-center text-slate-400">-</td>
                </tr>
              </tbody>

              {/* 5 Standards Rendered as Structured Interactive Rows */}
              {tableStandards.map((s) => {
                const isCollapsed = !!collapsedStandards[s.standardNumber];
                const stdTotal = getStandardTotalNplus1(s);

                // Filter rows according to user's toggles
                const visibleRows = s.rows.filter((r) => {
                  if (r.rowType === 'gender_breakdown' && !showGenderRows) return false;
                  if (r.rowType === 'key_indicator' && !showKeyIndicators) return false;
                  if (r.rowType === 'sub_indicator' && !showSubIndicators) return false;
                  return true;
                });

                return (
                  <React.Fragment key={s.standardNumber}>
                    {/* Master Interactive Clickable Standard Header Row */}
                    <tbody id={`standard-row-anchor-${s.standardNumber}`}>
                      <tr
                        onClick={() => handleSelectStandardAccordion(s.standardNumber)}
                        className={`cursor-pointer select-none transition-all border-t-2 border-b ${
                          !isCollapsed
                            ? 'bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white border-blue-500 shadow-md'
                            : 'bg-slate-100 hover:bg-blue-50 text-slate-800 border-slate-300'
                        }`}
                        title={!isCollapsed ? 'ចុចទីនេះដើម្បីបង្រួមលាក់' : 'ចុចទីនេះដើម្បីទម្លាក់ទិន្នន័យស្តង់ដានេះមកមើល'}
                      >
                        <td colSpan={9} className="py-3 px-4">
                          <div className="flex items-center justify-between gap-3">
                            <div className="flex items-center gap-3">
                              {/* Standard Number Badge */}
                              <span className={`w-8 h-8 rounded-xl font-bold flex items-center justify-center text-sm shadow-xs shrink-0 ${
                                !isCollapsed
                                  ? 'bg-blue-500 text-white'
                                  : 'bg-slate-200 text-slate-700'
                              }`}>
                                {s.standardNumber}
                              </span>

                              <div>
                                <div className="flex flex-wrap items-center gap-2">
                                  <span className={`font-bold text-sm sm:text-base ${!isCollapsed ? 'text-white' : 'text-slate-900'}`}>
                                    {s.title}
                                  </span>
                                  <span className={`text-[11px] px-2.5 py-0.5 rounded-full font-semibold ${
                                    !isCollapsed
                                      ? 'bg-blue-800/80 text-blue-200 border border-blue-400/30'
                                      : 'bg-slate-200 text-slate-600'
                                  }`}>
                                    {s.keyIndicatorCount} គន្លឹះ • {s.subIndicatorCount} រង ({visibleRows.length} ជួរ)
                                  </span>
                                </div>
                                <p className={`text-xs mt-0.5 ${!isCollapsed ? 'text-indigo-200' : 'text-slate-500'}`}>
                                  {!isCollapsed
                                    ? 'កំពុងបង្ហាញទិន្នន័យលម្អិត • ចុចដើម្បីបង្រួមលាក់'
                                    : 'ចុចទីនេះដើម្បីទម្លាក់ទិន្នន័យស្តង់ដានេះមកមើល (ចុចស្តង់ដាបន្ទាប់ដើម្បីទាញឡើង)'
                                  }
                                </p>
                              </div>
                            </div>

                            {/* Right side: Budget + Circle Chevron (identical to user screenshot) */}
                            <div className="flex items-center gap-3 shrink-0">
                              <div className="text-right hidden sm:block">
                                <span className={`text-[11px] block font-medium ${!isCollapsed ? 'text-indigo-200' : 'text-slate-500'}`}>
                                  ថវិកា N+1
                                </span>
                                <span className={`text-xs font-bold ${!isCollapsed ? 'text-white' : 'text-blue-700'}`}>
                                  {formatRiel(stdTotal)}
                                </span>
                              </div>

                              {/* Circle Chevron Button matching the circled icon in user screenshot */}
                              <div className={`w-9 h-9 rounded-full flex items-center justify-center transition-transform duration-200 shadow-xs border ${
                                !isCollapsed
                                  ? 'bg-white/20 text-white border-white/30 hover:bg-white/30 scale-105'
                                  : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                              }`}>
                                {!isCollapsed ? (
                                  <ChevronUp className="w-5 h-5 text-amber-300" />
                                ) : (
                                  <ChevronDown className="w-5 h-5 text-slate-600" />
                                )}
                              </div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    </tbody>

                    {/* Standard Content: Rendered when expanded */}
                    {!isCollapsed && (
                      <>
                        {/* Standard Subtotal Summary Row */}
                        <tbody className="bg-indigo-50/90 font-bold text-indigo-950 border-b border-indigo-200">
                          <tr>
                            <td colSpan={2} className="py-2 px-3 font-bold text-left">
                              {s.code}៖ សរុបថវិកា និងគោលដៅ
                            </td>
                            <td className="py-2 px-3 text-right font-bold text-indigo-900 bg-indigo-100/50">
                              {formatRiel(stdTotal)}
                            </td>
                            <td className="py-2 px-2 text-center text-slate-400">-</td>
                            <td className="py-2 px-2 text-center text-slate-400">-</td>
                            <td className="py-2 px-3 text-right font-bold text-indigo-900 bg-indigo-100/50">
                              {formatRiel(stdTotal)}
                            </td>
                            <td className="py-2 px-2 text-center text-slate-400">-</td>
                            <td className="py-2 px-2 text-center text-slate-400">-</td>
                            <td className="py-2 px-2 text-center text-slate-400">-</td>
                          </tr>
                        </tbody>

                        {/* Detail Rows of the Standard */}
                        <tbody className="divide-y divide-slate-200">
                          {visibleRows.map((row) => {
                            const isKey = row.rowType === 'key_indicator';
                            const isGender = row.rowType === 'gender_breakdown';

                            const trClass = isKey
                              ? 'bg-slate-50 font-bold text-slate-900 border-t border-slate-300'
                              : isGender
                              ? 'bg-slate-50/40 text-slate-600 italic'
                              : 'bg-white hover:bg-blue-50/30 text-slate-800 transition-colors';

                            return (
                              <tr key={row.id} className={trClass}>
                                {/* Col 1: Code */}
                                <td className={`py-2 px-2 text-center align-top ${isKey ? 'font-bold text-slate-900' : ''}`}>
                                  {row.code}
                                </td>

                                {/* Col 2: Title */}
                                <td className={`py-2 px-3 align-top ${isKey ? 'font-bold text-slate-900' : isGender ? 'pl-6 text-slate-500' : 'text-slate-800'}`}>
                                  {isEditMode && !isGender ? (
                                    <input
                                      type="text"
                                      value={row.title}
                                      onChange={(e) => handleUpdateTableCell(s.standardNumber, row.id, 'title', e.target.value)}
                                      className="w-full px-2 py-1 text-xs border border-amber-300 rounded bg-amber-50/50 font-medium focus:bg-white focus:outline-blue-500"
                                    />
                                  ) : (
                                    <span>{row.title}</span>
                                  )}
                                </td>

                                {/* Col 3: Budget N+1 (Riel) */}
                                <td className="py-2 px-2 text-right align-top">
                                  {isEditMode && !isGender ? (
                                    <input
                                      type="number"
                                      value={row.budgetNplus1}
                                      onChange={(e) => {
                                        const val = Number(e.target.value) || 0;
                                        handleUpdateTableCell(s.standardNumber, row.id, 'budgetNplus1', val);
                                        handleUpdateTableCell(s.standardNumber, row.id, 'targetNplus1Budget', val);
                                      }}
                                      className="w-24 px-1.5 py-1 text-xs text-right border border-amber-400 rounded bg-amber-50 focus:bg-white focus:outline-blue-500 font-bold text-slate-900"
                                    />
                                  ) : (
                                    <span className={row.budgetNplus1 > 0 ? 'font-semibold text-slate-900' : 'text-slate-400'}>
                                      {row.budgetNplus1 > 0 ? formatRiel(row.budgetNplus1) : '-'}
                                    </span>
                                  )}
                                </td>

                                {/* Col 4: Target N-1 */}
                                <td className="py-2 px-2 text-center align-top">
                                  {isEditMode ? (
                                    <input
                                      type="text"
                                      value={row.targetNminus1}
                                      onChange={(e) => handleUpdateTableCell(s.standardNumber, row.id, 'targetNminus1', e.target.value)}
                                      className="w-14 px-1 py-1 text-xs text-center border border-amber-300 rounded bg-amber-50/50 focus:bg-white"
                                    />
                                  ) : (
                                    <span>{row.targetNminus1 || '-'}</span>
                                  )}
                                </td>

                                {/* Col 5: Target N */}
                                <td className="py-2 px-2 text-center align-top">
                                  {isEditMode ? (
                                    <input
                                      type="text"
                                      value={row.targetN}
                                      onChange={(e) => handleUpdateTableCell(s.standardNumber, row.id, 'targetN', e.target.value)}
                                      className="w-14 px-1 py-1 text-xs text-center border border-amber-300 rounded bg-amber-50/50 focus:bg-white"
                                    />
                                  ) : (
                                    <span>{row.targetN || '-'}</span>
                                  )}
                                </td>

                                {/* Col 6: Target N+1 Budget */}
                                <td className="py-2 px-2 text-right align-top">
                                  {isEditMode && !isGender ? (
                                    <input
                                      type="number"
                                      value={row.targetNplus1Budget}
                                      onChange={(e) => handleUpdateTableCell(s.standardNumber, row.id, 'targetNplus1Budget', Number(e.target.value) || 0)}
                                      className="w-24 px-1.5 py-1 text-xs text-right border border-amber-400 rounded bg-amber-50 focus:bg-white font-bold"
                                    />
                                  ) : (
                                    <span className={row.targetNplus1Budget > 0 ? 'font-semibold text-slate-900' : 'text-slate-400'}>
                                      {row.targetNplus1Budget > 0 ? formatRiel(row.targetNplus1Budget) : '-'}
                                    </span>
                                  )}
                                </td>

                                {/* Col 7: Reason / Activities */}
                                <td className="py-2 px-3 align-top whitespace-pre-line text-[11px] text-slate-700">
                                  {isEditMode && !isGender ? (
                                    <textarea
                                      rows={2}
                                      value={row.reasonOrActivities}
                                      onChange={(e) => handleUpdateTableCell(s.standardNumber, row.id, 'reasonOrActivities', e.target.value)}
                                      className="w-full px-2 py-1 text-xs border border-amber-300 rounded bg-amber-50/50 focus:bg-white"
                                    />
                                  ) : (
                                    <span>{row.reasonOrActivities || '-'}</span>
                                  )}
                                </td>

                                {/* Col 8: Target N+2 */}
                                <td className="py-2 px-2 text-center align-top">
                                  {isEditMode ? (
                                    <input
                                      type="text"
                                      value={row.targetNplus2}
                                      onChange={(e) => handleUpdateTableCell(s.standardNumber, row.id, 'targetNplus2', e.target.value)}
                                      className="w-14 px-1 py-1 text-xs text-center border border-amber-300 rounded bg-amber-50/50 focus:bg-white"
                                    />
                                  ) : (
                                    <span>{row.targetNplus2 || '-'}</span>
                                  )}
                                </td>

                                {/* Col 9: Target N+3 */}
                                <td className="py-2 px-2 text-center align-top">
                                  {isEditMode ? (
                                    <input
                                      type="text"
                                      value={row.targetNplus3}
                                      onChange={(e) => handleUpdateTableCell(s.standardNumber, row.id, 'targetNplus3', e.target.value)}
                                      className="w-14 px-1 py-1 text-xs text-center border border-amber-300 rounded bg-amber-50/50 focus:bg-white"
                                    />
                                  ) : (
                                    <span>{row.targetNplus3 || '-'}</span>
                                  )}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>

                        {/* Stepper Navigation Footer at bottom of the standard */}
                        <tbody className="bg-slate-50 border-b-2 border-slate-300">
                          <tr>
                            <td colSpan={9} className="py-2.5 px-4">
                              <div className="flex flex-wrap items-center justify-between gap-3">
                                <div className="text-xs text-slate-500 font-medium">
                                  បានពិនិត្យចប់ <strong>{s.code}</strong> ({visibleRows.length} ជួរបានបង្ហាញ)
                                </div>
                                <div className="flex items-center gap-2">
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setCollapsedStandards(prev => ({ ...prev, [s.standardNumber]: true }));
                                      showToast(`បានបង្រួម${s.code}`);
                                    }}
                                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 text-xs font-semibold shadow-2xs transition-colors"
                                  >
                                    <ChevronUp className="w-4 h-4 text-slate-500" />
                                    <span>បង្រួមលាក់ស្តង់ដានេះ</span>
                                  </button>

                                  {s.standardNumber < 5 && (
                                    <button
                                      type="button"
                                      onClick={() => handleSelectStandardAccordion(s.standardNumber + 1)}
                                      className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-500/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
                                    >
                                      <span>បន្តទៅស្តង់ដាទី {s.standardNumber + 1}</span>
                                      <ArrowRight className="w-4 h-4" />
                                    </button>
                                  )}
                                </div>
                              </div>
                            </td>
                          </tr>
                        </tbody>
                      </>
                    )}
                  </React.Fragment>
                );
              })}
            </table>
          </div>

          {/* Bottom Budget Requirements Summary */}
          <div className="pt-6 border-t border-slate-200">
            <BudgetRequirementsTable
              budgetReq={budgetReq}
              formatRiel={formatRiel}
              onUpdateAmount={handleUpdateStandardAmount}
              onUpdatePlan={handleUpdateBudgetReq}
            />
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 3: BUDGET REQUIREMENTS & GAP ANALYSIS (តម្រូវការថវិកា & គម្លាត)
         ========================================================================= */}
      {activeTab === 'budget_summary' && (
        <div className="space-y-6">
          <BudgetRequirementsTable
            budgetReq={budgetReq}
            formatRiel={formatRiel}
            onUpdateAmount={handleUpdateStandardAmount}
            onUpdatePlan={handleUpdateBudgetReq}
          />
        </div>
      )}

      {/* =========================================================================
          TAB 4: COMMUNE CIP ASKS (គម្រោងស្នើសុំវិនិយោគឃុំ)
         ========================================================================= */}
      {activeTab === 'commune_asks' && (
        <div className="space-y-4">
          <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-2xl flex items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="p-2.5 bg-emerald-600 text-white rounded-xl shadow-xs shrink-0">
                <Building2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-emerald-950 text-sm">
                  កញ្ចប់គម្រោងអាទិភាពស្នើសុំវិនិយោគឃុំ-សង្កាត់ (CIP Package)
                </h4>
                <p className="text-xs text-emerald-800 mt-1 leading-relaxed">
                  បញ្ជីគម្រោងទាំងនេះត្រូវបានសម្រិតសម្រាំងដើម្បីដាក់ចូលក្នុងកិច្ចប្រជុំ <strong>«ក្រុមប្រឹក្សាឃុំ/សង្កាត់»</strong> និង <strong>គ.ក.ន.ក</strong> ដើម្បីបញ្ចូលក្នុងផែនការវិនិយោគ ៣ ឆ្នាំរំកិលរបស់ឃុំ។
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                const newAsk: CommuneInvestmentAsk = {
                  id: `ask-${Date.now()}`,
                  title: 'គម្រោងថ្មីស្នើក្នុង CIP',
                  standardCode: 'ស្តង់ដាទី៤',
                  targetBeneficiaries: 'សិស្សានុសិស្សទូទាំងសាលា',
                  requestedYear: 'ឆ្នាំទី១ (២០២៥)',
                  estimatedCost: 5000000,
                  communeContribution: 3500000,
                  schoolCommunityContribution: 1500000,
                  urgency: 'high',
                  status: 'draft',
                  communeFeedback: '',
                };
                onChangeBspPlan({
                  ...bspPlan,
                  communeAsks: [...bspPlan.communeAsks, newAsk],
                  updatedAt: new Date().toISOString(),
                });
                showToast('បានបន្ថែមគម្រោងថ្មី');
              }}
              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-600/20 shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>បន្ថែមគម្រោងស្នើឃុំ</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {bspPlan.communeAsks.map((ask) => {
              const statusBadge = {
                draft: { label: 'ព្រាងទុក', bg: 'bg-slate-100 text-slate-700 border-slate-200' },
                proposed_to_commune: { label: 'បានស្នើទៅឃុំ', bg: 'bg-amber-100 text-amber-800 border-amber-300' },
                approved_in_cip: { label: 'បានអនុម័តក្នុង CIP', bg: 'bg-emerald-100 text-emerald-800 border-emerald-300' },
                in_progress: { label: 'កំពុងអនុវត្ត', bg: 'bg-blue-100 text-blue-800 border-blue-300' },
              }[ask.status];

              return (
                <div key={ask.id} className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 border border-blue-200 text-[11px] font-bold">
                      {ask.standardCode}
                    </span>
                    <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${statusBadge.bg}`}>
                      {statusBadge.label}
                    </span>
                  </div>

                  <h4 className="font-bold text-slate-900 text-sm leading-snug">
                    {ask.title}
                  </h4>

                  <div className="text-xs text-slate-600 space-y-1">
                    <div><strong>អ្នកទទួលផល៖</strong> {ask.targetBeneficiaries}</div>
                    <div><strong>ឆ្នាំស្នើសុំ៖</strong> {ask.requestedYear}</div>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl space-y-1.5 text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-500">តម្លៃប៉ាន់ស្មានសរុប៖</span>
                      <strong className="text-slate-900">{formatRiel(ask.estimatedCost)}</strong>
                    </div>
                    <div className="flex justify-between text-emerald-700 font-bold">
                      <span>ស្នើសុំឃុំជួយ (CIP)៖</span>
                      <span>{formatRiel(ask.communeContribution)}</span>
                    </div>
                    <div className="flex justify-between text-slate-600">
                      <span>សាលា & សហគមន៍ចូលរួម៖</span>
                      <span>{formatRiel(ask.schoolCommunityContribution)}</span>
                    </div>
                  </div>

                  {ask.communeFeedback && (
                    <div className="p-2.5 bg-amber-50 rounded-lg border border-amber-200 text-[11px] text-amber-900">
                      <strong>មតិឆ្លើយតបរបស់ឃុំ៖</strong> {ask.communeFeedback}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Floating Toast Feedback */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-2.5 rounded-xl shadow-xl flex items-center gap-2 text-xs animate-in fade-in slide-in-from-bottom-2 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

    </div>
  );
};

/**
 * Bottom Budget Requirements & Projection Summary Table
 * Exactly fulfills the user requirement:
 * "តែផែនការបីឆ្នាំនេះត្រូវមាន ខាងក្រោមវាតម្រូវការថវិកា... ដាក់ថវិកាសរុបតាមស្តង់ដារ... ហើយនិងអាទាបនោះយើងស្មានៗវា បន្ថែមវា ឬក៏ថយវាតាមយើងចង់ដាក់"
 */
interface BudgetRequirementsTableProps {
  budgetReq: BudgetRequirementPlan;
  formatRiel: (amount: number) => string;
  onUpdateAmount: (stdId: string, field: keyof StandardBudgetSummaryItem, value: number) => void;
  onUpdatePlan: (updated: Partial<BudgetRequirementPlan>) => void;
}

const BudgetRequirementsTable: React.FC<BudgetRequirementsTableProps> = ({
  budgetReq,
  formatRiel,
  onUpdateAmount,
  onUpdatePlan,
}) => {
  // PB calculation: studentCount * perStudentRateRiel
  const calculatedStateBudget = (budgetReq.studentCount || 0) * (budgetReq.perStudentRateRiel || 0);

  // Totals of all 5 standards
  const totalBudgetNminus1 = budgetReq.standardsSummary.reduce((acc, s) => acc + (s.budgetNminus1 || 0), 0);
  const totalBudgetN = budgetReq.standardsSummary.reduce((acc, s) => acc + (s.budgetN || 0), 0);
  const totalBudgetNplus1 = budgetReq.standardsSummary.reduce((acc, s) => acc + (s.budgetNplus1 || 0), 0);
  const totalBudgetNplus2 = budgetReq.standardsSummary.reduce((acc, s) => acc + (s.budgetNplus2 || 0), 0);
  const totalBudgetNplus3 = budgetReq.standardsSummary.reduce((acc, s) => acc + (s.budgetNplus3 || 0), 0);

  // Funding gap
  const fundingGapYear1 = Math.max(0, totalBudgetNplus1 - calculatedStateBudget);
  const totalFundingAsked = (budgetReq.communeCipAskTotal || 0) + (budgetReq.communityContributionTotal || 0);
  const balance = totalFundingAsked - fundingGapYear1;

  // Accordion toggle states for Budget Requirements table and Gap Analysis
  const [isTableCollapsed, setIsTableCollapsed] = useState<boolean>(false);
  const [isGapCollapsed, setIsGapCollapsed] = useState<boolean>(false);

  return (
    <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-sm space-y-6">
      
      {/* Clickable Header with Accordion Toggle */}
      <div 
        onClick={() => setIsTableCollapsed(!isTableCollapsed)}
        className="border-b border-slate-200 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 cursor-pointer select-none hover:bg-slate-50/70 p-2 rounded-2xl transition-colors"
      >
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-xs font-bold">
              ផ្នែកខាងក្រោមនៃផែនការ ៣ ឆ្នាំ
            </span>
            <span className="text-xs text-slate-500">
              ការបូកសរុបថវិកា & ការស្មានតម្រូវការ
            </span>
          </div>
          <h3 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
            <span>តារាងតម្រូវការថវិកា ៣ ឆ្នាំ តាមស្តង់ដា (Budget Requirement Summary)</span>
          </h3>
          <p className="text-xs text-slate-500">
            {isTableCollapsed 
              ? 'បានបង្រួមលាក់ • ចុចទីនេះដើម្បីទម្លាក់តារាងតម្លៃមកមើល' 
              : 'បូកសរុបថវិកាតាមស្តង់ដានីមួយៗ និងអនុញ្ញាតឱ្យលោកគ្រូ-អ្នកគ្រូស្មានថវិកា បន្ថែម ឬថយចុះតាមតម្រូវការជាក់ស្តែង'
            }
          </p>
        </div>

        <div className="flex items-center gap-3 self-end sm:self-center">
          <div className="text-right bg-blue-50 px-3.5 py-2 rounded-2xl border border-blue-200">
            <div className="text-[11px] text-blue-700 font-semibold">តម្រូវការឆ្នាំគ្រោង (N+1)</div>
            <div className="text-lg font-bold text-blue-900">{formatRiel(totalBudgetNplus1)}</div>
          </div>

          {/* Circular Accordion Toggle matching user screenshot */}
          <div className={`w-9 h-9 rounded-full flex items-center justify-center transition-all shadow-xs border ${
            !isTableCollapsed
              ? 'bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100'
              : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
          }`}>
            {!isTableCollapsed ? (
              <ChevronUp className="w-5 h-5 text-blue-700" />
            ) : (
              <ChevronDown className="w-5 h-5 text-slate-600" />
            )}
          </div>
        </div>
      </div>

      {/* Summary Table: 5 Standards across 5 Columns (Collapsible) */}
      {!isTableCollapsed && (
        <div className="overflow-x-auto animate-in fade-in duration-200">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-slate-100/90 text-slate-700 border-b border-slate-300">
              <th className="py-2.5 px-3 w-12 text-center">ល.រ</th>
              <th className="py-2.5 px-3 min-w-[220px]">ស្តង់ដាសាលារៀន</th>
              <th className="py-2.5 px-3 text-right">ឆ្នាំមុន (N-1)</th>
              <th className="py-2.5 px-3 text-right">ឆ្នាំបច្ចុប្បន្ន (N)</th>
              <th className="py-2.5 px-3 text-right bg-blue-50/70 text-blue-800 font-bold min-w-[130px]">
                ឆ្នាំគ្រោង (N+1)
              </th>
              <th className="py-2.5 px-3 text-right">ឆ្នាំគ្រោង (N+2)</th>
              <th className="py-2.5 px-3 text-right">ឆ្នាំគ្រោង (N+3)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {budgetReq.standardsSummary.map((std, idx) => (
              <tr key={std.id} className="hover:bg-slate-50/70 transition-colors">
                <td className="py-3 px-3 text-center font-bold text-slate-600">
                  {idx + 1}
                </td>
                <td className="py-3 px-3">
                  <div className="font-bold text-slate-900">{std.standardCode}</div>
                  <div className="text-[11px] text-slate-500 line-clamp-1">{std.standardTitle}</div>
                </td>
                <td className="py-3 px-3 text-right text-slate-600 font-mono">
                  {formatRiel(std.budgetNminus1)}
                </td>
                <td className="py-3 px-3 text-right text-slate-600 font-mono">
                  {formatRiel(std.budgetN)}
                </td>
                {/* Year N+1 (Feeder to AOP - Editable with inline input) */}
                <td className="py-2 px-3 text-right bg-blue-50/30">
                  <input
                    type="number"
                    value={std.budgetNplus1}
                    onChange={(e) => onUpdateAmount(std.id, 'budgetNplus1', Number(e.target.value) || 0)}
                    className="w-full text-right p-1 text-xs font-bold text-blue-900 border border-blue-200 rounded-lg bg-white focus:ring-1 focus:ring-blue-500"
                  />
                </td>
                <td className="py-2 px-3 text-right">
                  <input
                    type="number"
                    value={std.budgetNplus2}
                    onChange={(e) => onUpdateAmount(std.id, 'budgetNplus2', Number(e.target.value) || 0)}
                    className="w-full text-right p-1 text-xs text-slate-700 border border-slate-200 rounded-lg bg-white focus:ring-1 focus:ring-blue-500"
                  />
                </td>
                <td className="py-2 px-3 text-right">
                  <input
                    type="number"
                    value={std.budgetNplus3}
                    onChange={(e) => onUpdateAmount(std.id, 'budgetNplus3', Number(e.target.value) || 0)}
                    className="w-full text-right p-1 text-xs text-slate-700 border border-slate-200 rounded-lg bg-white focus:ring-1 focus:ring-blue-500"
                  />
                </td>
              </tr>
            ))}

            {/* Grand Total Row */}
            <tr className="bg-slate-100 font-bold text-slate-900 border-t-2 border-slate-300">
              <td colSpan={2} className="py-3 px-3 text-center">
                បូកសរុបថវិកា (Grand Total)
              </td>
              <td className="py-3 px-3 text-right font-mono">
                {formatRiel(totalBudgetNminus1)}
              </td>
              <td className="py-3 px-3 text-right font-mono">
                {formatRiel(totalBudgetN)}
              </td>
              <td className="py-3 px-3 text-right text-blue-700 font-mono font-bold bg-blue-100/50">
                {formatRiel(totalBudgetNplus1)}
              </td>
              <td className="py-3 px-3 text-right font-mono">
                {formatRiel(totalBudgetNplus2)}
              </td>
              <td className="py-3 px-3 text-right font-mono">
                {formatRiel(totalBudgetNplus3)}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      )}

      {/* =========================================================================
          INTERACTIVE ESTIMATION & GAP ANALYSIS SECTION
          "ហើយ និងអាទាបនោះយើងស្មានៗវា បន្ថែមវា ឬក៏ថយវាតាមយើងចង់ដាក់"
         ========================================================================= */}
      <div className="bg-gradient-to-br from-slate-50 to-indigo-50/40 border border-slate-200 rounded-2xl p-5 space-y-4">
        <div 
          onClick={() => setIsGapCollapsed(!isGapCollapsed)}
          className="flex items-center justify-between cursor-pointer select-none"
        >
          <div className="flex items-center gap-2">
            <Calculator className="w-5 h-5 text-indigo-600" />
            <h4 className="font-bold text-slate-900 text-sm">
              ការវិភាគប្រភពថវិកា និងការស្មានការចូលរួមពីឃុំ & សហគមន៍ (Gap Analysis)
            </h4>
          </div>

          <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-all shadow-xs border ${
            !isGapCollapsed
              ? 'bg-indigo-50 text-indigo-700 border-indigo-200 hover:bg-indigo-100'
              : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
          }`}>
            {!isGapCollapsed ? (
              <ChevronUp className="w-4 h-4 text-indigo-700" />
            ) : (
              <ChevronDown className="w-4 h-4 text-slate-600" />
            )}
          </div>
        </div>

        {!isGapCollapsed && (
          <div className="space-y-4 animate-in fade-in duration-200">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
          
          {/* Card 1: State PB Calculator based on Student Count */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800">១. ថវិការដ្ឋទទួលបាន (PB)</span>
              <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                ផ្អែកលើចំនួនសិស្ស
              </span>
            </div>
            
            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between gap-2">
                <span className="text-slate-500">ចំនួនសិស្សសរុប៖</span>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => onUpdatePlan({ studentCount: Math.max(10, (budgetReq.studentCount || 420) - 10) })}
                    className="p-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700"
                    title="ថយ ១០ នាក់"
                  >
                    <Minus className="w-3 h-3" />
                  </button>
                  <input
                    type="number"
                    value={budgetReq.studentCount}
                    onChange={(e) => onUpdatePlan({ studentCount: Number(e.target.value) || 0 })}
                    className="w-16 p-1 text-center font-bold border rounded-lg text-slate-800 text-xs"
                  />
                  <button
                    onClick={() => onUpdatePlan({ studentCount: (budgetReq.studentCount || 420) + 10 })}
                    className="p-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700"
                    title="បន្ថែម ១០ នាក់"
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between gap-2">
                <span className="text-slate-500">កញ្ចប់ក្នុង១សិស្ស៖</span>
                <input
                  type="number"
                  value={budgetReq.perStudentRateRiel}
                  onChange={(e) => onUpdatePlan({ perStudentRateRiel: Number(e.target.value) || 0 })}
                  className="w-24 p-1 text-right font-bold border rounded-lg text-slate-800 text-xs"
                />
              </div>

              <div className="pt-2 border-t flex justify-between font-bold text-emerald-800">
                <span>សរុបថវិការដ្ឋ (តិចតួច)៖</span>
                <span>{formatRiel(calculatedStateBudget)}</span>
              </div>
            </div>
          </div>

          {/* Card 2: Commune CIP Ask (ស្មាន និងបន្ថែម/ថយចុះ) */}
          <div className="bg-white p-4 rounded-xl border border-emerald-200 shadow-2xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-950">២. ស្នើវិនិយោគឃុំ (CIP)</span>
              <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                ស្មានបន្ថែម/ថយ
              </span>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between gap-1">
                <button
                  onClick={() => onUpdatePlan({ communeCipAskTotal: Math.max(0, (budgetReq.communeCipAskTotal || 0) - 500000) })}
                  className="px-2 py-1 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-700 text-[11px] font-bold"
                >
                  - ៥០ម៉ឺន
                </button>
                <input
                  type="number"
                  value={budgetReq.communeCipAskTotal}
                  onChange={(e) => onUpdatePlan({ communeCipAskTotal: Number(e.target.value) || 0 })}
                  className="w-32 p-1 text-right font-bold text-emerald-800 border rounded-lg text-xs"
                />
                <button
                  onClick={() => onUpdatePlan({ communeCipAskTotal: (budgetReq.communeCipAskTotal || 0) + 500000 })}
                  className="px-2 py-1 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-lg text-[11px] font-bold"
                >
                  + ៥០ម៉ឺន
                </button>
              </div>

              <p className="text-[11px] text-slate-500">
                សម្រាប់ដាក់បញ្ចូលក្នុង <strong>គម្រោងវិនិយោគឃុំ (CIP)</strong> ដូចជា របង សួន បង្គន់...
              </p>

              <div className="pt-1 text-right font-bold text-emerald-700">
                {formatRiel(budgetReq.communeCipAskTotal)}
              </div>
            </div>
          </div>

          {/* Card 3: Community Contribution Ask (ស្មាន និងបន្ថែម/ថយចុះ) */}
          <div className="bg-white p-4 rounded-xl border border-amber-200 shadow-2xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-amber-950">៣. សហគមន៍ & សប្បុរសជន</span>
              <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-800 text-[10px] font-bold">
                ស្មានបន្ថែម/ថយ
              </span>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between gap-1">
                <button
                  onClick={() => onUpdatePlan({ communityContributionTotal: Math.max(0, (budgetReq.communityContributionTotal || 0) - 200000) })}
                  className="px-2 py-1 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-700 text-[11px] font-bold"
                >
                  - ២០ម៉ឺន
                </button>
                <input
                  type="number"
                  value={budgetReq.communityContributionTotal}
                  onChange={(e) => onUpdatePlan({ communityContributionTotal: Number(e.target.value) || 0 })}
                  className="w-32 p-1 text-right font-bold text-amber-800 border rounded-lg text-xs"
                />
                <button
                  onClick={() => onUpdatePlan({ communityContributionTotal: (budgetReq.communityContributionTotal || 0) + 200000 })}
                  className="px-2 py-1 bg-amber-100 hover:bg-amber-200 text-amber-800 rounded-lg text-[11px] font-bold"
                >
                  + ២០ម៉ឺន
                </button>
              </div>

              <p className="text-[11px] text-slate-500">
                ការចូលរួមពីមាតាបិតា សមាគម គ.គ.ស និងសប្បុរសជននានា
              </p>

              <div className="pt-1 text-right font-bold text-amber-700">
                {formatRiel(budgetReq.communityContributionTotal)}
              </div>
            </div>
          </div>

        </div>

        {/* Final Gap Balance Comparison */}
        <div className="p-4 bg-white rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div>
            <div className="font-bold text-slate-900">
              តុល្យភាពថវិកា (Budget Gap vs Asks)៖
            </div>
            <div className="text-slate-500 text-[11px] mt-0.5">
              តម្រូវការខ្វះខាត ({formatRiel(fundingGapYear1)}) ធៀបនឹងការស្នើសុំ ({formatRiel(totalFundingAsked)})
            </div>
          </div>

          <div className="flex items-center gap-3">
            {balance >= 0 ? (
              <div className="px-3 py-1.5 rounded-xl bg-emerald-100 text-emerald-800 font-bold flex items-center gap-1.5">
                <Check className="w-4 h-4" />
                <span>ថវិកាគ្រប់គ្រាន់ពេញលេញ (+{formatRiel(balance)})</span>
              </div>
            ) : (
              <div className="px-3 py-1.5 rounded-xl bg-amber-100 text-amber-900 font-bold flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-amber-600" />
                <span>នៅខ្វះ {formatRiel(Math.abs(balance))} (ត្រូវបន្ថែមការកៀរគរ)</span>
              </div>
            )}
          </div>
        </div>
      </div>
    )}

      </div>
    </div>
  );
};
