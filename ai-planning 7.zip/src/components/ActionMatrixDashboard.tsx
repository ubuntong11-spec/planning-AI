import React, { useState, useMemo } from 'react';
import { 
  ActionMatrixItem, 
  ActivityStatus 
} from '../types/plan';
import { 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  TrendingUp, 
  PieChart as PieIcon, 
  BarChart3, 
  Filter, 
  Search, 
  Calendar, 
  Coins, 
  UserCheck, 
  Check, 
  Edit3, 
  ArrowUpRight,
  ShieldCheck,
  Percent,
  Layers,
  Sparkles
} from 'lucide-react';

interface ActionMatrixDashboardProps {
  items: ActionMatrixItem[];
  onChangeItems?: (newItems: ActionMatrixItem[]) => void;
  onOpenTableEdit?: () => void;
}

export const ActionMatrixDashboard: React.FC<ActionMatrixDashboardProps> = ({
  items,
  onChangeItems,
  onOpenTableEdit,
}) => {
  const [filterStatus, setFilterStatus] = useState<'all' | ActivityStatus>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [chartMode, setChartMode] = useState<'donut' | 'pie'>('donut');
  const [hoveredSlice, setHoveredSlice] = useState<ActivityStatus | null>(null);

  // Normalize statuses for backward compatibility
  const normalizedItems = useMemo(() => {
    return items.map((item) => {
      let status: ActivityStatus = item.status || 'pending';
      let progress = typeof item.progressPercentage === 'number' 
        ? item.progressPercentage 
        : status === 'completed' ? 100 : status === 'in_progress' ? 50 : 0;
      return {
        ...item,
        status,
        progressPercentage: progress,
      };
    });
  }, [items]);

  // Statistics calculation
  const stats = useMemo(() => {
    const total = normalizedItems.length;
    const completed = normalizedItems.filter((i) => i.status === 'completed').length;
    const inProgress = normalizedItems.filter((i) => i.status === 'in_progress').length;
    const pending = normalizedItems.filter((i) => i.status === 'pending').length;

    // Binary completed vs pending view (combining in_progress + pending as pending/uncompleted if needed)
    const pendingOrInProgress = total - completed;

    const completedPercent = total > 0 ? Math.round((completed / total) * 100) : 0;
    const inProgressPercent = total > 0 ? Math.round((inProgress / total) * 100) : 0;
    const pendingPercent = total > 0 ? Math.round((pending / total) * 100) : 0;

    // Average granular progress (0-100%)
    const avgProgress = total > 0 
      ? Math.round(normalizedItems.reduce((acc, curr) => acc + (curr.progressPercentage || 0), 0) / total) 
      : 0;

    // Parse Riel budget strings e.g. "១,២០០,០០០ រៀល" or "1,200,000"
    const parseKhmerOrLatinNumber = (str: string) => {
      if (!str) return 0;
      const khmerNums: { [key: string]: string } = {
        '០': '0', '១': '1', '២': '2', '៣': '3', '៤': '4',
        '៥': '5', '៦': '6', '៧': '7', '៨': '8', '៩': '9'
      };
      const latinized = str.replace(/[០-៩]/g, (k) => khmerNums[k] || k);
      const digitsOnly = latinized.replace(/[^\d]/g, '');
      return parseInt(digitsOnly, 10) || 0;
    };

    const totalBudget = normalizedItems.reduce((sum, item) => sum + parseKhmerOrLatinNumber(item.budget), 0);
    const completedBudget = normalizedItems
      .filter((i) => i.status === 'completed')
      .reduce((sum, item) => sum + parseKhmerOrLatinNumber(item.budget), 0);
    const inProgressBudget = normalizedItems
      .filter((i) => i.status === 'in_progress')
      .reduce((sum, item) => sum + parseKhmerOrLatinNumber(item.budget), 0);

    return {
      total,
      completed,
      inProgress,
      pending,
      pendingOrInProgress,
      completedPercent,
      inProgressPercent,
      pendingPercent,
      avgProgress,
      totalBudget,
      completedBudget,
      inProgressBudget,
    };
  }, [normalizedItems]);

  // Update item status directly from dashboard
  const handleUpdateStatus = (id: string, newStatus: ActivityStatus) => {
    if (!onChangeItems) return;
    const updated = items.map((item) => {
      if (item.id === id) {
        return {
          ...item,
          status: newStatus,
          progressPercentage: newStatus === 'completed' ? 100 : newStatus === 'in_progress' ? 50 : 0,
          completedDate: newStatus === 'completed' ? new Date().toISOString().split('T')[0] : undefined,
        };
      }
      return item;
    });
    onChangeItems(updated);
  };

  // Update item progress slider directly
  const handleUpdateProgress = (id: string, progress: number) => {
    if (!onChangeItems) return;
    const updated = items.map((item) => {
      if (item.id === id) {
        let status: ActivityStatus = item.status || 'pending';
        if (progress >= 100) status = 'completed';
        else if (progress > 0) status = 'in_progress';
        else status = 'pending';
        return {
          ...item,
          progressPercentage: progress,
          status,
        };
      }
      return item;
    });
    onChangeItems(updated);
  };

  // Filtered items
  const filteredItems = useMemo(() => {
    return normalizedItems.filter((item) => {
      const matchesStatus = filterStatus === 'all' || item.status === filterStatus;
      const matchesSearch = searchQuery.trim() === '' || 
        item.activity.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.indicator.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.responsiblePerson.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.timeline.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesStatus && matchesSearch;
    });
  }, [normalizedItems, filterStatus, searchQuery]);

  // SVG Pie / Donut Chart Angles Calculation
  const pieSlices = useMemo(() => {
    const total = stats.total;
    if (total === 0) return [];

    const slicesData = [
      {
        id: 'completed' as ActivityStatus,
        label: 'សម្រេចបាន (Completed)',
        shortLabel: 'សម្រេចបាន',
        count: stats.completed,
        percent: stats.completedPercent,
        color: '#10b981', // emerald-500
        hoverColor: '#059669',
        bgColor: 'bg-emerald-500',
        textColor: 'text-emerald-700',
        bgLight: 'bg-emerald-50',
      },
      {
        id: 'in_progress' as ActivityStatus,
        label: 'កំពុងអនុវត្ត (In Progress)',
        shortLabel: 'កំពុងអនុវត្ត',
        count: stats.inProgress,
        percent: stats.inProgressPercent,
        color: '#f59e0b', // amber-500
        hoverColor: '#d97706',
        bgColor: 'bg-amber-500',
        textColor: 'text-amber-700',
        bgLight: 'bg-amber-50',
      },
      {
        id: 'pending' as ActivityStatus,
        label: 'មិនទាន់ចាប់ផ្ដើម (Pending)',
        shortLabel: 'មិនទាន់ចាប់ផ្ដើម',
        count: stats.pending,
        percent: stats.pendingPercent,
        color: '#94a3b8', // slate-400
        hoverColor: '#64748b',
        bgColor: 'bg-slate-400',
        textColor: 'text-slate-700',
        bgLight: 'bg-slate-100',
      },
    ];

    let currentAngle = -90; // Start at 12 o'clock

    return slicesData.map((slice) => {
      const sliceAngle = (slice.count / total) * 360;
      const startAngle = currentAngle;
      const endAngle = currentAngle + sliceAngle;
      currentAngle = endAngle;

      // SVG path geometry calculation
      const polarToCartesian = (cx: number, cy: number, r: number, angleDeg: number) => {
        const rad = ((angleDeg - 90) * Math.PI) / 180.0;
        return {
          x: cx + r * Math.cos(rad),
          y: cy + r * Math.sin(rad),
        };
      };

      const cx = 100;
      const cy = 100;
      const outerR = 85;
      const innerR = chartMode === 'donut' ? 52 : 0;

      // Prevent full 360 edge case error
      const actualAngle = sliceAngle >= 359.99 ? 359.99 : sliceAngle;
      const adjustedEnd = startAngle + actualAngle;

      const p1 = polarToCartesian(cx, cy, outerR, startAngle + 90);
      const p2 = polarToCartesian(cx, cy, outerR, adjustedEnd + 90);
      const p3 = polarToCartesian(cx, cy, innerR, adjustedEnd + 90);
      const p4 = polarToCartesian(cx, cy, innerR, startAngle + 90);

      const largeArcFlag = actualAngle > 180 ? 1 : 0;

      let d = '';
      if (slice.count === 0) {
        d = '';
      } else if (chartMode === 'donut') {
        d = [
          `M ${p1.x} ${p1.y}`,
          `A ${outerR} ${outerR} 0 ${largeArcFlag} 1 ${p2.x} ${p2.y}`,
          `L ${p3.x} ${p3.y}`,
          `A ${innerR} ${innerR} 0 ${largeArcFlag} 0 ${p4.x} ${p4.y}`,
          'Z',
        ].join(' ');
      } else {
        d = [
          `M ${cx} ${cy}`,
          `L ${p1.x} ${p1.y}`,
          `A ${outerR} ${outerR} 0 ${largeArcFlag} 1 ${p2.x} ${p2.y}`,
          'Z',
        ].join(' ');
      }

      return {
        ...slice,
        startAngle,
        endAngle: adjustedEnd,
        d,
      };
    });
  }, [stats, chartMode]);

  return (
    <div className="space-y-6 font-kantumruy">
      {/* =========================================================================
          TOP BANNER / HEADER CARD
         ========================================================================= */}
      <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 text-white p-5 sm:p-6 rounded-2xl shadow-md border border-slate-800 relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-44 h-44 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 -mb-8 w-36 h-36 bg-emerald-500/10 rounded-full blur-xl pointer-events-none" />

        <div className="relative z-10 flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-2.5 py-0.5 rounded-full bg-blue-500/20 text-blue-300 text-xs font-semibold border border-blue-400/30 flex items-center gap-1">
                <BarChart3 className="w-3.5 h-3.5 text-blue-300" />
                ផ្ទាំងតាមដានវឌ្ឍនភាព AOP
              </span>
              <span className="text-xs text-slate-400">
                • ម៉ាទ្រីសសកម្មភាពអនុវត្ត
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <span>វឌ្ឍនភាពនៃការអនុវត្តសកម្មភាពសាលារៀន</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mt-1">
              តាមដានការអនុវត្តជាក់ស្តែង គណនាភាគរយសម្រេច និងប្រៀបធៀបសកម្មភាពដែលបានបញ្ចប់ ធៀបនឹងសកម្មភាពនៅសល់
            </p>
          </div>

          <div className="flex items-center gap-2">
            {onOpenTableEdit && (
              <button
                onClick={onOpenTableEdit}
                className="px-3.5 py-2 bg-white/10 hover:bg-white/20 text-white text-xs font-semibold rounded-xl border border-white/15 transition-all flex items-center gap-1.5 backdrop-blur-sm"
              >
                <Edit3 className="w-3.5 h-3.5 text-blue-300" />
                <span>កែសម្រួលតារាងម៉ាទ្រីស</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* =========================================================================
          KEY PERFORMANCE METRIC CARDS
         ========================================================================= */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        {/* Total Activities */}
        <div 
          onClick={() => setFilterStatus('all')}
          className={`cursor-pointer p-4 rounded-2xl border transition-all ${
            filterStatus === 'all' 
              ? 'bg-blue-50/80 border-blue-300 shadow-sm ring-2 ring-blue-500/20' 
              : 'bg-white border-slate-200 hover:border-slate-300 hover:shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between text-slate-500 text-xs mb-1">
            <span>សកម្មភាពសរុប</span>
            <Layers className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            {stats.total}
          </div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
            <span className="font-semibold text-slate-700">១០០%</span> នៃផែនការប្រចាំឆ្នាំ
          </div>
        </div>

        {/* Completed */}
        <div 
          onClick={() => setFilterStatus('completed')}
          className={`cursor-pointer p-4 rounded-2xl border transition-all ${
            filterStatus === 'completed' 
              ? 'bg-emerald-50/90 border-emerald-400 shadow-sm ring-2 ring-emerald-500/20' 
              : 'bg-white border-slate-200 hover:border-emerald-300 hover:shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between text-emerald-700 text-xs mb-1">
            <span className="font-medium">សម្រេចបាន (Completed)</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-emerald-700">
            {stats.completed}
          </div>
          <div className="text-[11px] text-emerald-600 mt-1 flex items-center gap-1">
            <span className="font-bold bg-emerald-100 px-1.5 py-0.2 rounded text-emerald-800">
              {stats.completedPercent}%
            </span>
            <span>នៃសកម្មភាពទាំងអស់</span>
          </div>
        </div>

        {/* In Progress */}
        <div 
          onClick={() => setFilterStatus('in_progress')}
          className={`cursor-pointer p-4 rounded-2xl border transition-all ${
            filterStatus === 'in_progress' 
              ? 'bg-amber-50/90 border-amber-400 shadow-sm ring-2 ring-amber-500/20' 
              : 'bg-white border-slate-200 hover:border-amber-300 hover:shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between text-amber-700 text-xs mb-1">
            <span className="font-medium">កំពុងអនុវត្ត (In Progress)</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-amber-700">
            {stats.inProgress}
          </div>
          <div className="text-[11px] text-amber-600 mt-1 flex items-center gap-1">
            <span className="font-bold bg-amber-100 px-1.5 py-0.2 rounded text-amber-800">
              {stats.inProgressPercent}%
            </span>
            <span>កំពុងដំណើរការ</span>
          </div>
        </div>

        {/* Pending */}
        <div 
          onClick={() => setFilterStatus('pending')}
          className={`cursor-pointer p-4 rounded-2xl border transition-all ${
            filterStatus === 'pending' 
              ? 'bg-slate-100 border-slate-400 shadow-sm ring-2 ring-slate-500/20' 
              : 'bg-white border-slate-200 hover:border-slate-300 hover:shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between text-slate-600 text-xs mb-1">
            <span className="font-medium">មិនទាន់ចាប់ផ្ដើម (Pending)</span>
            <AlertCircle className="w-4 h-4 text-slate-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-600">
            {stats.pending}
          </div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
            <span className="font-bold bg-slate-100 px-1.5 py-0.2 rounded text-slate-700">
              {stats.pendingPercent}%
            </span>
            <span>រង់ចាំតាមកាលវិភាគ</span>
          </div>
        </div>
      </div>

      {/* =========================================================================
          VISUAL PROGRESS BAR & PIE/DONUT CHART SECTION
         ========================================================================= */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left: Overall Multi-Segment Progress Bar & Milestones (7 Columns) */}
        <div className="lg:col-span-7 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-blue-600" />
                <span>របារវឌ្ឍនភាពអនុវត្តរួម (Implementation Progress Bar)</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                បង្ហាញសមាមាត្រសកម្មភាព សម្រេចបាន vs កំពុងដំណើរការ vs រង់ចាំ
              </p>
            </div>
            <div className="text-right">
              <span className="text-xl sm:text-2xl font-black text-blue-600">
                {stats.avgProgress}%
              </span>
              <span className="block text-[10px] text-slate-400 font-medium">វឌ្ឍនភាពមធ្យម</span>
            </div>
          </div>

          {/* Multi-Segment Stacked Progress Bar */}
          <div className="space-y-2">
            <div className="h-6 w-full bg-slate-100 rounded-xl overflow-hidden flex shadow-inner p-1 gap-0.5 border border-slate-200">
              {stats.completedPercent > 0 && (
                <div 
                  style={{ width: `${stats.completedPercent}%` }} 
                  className="bg-emerald-500 h-full rounded-lg transition-all duration-500 relative group flex items-center justify-center text-[11px] text-white font-bold"
                  title={`សម្រេចបាន: ${stats.completed} (${stats.completedPercent}%)`}
                >
                  {stats.completedPercent >= 12 && `${stats.completedPercent}%`}
                </div>
              )}
              {stats.inProgressPercent > 0 && (
                <div 
                  style={{ width: `${stats.inProgressPercent}%` }} 
                  className="bg-amber-400 h-full rounded-lg transition-all duration-500 relative group flex items-center justify-center text-[11px] text-amber-950 font-bold"
                  title={`កំពុងអនុវត្ត: ${stats.inProgress} (${stats.inProgressPercent}%)`}
                >
                  {stats.inProgressPercent >= 12 && `${stats.inProgressPercent}%`}
                </div>
              )}
              {stats.pendingPercent > 0 && (
                <div 
                  style={{ width: `${stats.pendingPercent}%` }} 
                  className="bg-slate-300 h-full rounded-lg transition-all duration-500 relative group flex items-center justify-center text-[11px] text-slate-700 font-bold"
                  title={`មិនទាន់ចាប់ផ្ដើម: ${stats.pending} (${stats.pendingPercent}%)`}
                >
                  {stats.pendingPercent >= 12 && `${stats.pendingPercent}%`}
                </div>
              )}
            </div>

            {/* Milestones Indicator */}
            <div className="flex justify-between items-center text-[10px] text-slate-400 font-medium px-1">
              <span>0% ចាប់ផ្តើម</span>
              <span className="hidden sm:inline">25% ត្រីមាសទី១</span>
              <span>50% ពាក់កណ្តាលឆ្នាំ</span>
              <span className="hidden sm:inline">75% ត្រីមាសទី៣</span>
              <span>100% បញ្ចប់ផែនការ</span>
            </div>
          </div>

          {/* Quick Comparison Bar: Completed vs Pending / Incomplete */}
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/80 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-700 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                ការប្រៀបធៀប៖ សកម្មភាពសម្រេចបាន (Completed) ធៀបនឹង សកម្មភាពនៅសល់ (Pending)
              </span>
              <span className="text-[11px] font-bold text-slate-600">
                {stats.completed} / {stats.total}
              </span>
            </div>

            <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden flex">
              <div 
                style={{ width: `${stats.completedPercent}%` }}
                className="bg-emerald-600 h-full rounded-full transition-all duration-500"
              />
            </div>

            <div className="flex justify-between items-center text-[11px]">
              <span className="text-emerald-700 font-medium flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
                សម្រេចបាន៖ {stats.completed} សកម្មភាព ({stats.completedPercent}%)
              </span>
              <span className="text-slate-600 font-medium flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-slate-400"></span>
                នៅសល់៖ {stats.pendingOrInProgress} សកម្មភាព ({100 - stats.completedPercent}%)
              </span>
            </div>
          </div>

          {/* Financial Implementation Breakdown */}
          {stats.totalBudget > 0 && (
            <div className="grid grid-cols-2 gap-3 pt-1">
              <div className="bg-emerald-50/60 p-3 rounded-xl border border-emerald-100">
                <div className="text-[11px] text-emerald-700 flex items-center gap-1">
                  <Coins className="w-3.5 h-3.5" />
                  <span>ថវិកាសកម្មភាពបានសម្រេច</span>
                </div>
                <div className="text-sm sm:text-base font-bold text-emerald-800 mt-0.5">
                  {stats.completedBudget.toLocaleString()} រៀល
                </div>
              </div>
              <div className="bg-blue-50/60 p-3 rounded-xl border border-blue-100">
                <div className="text-[11px] text-blue-700 flex items-center gap-1">
                  <Coins className="w-3.5 h-3.5" />
                  <span>ថវិកាសរុបនៃម៉ាទ្រីស</span>
                </div>
                <div className="text-sm sm:text-base font-bold text-blue-900 mt-0.5">
                  {stats.totalBudget.toLocaleString()} រៀល
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Right: Interactive SVG Pie / Donut Chart (5 Columns) */}
        <div className="lg:col-span-5 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <PieIcon className="w-4 h-4 text-emerald-600" />
                <span>គំនូសតាងចំណិត (Pie / Donut Chart)</span>
              </h3>
              <p className="text-[11px] text-slate-500">
                ការបែងចែកស្ថានភាពសកម្មភាព
              </p>
            </div>

            {/* Toggle Donut vs Full Pie */}
            <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200 text-[11px]">
              <button
                type="button"
                onClick={() => setChartMode('donut')}
                className={`px-2 py-0.5 rounded-md transition-colors ${
                  chartMode === 'donut' ? 'bg-white font-bold text-blue-700 shadow-2xs' : 'text-slate-600'
                }`}
              >
                ដូណាត់
              </button>
              <button
                type="button"
                onClick={() => setChartMode('pie')}
                className={`px-2 py-0.5 rounded-md transition-colors ${
                  chartMode === 'pie' ? 'bg-white font-bold text-blue-700 shadow-2xs' : 'text-slate-600'
                }`}
              >
                ចំណិតពេញ
              </button>
            </div>
          </div>

          {/* SVG Canvas Area */}
          <div className="relative flex items-center justify-center my-3">
            <svg 
              viewBox="0 0 200 200" 
              className="w-48 h-48 sm:w-52 sm:h-52 transform -rotate-90 filter drop-shadow-xs"
            >
              {pieSlices.map((slice) => {
                if (slice.count === 0 || !slice.d) return null;
                const isHovered = hoveredSlice === slice.id;
                return (
                  <path
                    key={slice.id}
                    d={slice.d}
                    fill={isHovered ? slice.hoverColor : slice.color}
                    className="cursor-pointer transition-all duration-200 hover:opacity-95"
                    onMouseEnter={() => setHoveredSlice(slice.id)}
                    onMouseLeave={() => setHoveredSlice(null)}
                    onClick={() => setFilterStatus(filterStatus === slice.id ? 'all' : slice.id)}
                  />
                );
              })}
            </svg>

            {/* Donut Center Display */}
            {chartMode === 'donut' && (
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center">
                <span className="text-2xl font-black text-slate-800">
                  {stats.completedPercent}%
                </span>
                <span className="text-[10px] font-semibold text-emerald-600">
                  សម្រេចបាន
                </span>
                <span className="text-[9px] text-slate-400">
                  {stats.completed} នៃ {stats.total}
                </span>
              </div>
            )}
          </div>

          {/* Interactive Legend */}
          <div className="space-y-1.5 pt-2 border-t border-slate-100 text-xs">
            {pieSlices.map((slice) => {
              const isSelected = filterStatus === slice.id;
              return (
                <div
                  key={slice.id}
                  onClick={() => setFilterStatus(filterStatus === slice.id ? 'all' : slice.id)}
                  onMouseEnter={() => setHoveredSlice(slice.id)}
                  onMouseLeave={() => setHoveredSlice(null)}
                  className={`flex items-center justify-between p-1.5 rounded-lg cursor-pointer transition-colors ${
                    isSelected ? 'bg-slate-100 font-bold' : 'hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span 
                      style={{ backgroundColor: slice.color }} 
                      className="w-3 h-3 rounded-full shrink-0 shadow-2xs" 
                    />
                    <span className="text-slate-700 text-xs">{slice.label}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-slate-500 font-semibold">{slice.count}</span>
                    <span className="text-[11px] text-slate-400 font-mono w-10 text-right">
                      {slice.percent}%
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* =========================================================================
          INTERACTIVE ACTIVITY LIST WITH QUICK STATUS TOGGLES
         ========================================================================= */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {/* Table / List Controls */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 bg-slate-50/70">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              បញ្ជីសកម្មភាព និងការធ្វើបច្ចុប្បន្នភាពស្ថានភាព
            </h3>
            <p className="text-xs text-slate-500">
              ចុចប៊ូតុងស្ថានភាព ឬរំកិលរបារ % ដើម្បីកត់ត្រាវឌ្ឍនភាពជាក់ស្តែង
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Filter Status Tabs */}
            <div className="flex items-center bg-white p-1 rounded-xl border border-slate-200 text-xs">
              <button
                type="button"
                onClick={() => setFilterStatus('all')}
                className={`px-2.5 py-1 rounded-lg transition-colors ${
                  filterStatus === 'all' ? 'bg-blue-600 text-white font-semibold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                ទាំងអស់ ({stats.total})
              </button>
              <button
                type="button"
                onClick={() => setFilterStatus('completed')}
                className={`px-2.5 py-1 rounded-lg transition-colors ${
                  filterStatus === 'completed' ? 'bg-emerald-600 text-white font-semibold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                សម្រេច ({stats.completed})
              </button>
              <button
                type="button"
                onClick={() => setFilterStatus('in_progress')}
                className={`px-2.5 py-1 rounded-lg transition-colors ${
                  filterStatus === 'in_progress' ? 'bg-amber-600 text-white font-semibold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                កំពុងអនុវត្ត ({stats.inProgress})
              </button>
              <button
                type="button"
                onClick={() => setFilterStatus('pending')}
                className={`px-2.5 py-1 rounded-lg transition-colors ${
                  filterStatus === 'pending' ? 'bg-slate-700 text-white font-semibold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                មិនទាន់ ({stats.pending})
              </button>
            </div>

            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="ស្វែងរកសកម្មភាព..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-xl focus:border-blue-500 focus:outline-none w-40 sm:w-56"
              />
            </div>
          </div>
        </div>

        {/* Activities Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200 font-kantumruy">
              <tr>
                <th className="py-3 px-3 text-center w-12 border-r border-slate-200">ល.រ</th>
                <th className="py-3 px-3 min-w-[220px] border-r border-slate-200">សកម្មភាពអនុវត្ត</th>
                <th className="py-3 px-3 min-w-[140px] border-r border-slate-200">កាលវិភាគ & ថវិកា</th>
                <th className="py-3 px-3 min-w-[140px] border-r border-slate-200">អ្នកទទួលខុសត្រូវ</th>
                <th className="py-3 px-3 min-w-[160px] border-r border-slate-200">វឌ្ឍនភាព (%)</th>
                <th className="py-3 px-3 text-center min-w-[190px]">កំណត់ស្ថានភាព</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-kantumruy">
              {filteredItems.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400 text-xs">
                    មិនមានសកម្មភាពត្រូវគ្នានឹងការស្វែងរក ឬតម្រងនេះទេ
                  </td>
                </tr>
              ) : (
                filteredItems.map((item, idx) => {
                  return (
                    <tr 
                      key={item.id} 
                      className={`hover:bg-slate-50/80 transition-colors ${
                        item.status === 'completed' ? 'bg-emerald-50/20' : ''
                      }`}
                    >
                      {/* Index */}
                      <td className="py-3 px-3 text-center font-bold text-slate-500 border-r border-slate-200">
                        {idx + 1}
                      </td>

                      {/* Activity Details */}
                      <td className="py-3 px-3 border-r border-slate-200">
                        <div className="font-semibold text-slate-900 leading-snug">
                          {item.activity}
                        </div>
                        <div className="text-[11px] text-slate-500 mt-0.5">
                          <span className="font-medium text-slate-600">សូចនាករ៖</span> {item.indicator}
                        </div>
                        {item.notes && (
                          <div className="text-[10px] text-blue-600 bg-blue-50/80 rounded px-1.5 py-0.5 mt-1 inline-block">
                            កំណត់ចំណាំ៖ {item.notes}
                          </div>
                        )}
                      </td>

                      {/* Timeline & Budget */}
                      <td className="py-3 px-3 border-r border-slate-200 space-y-1">
                        <div className="flex items-center gap-1 text-slate-700">
                          <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span>{item.timeline}</span>
                        </div>
                        <div className="flex items-center gap-1 font-semibold text-emerald-700">
                          <Coins className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>{item.budget}</span>
                        </div>
                      </td>

                      {/* Responsible Person */}
                      <td className="py-3 px-3 text-slate-600 border-r border-slate-200">
                        <div className="flex items-center gap-1">
                          <UserCheck className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span>{item.responsiblePerson}</span>
                        </div>
                      </td>

                      {/* Granular Progress Slider */}
                      <td className="py-3 px-3 border-r border-slate-200">
                        <div className="space-y-1.5">
                          <div className="flex justify-between items-center text-[11px]">
                            <span className="text-slate-500">កម្រិតសម្រេច</span>
                            <span className="font-bold text-slate-800">
                              {item.progressPercentage || 0}%
                            </span>
                          </div>
                          <input
                            type="range"
                            min="0"
                            max="100"
                            step="5"
                            value={item.progressPercentage || 0}
                            onChange={(e) => handleUpdateProgress(item.id, parseInt(e.target.value, 10))}
                            className="w-full accent-blue-600 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
                          />
                        </div>
                      </td>

                      {/* Status Badges & Quick Toggles */}
                      <td className="py-3 px-3 text-center">
                        <div className="inline-flex p-1 bg-slate-100 rounded-xl gap-1 border border-slate-200">
                          {/* Completed Toggle */}
                          <button
                            type="button"
                            onClick={() => handleUpdateStatus(item.id, 'completed')}
                            title="កំណត់ជាសម្រេចបាន"
                            className={`px-2 py-1 rounded-lg text-[11px] font-semibold flex items-center gap-1 transition-all ${
                              item.status === 'completed'
                                ? 'bg-emerald-600 text-white shadow-2xs'
                                : 'text-slate-600 hover:text-emerald-700 hover:bg-emerald-50'
                            }`}
                          >
                            <Check className="w-3 h-3" />
                            <span>សម្រេច</span>
                          </button>

                          {/* In Progress Toggle */}
                          <button
                            type="button"
                            onClick={() => handleUpdateStatus(item.id, 'in_progress')}
                            title="កំណត់ជាកំពុងអនុវត្ត"
                            className={`px-2 py-1 rounded-lg text-[11px] font-semibold flex items-center gap-1 transition-all ${
                              item.status === 'in_progress'
                                ? 'bg-amber-500 text-white shadow-2xs'
                                : 'text-slate-600 hover:text-amber-700 hover:bg-amber-50'
                            }`}
                          >
                            <Clock className="w-3 h-3" />
                            <span>កំពុងធ្វើ</span>
                          </button>

                          {/* Pending Toggle */}
                          <button
                            type="button"
                            onClick={() => handleUpdateStatus(item.id, 'pending')}
                            title="កំណត់ជាមិនទាន់ចាប់ផ្ដើម"
                            className={`px-2 py-1 rounded-lg text-[11px] font-semibold flex items-center gap-1 transition-all ${
                              item.status === 'pending'
                                ? 'bg-slate-600 text-white shadow-2xs'
                                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200'
                            }`}
                          >
                            <AlertCircle className="w-3 h-3" />
                            <span>មិនទាន់</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
