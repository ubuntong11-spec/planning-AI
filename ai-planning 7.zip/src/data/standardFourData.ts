export interface IndicatorRow {
  id: string;
  code: string; // e.g. "១", "១.១", "២", "២.១"
  title: string;
  unit: string; // "%", "ចំនួន", "លើក", "ក្បាល", "ដង"
  currentN: string; // លទ្ធផលសូចនាករឆ្នាំបច្ចុប្បន្ន(N)
  targetN1: string; // គោលដៅសូចនាករគ្រោងថវិកា (N+1)
  stateBudget: number; // ថវិការដ្ឋ
  nonStateBudget: number; // ថវិកាក្រៅពីរដ្ឋ
  isCategoryHeader?: boolean; // Main category under standard (e.g. "១. ការប្រមូលកុមារចូលរៀន")
}

export interface StandardCategory {
  id: string;
  code: string;
  title: string;
  subtitle: string;
  defaultBudget: number;
  rows: IndicatorRow[];
}

export const DEFAULT_STANDARD_FOUR_DATA: StandardCategory[] = [
  {
    id: 'std-1',
    code: 'ស្តង់ដាទី១',
    title: 'លទ្ធផលសិក្សារបស់សិស្ស',
    subtitle: '៥ សូចនាករគន្លឹះ និង ១១ សូចនាកររង',
    defaultBudget: 2720000,
    rows: [
      { id: '1-1', code: '១', title: 'ការប្រមូលកុមារចូលរៀន', unit: '', currentN: '', targetN1: '', stateBudget: 200000, nonStateBudget: 0, isCategoryHeader: true },
      { id: '1-1-1', code: '១.១', title: 'ភាគរយកុមារថ្នាក់ទី១ ចូលរៀនត្រឹមត្រូវតាមអាយុ', unit: '%', currentN: '99', targetN1: '100', stateBudget: 200000, nonStateBudget: 0 },
      { id: '1-2', code: '២', title: 'កុមាររៀនបានគង់វង្សក្នុងសាលារៀន', unit: '', currentN: '', targetN1: '', stateBudget: 400000, nonStateBudget: 0, isCategoryHeader: true },
      { id: '1-2-1', code: '២.១', title: 'អត្រាបោះបង់ការសិក្សាបានថយចុះ', unit: '%', currentN: '5', targetN1: '3', stateBudget: 200000, nonStateBudget: 0 },
      { id: '1-2-2', code: '២.២', title: 'អត្រាត្រួតថ្នាក់បានថយចុះ', unit: '%', currentN: '3', targetN1: '2', stateBudget: 200000, nonStateBudget: 0 },
      { id: '1-3', code: '៣', title: 'លទ្ធផលនៃការសិក្សារបស់សិស្ស', unit: '', currentN: '', targetN1: '', stateBudget: 1420000, nonStateBudget: 0, isCategoryHeader: true },
      { id: '1-3-1', code: '៣.១', title: 'ភាគរយសិស្សមាននិទ្ទេស A B និង C មុខវិជ្ជាភាសាខ្មែរ', unit: '%', currentN: '46', targetN1: '50', stateBudget: 450000, nonStateBudget: 0 },
      { id: '1-3-2', code: '៣.២', title: 'ភាគរយសិស្សមាននិទ្ទេស A B និង C មុខវិជ្ជាគណិតវិទ្យា', unit: '%', currentN: '46', targetN1: '50', stateBudget: 450000, nonStateBudget: 0 },
      { id: '1-3-3', code: '៣.៣', title: 'ភាគរយសិស្សថ្នាក់ទី៣ មានសមត្ថភាពអានតាមស្តង់ដា (៤៥ ទៅ ៦០ពាក្យក្នុង១នាទី)', unit: '%', currentN: '43', targetN1: '47.5', stateBudget: 270000, nonStateBudget: 0 },
      { id: '1-3-4', code: '៣.៤', title: 'ភាគរយសិស្សថ្នាក់ទី៦ មានសមត្ថភាពអានតាមស្តង់ដា (១០០ ទៅ ១២០ពាក្យក្នុង១នាទី)', unit: '%', currentN: '51.5', targetN1: '55', stateBudget: 250000, nonStateBudget: 0 },
      { id: '1-4', code: '៤', title: 'ស្ថានភាពអាហារូបត្ថម្ភ', unit: '', currentN: '', targetN1: '', stateBudget: 300000, nonStateBudget: 0, isCategoryHeader: true },
      { id: '1-4-1', code: '៤.១', title: 'ភាគរយសិស្សមានស្ថានភាពអាហារូបត្ថម្ភធម្មតា', unit: '%', currentN: '65', targetN1: '69', stateBudget: 100000, nonStateBudget: 0 },
      { id: '1-4-2', code: '៤.២', title: 'ភាគរយសិស្សដែលមានបញ្ហាអាហារូបត្ថម្ភ ទទួលបានកិច្ចអន្តរាគមន៍', unit: '%', currentN: '52.5', targetN1: '56.5', stateBudget: 100000, nonStateBudget: 0 },
      { id: '1-4-3', code: '៤.៣', title: 'ភាគរយសិស្សក្រីក្រទទួលបានអាហារូបករណ៍ ឬការឧបត្ថម្ភនានា', unit: '%', currentN: '80', targetN1: '90', stateBudget: 100000, nonStateBudget: 0 },
      { id: '1-5', code: '៥', title: 'សីលធម៌ និងឥរិយាបថរបស់សិស្ស', unit: '', currentN: '', targetN1: '', stateBudget: 400000, nonStateBudget: 0, isCategoryHeader: true },
      { id: '1-5-1', code: '៥.១', title: 'ភាគរយកុមារទទួលបានការប្រឹក្សាយោបល់', unit: '%', currentN: '70', targetN1: '85', stateBudget: 100000, nonStateBudget: 0 },
    ],
  },
  {
    id: 'std-2',
    code: 'ស្តង់ដាទី២',
    title: 'ការបង្រៀន និងរៀន',
    subtitle: '៩ សូចនាករគន្លឹះ និង ៣០ សូចនាកររង',
    defaultBudget: 5983100,
    rows: [
      { id: '2-1', code: '១', title: 'ការអនុវត្តវិធីសាស្ត្របង្រៀន', unit: '', currentN: '', targetN1: '', stateBudget: 1400000, nonStateBudget: 0, isCategoryHeader: true },
      { id: '2-1-1', code: '១.១', title: 'ភាគរយគ្រូបង្រៀនថ្នាក់ទី១ និង/ឬ ទី២ និង/ឬ ទី៣ អនុវត្តកញ្ចប់សម្ភារៈអំណាន ថ្នាក់ដំបូងកម្រិត២ និងកម្រិត៣', unit: '%', currentN: '80', targetN1: '95', stateBudget: 350000, nonStateBudget: 0 },
      { id: '2-1-2', code: '១.២', title: 'ភាគរយគ្រូបង្រៀនថ្នាក់ទី១ និង/ឬ ទី២ និង/ឬ ទី៣ អនុវត្តកញ្ចប់សម្ភារៈគណិតវិទ្យា ថ្នាក់ដំបូងកម្រិត២ និងកម្រិត៣', unit: '%', currentN: '80', targetN1: '95', stateBudget: 350000, nonStateBudget: 0 },
      { id: '2-1-3', code: '១.៣', title: 'ភាគរយគ្រូបង្រៀនចូលរៀនវគ្គអភិវឌ្ឍសមត្ថភាពប្រចាំឆ្នាំ (កញ្ចប់សម្ភារៈអំណាននិងគណិតវិទ្យាថ្នាក់ដំបូង ការប្រឹក្សាគរុកោសល្យ វិធីសាស្ត្របង្រៀននានា ការអប់រំវិន័យបែបវិជ្ជមាន វិធីសាស្ត្រអំណានក្នុងបណ្ណាល័យ...)', unit: '%', currentN: '85', targetN1: '100', stateBudget: 300000, nonStateBudget: 0 },
      { id: '2-1-4', code: '១.៤', title: 'ចំនួនកិច្ចការជាគម្រោងដែលគ្រូថ្នាក់ទី៤-៦ បានដាក់ឱ្យសិស្សអនុវត្ត ក្នុង១ឆ្នាំ (គិតជាមធ្យម ក្នុងថ្នាក់/សាលា)', unit: 'ចំនួន', currentN: '2', targetN1: '4', stateBudget: 200000, nonStateBudget: 0 },
      { id: '2-1-5', code: '១.៥', title: 'ភាគរយសិស្សបានធ្វើកិច្ចការតាមផ្ទះ មេរៀនភាសាខ្មែរ គណិត និងមានការកែពីគ្រូ', unit: '%', currentN: '85', targetN1: '95', stateBudget: 200000, nonStateBudget: 0 },

      { id: '2-2', code: '២', title: 'ការអនុវត្តកម្មវិធីសិក្សានិងការរៀបចំផែនការបង្រៀន', unit: '', currentN: '', targetN1: '', stateBudget: 783100, nonStateBudget: 0, isCategoryHeader: true },
      { id: '2-2-1', code: '២.១', title: 'ភាគរយថ្នាក់រៀនដែលមានបំណែងចែកកម្មវិធីសិក្សា គ្រប់មុខវិជ្ជាសិក្សាគោល', unit: '%', currentN: '90', targetN1: '100', stateBudget: 150000, nonStateBudget: 0 },
      { id: '2-2-2', code: '២.២', title: 'ភាគរយគ្រូដែលបានរៀបចំកិច្ចតែងការបង្រៀនថ្មី ឬបានធ្វើបច្ចុប្បន្នកម្ម គ្រប់មេរៀន និងគ្រប់មុខវិជ្ជា', unit: '%', currentN: '85', targetN1: '100', stateBudget: 200000, nonStateBudget: 0 },
      { id: '2-2-3', code: '២.៣', title: 'ចំនួនដងថ្នាក់រៀនបិទទ្វារ (សរុបថ្នាក់ទាំងអស់គិតជាមធ្យម)', unit: '%', currentN: '2', targetN1: '0', stateBudget: 53100, nonStateBudget: 0 },
      { id: '2-2-4', code: '២.៤', title: 'ចំនួនថ្ងៃសាលាបិទទ្វារមិនស្របតាមប្រតិទិនសិក្សាប្រចាំឆ្នាំ', unit: 'លើក', currentN: '0', targetN1: '0', stateBudget: 80000, nonStateBudget: 0 },
      { id: '2-2-5', code: '២.៥', title: 'ភាគរយថ្នាក់ទី ៤-៦ បានបង្រៀនភាសាបរទេស', unit: '%', currentN: '60', targetN1: '80', stateBudget: 100000, nonStateBudget: 0 },
      { id: '2-2-6', code: '២.៦', title: 'ភាគរយថ្នាក់ទី ៤-៦ បានបង្រៀនមេរៀន បំណិនជីវិតមូលដ្ឋាន', unit: '%', currentN: '70', targetN1: '90', stateBudget: 100000, nonStateBudget: 0 },
      { id: '2-2-7', code: '២.៧', title: 'ភាគរយសិស្សអវត្តមាន លើសពី៤ដង ក្នុង១ឆ្នាំសិក្សា', unit: '%', currentN: '8', targetN1: '4', stateBudget: 100000, nonStateBudget: 0 },

      { id: '2-3', code: '៣', title: 'សម្ភារៈរៀននិងបង្រៀន', unit: '', currentN: '', targetN1: '', stateBudget: 1700000, nonStateBudget: 0, isCategoryHeader: true },
      { id: '2-3-1', code: '៣.១', title: 'ភាគរយសិស្សមានសៀវភៅសិក្សាគោលតាមនិយាម', unit: '%', currentN: '88', targetN1: '98', stateBudget: 200000, nonStateBudget: 0 },
      { id: '2-3-2', code: '៣.២', title: 'ភាគរយសិស្សថ្នាក់ទី១ និង/ឬ ទី២ និង/ឬ ទី៣ មានកញ្ចប់សម្ភារៈអំណាន និងគណិតវិទ្យា ថ្នាក់ដំបូង ដែលមាតាបិតាទិញឱ្យ', unit: '%', currentN: '75', targetN1: '90', stateBudget: 100000, nonStateBudget: 0 },
      { id: '2-3-3', code: '៣.៣', title: 'ភាគរយគ្រូបង្រៀនផលិត និងប្រើប្រាស់សម្ភារៈឧបទេសជាប្រចាំ', unit: '%', currentN: '70', targetN1: '90', stateBudget: 1000000, nonStateBudget: 0 },
      { id: '2-3-4', code: '៣.៤', title: 'ភាគរយគ្រូបង្រៀនប្រើប្រាស់បច្ចេកវិទ្យាបម្រើឱ្យការរៀន និងបង្រៀន', unit: '%', currentN: '50', targetN1: '75', stateBudget: 400000, nonStateBudget: 0 },

      { id: '2-4', code: '៤', title: 'ការជួយគាំទ្រសិស្ស', unit: '', currentN: '', targetN1: '', stateBudget: 200000, nonStateBudget: 0, isCategoryHeader: true },
      { id: '2-4-1', code: '៤.១', title: 'ភាគរយសិស្ស និងមាតាបិតា បានចុះកិច្ចព្រមព្រៀង រៀនសូត្រប្រចាំឆ្នាំជាមួយគ្រូ', unit: '%', currentN: '80', targetN1: '95', stateBudget: 50000, nonStateBudget: 0 },
      { id: '2-4-2', code: '៤.២', title: 'ភាគរយថ្នាក់រៀនមានការប្រជុំជាមួយ មាតាបិតា ពិនិត្យតាមដានការរៀនសូត្រ ទៀងទាត់', unit: '%', currentN: '75', targetN1: '90', stateBudget: 100000, nonStateBudget: 0 },
      { id: '2-4-3', code: '៤.៣', title: 'ភាគរយសិស្សរៀនយឺតបានទទួលការជួយប្រចាំខែ ផ្អែកតាមលទ្ធផល តេស្តស្តង់ដាប្រចាំខែ', unit: '%', currentN: '80', targetN1: '95', stateBudget: 50000, nonStateBudget: 0 },

      { id: '2-5', code: '៥', title: 'ដំណើរការបណ្ណាល័យ', unit: '', currentN: '', targetN1: '', stateBudget: 600000, nonStateBudget: 0, isCategoryHeader: true },
      { id: '2-5-1', code: '៥.១', title: 'ចំនួនសៀវភៅដែលសិស្សម្នាក់ៗ ខ្ចី-សង ក្នុង១ឆ្នាំ', unit: 'ក្បាល', currentN: '8', targetN1: '15', stateBudget: 300000, nonStateBudget: 0 },
      { id: '2-5-2', code: '៥.២', title: 'ចំនួនដង គ្រូបង្រៀនម្នាក់ៗក្នុង១ឆ្នាំ នាំសិស្សចូលបណ្ណាល័យអនុវត្តសកម្មភាពអាន ដោយប្រើប្រាស់វិធីសាស្ត្រអំណាន', unit: 'លើក', currentN: '10', targetN1: '18', stateBudget: 300000, nonStateBudget: 0 },

      { id: '2-6', code: '៦', title: 'ការធ្វើអធិការកិច្ចផ្ទៃក្នុង', unit: '', currentN: '', targetN1: '', stateBudget: 100000, nonStateBudget: 0, isCategoryHeader: true },
      { id: '2-6-1', code: '៦.១', title: 'ភាគរយគ្រូបង្រៀនទទួលបានការផ្តល់ប្រឹក្សាគរុកោសល្យ/អធិការកិច្ចថ្នាក់រៀន យ៉ាងតិចម្តង/ខែ', unit: '%', currentN: '85', targetN1: '100', stateBudget: 100000, nonStateBudget: 0 },

      { id: '2-7', code: '៧', title: 'ការប្រជុំបច្ចេកទេស', unit: '', currentN: '', targetN1: '', stateBudget: 200000, nonStateBudget: 0, isCategoryHeader: true },
      { id: '2-7-1', code: '៧.១', title: 'ចំនួនដងសាលារៀនបានរៀបចំការប្រជុំបច្ចេកទេស', unit: 'ដង', currentN: '7', targetN1: '7', stateBudget: 200000, nonStateBudget: 0 },

      { id: '2-8', code: '៨', title: 'ការអនុវត្តកម្មវិធីសិក្សាក្រៅម៉ោងសិក្សា', unit: '', currentN: '', targetN1: '', stateBudget: 800000, nonStateBudget: 0, isCategoryHeader: true },
      { id: '2-8-1', code: '៨.១', title: 'ចំនួនដងការប្រកួតប្រជែងអំណាន និងធ្វើលំហាត់គណិតវិទ្យាក្នុងមួយឆ្នាំ', unit: 'លើក', currentN: '2', targetN1: '2', stateBudget: 400000, nonStateBudget: 0 },
      { id: '2-8-2', code: '៨.២', title: 'ចំនួនក្លឹបសិក្សាបានបង្កើតដើម្បីជួយសិស្សរៀនយឺត និងជួយការងារផ្សេងៗរបស់សាលា', unit: 'លើក', currentN: '1', targetN1: '1', stateBudget: 200000, nonStateBudget: 0 },
      { id: '2-8-3', code: '៨.៣', title: 'ចំនួនដងសិស្សានុសិស្សបានចុះទស្សនៈកិច្ចសិក្សានៅតាមទីកន្លែងនានា ក្នុងមួយឆ្នាំសិក្សា', unit: 'លើក', currentN: '1', targetN1: '1', stateBudget: 200000, nonStateBudget: 0 },

      { id: '2-9', code: '៩', title: 'ការអនុវត្តការអប់រំសីលធម៌ ចរិយាធម៌', unit: '', currentN: '', targetN1: '', stateBudget: 200000, nonStateBudget: 0, isCategoryHeader: true },
      { id: '2-9-1', code: '៩.១', title: 'សាលារៀនមានកម្មវិធីលើកកម្ពស់ការអប់រំសីលធម៌ និងចរិយាធម៌ (ស្អាត សុភាព របៀប ទៀងពេល និងសមាធិ)', unit: 'លើក', currentN: '92.5', targetN1: '97', stateBudget: 50000, nonStateBudget: 0 },
      { id: '2-9-2', code: '៩.២', title: 'ចំនួនដងព្រះសង្ឃនិមន្តមកផ្តល់ធម៌ទេសនាអប់រំ ក្នុង១ឆ្នាំ', unit: 'លើក', currentN: '95', targetN1: '98', stateBudget: 50000, nonStateBudget: 0 },
      { id: '2-9-3', code: '៩.៣', title: 'សាលារៀនមានសកម្មភាពអប់រំសិល្បៈ (ចម្រៀង គំនូរ រាំ តន្ត្រី)', unit: 'លើក', currentN: '2', targetN1: '4', stateBudget: 50000, nonStateBudget: 0 },
    ],
  },
  {
    id: 'std-3',
    code: 'ស្តង់ដាទី៣',
    title: 'ការចូលរួមរបស់សហគមន៍',
    subtitle: '៣ សូចនាករគន្លឹះ និង ៦ សូចនាកររង',
    defaultBudget: 1000000,
    rows: [
      { id: '3-1', code: '១', title: 'ការបង្កើតនិងដំណើរការគណៈកម្មការគ្រប់គ្រងសាលារៀន និងថ្នាក់រៀន', unit: '', currentN: '', targetN1: '', stateBudget: 500000, nonStateBudget: 0, isCategoryHeader: true },
      { id: '3-1-1', code: '១.១', title: 'ចំនួនដងគណៈកម្មការគ្រប់គ្រងសាលារៀន (គ.គ.ស.) ប្រជុំក្នុងមួយឆ្នាំ', unit: 'លើក', currentN: '7', targetN1: '9', stateBudget: 100000, nonStateBudget: 0 },
      { id: '3-1-2', code: '១.២', title: 'ភាគរយថ្នាក់រៀនបង្កើត និងដំណើរការគណៈកម្មការគ្រប់គ្រងថ្នាក់រៀន (គ.គ.ថ)', unit: '%', currentN: '50', targetN1: '60', stateBudget: 300000, nonStateBudget: 0 },
      { id: '3-1-3', code: '១.៣', title: 'ភាគរយមាតាបិតា អ្នកអាណាព្យាបាលបានចូលរួមប្រជុំប្រចាំខែពិភាក្សាអំពីលទ្ធផលការសិក្សារបស់កូន និងកិច្ចការផ្សេងៗ', unit: '%', currentN: '70', targetN1: '85', stateBudget: 100000, nonStateBudget: 0 },

      { id: '3-2', code: '២', title: 'ការចូលរួមរបស់សហគមន៍', unit: '', currentN: '', targetN1: '', stateBudget: 300000, nonStateBudget: 0, isCategoryHeader: true },
      { id: '3-2-1', code: '២.១', title: 'សាលារៀនមានកិច្ចសហប្រតិបត្តិការភាពជាដៃគូវិនិយោគជាមួយវិស័យសាធារណៈ វិស័យឯកជន និងដៃគូអភិវឌ្ឍ', unit: 'ចំនួន', currentN: '2', targetN1: '3', stateBudget: 200000, nonStateBudget: 0 },
      { id: '3-2-2', code: '២.២', title: 'ភាគរយសិស្សត្រៀមនឹងបោះបង់ ឬបោះបង់ការសិក្សាបានត្រឡប់មករៀនវិញ ក្រោមការគាំទ្រពីសហគមន៍', unit: '%', currentN: '30', targetN1: '35', stateBudget: 100000, nonStateBudget: 0 },

      { id: '3-3', code: '៣', title: 'ការគាំទ្ររបស់សហគមន៍', unit: '', currentN: '', targetN1: '', stateBudget: 200000, nonStateBudget: 0, isCategoryHeader: true },
      { id: '3-3-1', code: '៣.១', title: 'បរិមាណចំណូលមូលនិធិបង់ចូលសាលារៀន', unit: '%', currentN: '3ដង', targetN1: '5ដង', stateBudget: 200000, nonStateBudget: 0 },
    ],
  },
  {
    id: 'std-4',
    code: 'ស្តង់ដាទី៤',
    title: 'អភិបាលកិច្ចរបស់សាលារៀន',
    subtitle: '៦ សូចនាករគន្លឹះ និង ១៧ សូចនាកររង',
    defaultBudget: 3200000,
    rows: [
      { id: '4-1', code: '១', title: 'ការគ្រប់គ្រងរដ្ឋបាលទូទៅ', unit: '', currentN: '', targetN1: '', stateBudget: 600000, nonStateBudget: 0, isCategoryHeader: true },
      { id: '4-1-1', code: '១.១', title: 'ការរៀបចំទីតាំងការតុកដាក់ឯកសារ មានសណ្ឋាប់ធ្នាប់ និងរបៀបរៀបរយ', unit: '%', currentN: 'មានទូដាក់ឯកសារ', targetN1: 'មានទូដាក់ឯកសារ+មានកៅអី', stateBudget: 200000, nonStateBudget: 0 },
      { id: '4-1-2', code: '១.២', title: 'ការប្រើប្រាស់ថ្នាលបឋមក្នុងការគ្រប់គ្រងទិន្នន័យសាលារៀន', unit: '%', currentN: 'ប្រើ app', targetN1: 'ប្រើ app', stateBudget: 400000, nonStateBudget: 0 },

      { id: '4-2', code: '២', title: 'ការរៀបចំផែនការអភិវឌ្ឍន៍សាលារៀន', unit: '', currentN: '', targetN1: '', stateBudget: 300000, nonStateBudget: 0, isCategoryHeader: true },
      { id: '4-2-1', code: '២.១', title: 'ផែនការយុទ្ធសាស្ត្រអភិវឌ្ឍន៍សាលារៀន ៥ ឆ្នាំ ផែនការថវិកាប្រចាំឆ្នាំ និងផែនការប្រតិបត្តិប្រចាំឆ្នាំ', unit: 'ចំនួន', currentN: 'មាន៣', targetN1: 'មាន៤', stateBudget: 300000, nonStateBudget: 0 },

      { id: '4-3', code: '៣', title: 'ការវាយតម្លៃបំពេញការងាររបស់បុគ្គលិក', unit: '', currentN: '', targetN1: '', stateBudget: 200000, nonStateBudget: 0, isCategoryHeader: true },
      { id: '4-3-1', code: '៣.១', title: 'ភាគរយគ្រូបង្រៀន និងបុគ្គលិកអប់រំបានចុះកិច្ចព្រមព្រៀងទទួលផលការងារប្រចាំឆ្នាំ', unit: 'លើក', currentN: '12', targetN1: '12', stateBudget: 200000, nonStateBudget: 0 },

      { id: '4-4', code: '៤', title: 'វាយតម្លៃលទ្ធផលសិក្សា', unit: '', currentN: '', targetN1: '', stateBudget: 150000, nonStateBudget: 0, isCategoryHeader: true },
      { id: '4-4-1', code: '៤.១', title: 'តេស្តស្តង់ដារដើមឆ្នាំ ប្រចាំខែ ឆមាស និងតេស្តស្តង់ដារថ្នាក់ទី៣ និងទី៦ ត្រូវបានរៀបចំឡើង', unit: 'លើក', currentN: 'ពេញ១ឆ្នាំ', targetN1: 'ពេញ១ឆ្នាំ', stateBudget: 150000, nonStateBudget: 0 },

      { id: '4-5', code: '៥', title: 'ការលើកកម្ពស់សុខភាពសិក្សា និងអាហារូបត្ថម្ភ', unit: '', currentN: '', targetN1: '', stateBudget: 850000, nonStateBudget: 0, isCategoryHeader: true },
      { id: '4-5-1', code: '៥.១', title: 'ការលើកកម្ពស់សុខភាព ថែសុខភាពបឋម', unit: 'លើក', currentN: 'មានរបាយការណ៍', targetN1: 'មានរបាយការណ៍', stateBudget: 50000, nonStateBudget: 0 },
      { id: '4-5-2', code: '៥.២', title: 'ការលើកកម្ពស់ទឹកស្អាត និងអនាម័យ', unit: 'លើក', currentN: 'មានរបាយការណ៍', targetN1: 'មានរបាយការណ៍', stateBudget: 50000, nonStateBudget: 0 },
      { id: '4-5-3', code: '៥.៣', title: 'ការលើកកម្ពស់សុវត្ថិភាពចំណីអាហារ និងអាហារប្រកបដោយសុខភាព', unit: 'លើក', currentN: 'មានរបាយការណ៍', targetN1: 'មានរបាយការណ៍', stateBudget: 50000, nonStateBudget: 0 },
      { id: '4-5-4', code: '៥.៤', title: 'ការអនុវត្តមុខវិជ្ជាអប់រំសុខភាព', unit: 'លើក', currentN: 'មានរបាយការណ៍', targetN1: 'មានរបាយការណ៍', stateBudget: 50000, nonStateBudget: 0 },
      { id: '4-5-5', code: '៥.៥', title: 'ការលើកកម្ពស់បរិស្ថានស្អាត បៃតង សុវត្ថិភាព អនាម័យ និងមេត្រីភាព', unit: 'ចំនួន', currentN: 'មានរបាយការណ៍', targetN1: 'មានរបាយការណ៍', stateBudget: 400000, nonStateBudget: 0 },
      { id: '4-5-6', code: '៥.៦', title: 'ការរក្សាសុខសុវត្ថិភាព ការការពារកុមារ ការបង្ការគ្រោះមហន្តរាយ', unit: 'ចំនួន', currentN: 'មានរបាយការណ៍', targetN1: 'មានរបាយការណ៍', stateBudget: 150000, nonStateBudget: 0 },
      { id: '4-5-7', code: '៥.៧', title: 'ការអនុវត្តសកម្មភាពអប់រំកាយ និងកីឡា', unit: 'ចំនួន', currentN: '2ក្រុម', targetN1: '2ក្រុម', stateBudget: 100000, nonStateBudget: 0 },

      { id: '4-6', code: '៦', title: 'ការអភិវឌ្ឍន៍ហេដ្ឋារចនាសម្ព័ន្ធ', unit: '', currentN: '', targetN1: '', stateBudget: 1100000, nonStateBudget: 0, isCategoryHeader: true },
      { id: '4-6-1', code: '៦.១', title: 'សាលារៀនមានបណ្តាញអគ្គិសនី បំពាក់អ៊ីនធឺណិត', unit: '%', currentN: '70', targetN1: '100', stateBudget: 200000, nonStateBudget: 0 },
      { id: '4-6-2', code: '៦.២', title: 'ការបំពាក់បន្ទប់រៀនដោយឧបករណ៍សិក្សាទំនើប (LCD, Smart TV, Smart Board...)', unit: '%', currentN: '0', targetN1: '1', stateBudget: 200000, nonStateBudget: 0 },
      { id: '4-6-3', code: '៦.៣', title: 'បណ្ណាល័យសាលារៀន', unit: 'ចំនួន', currentN: '1', targetN1: '1', stateBudget: 200000, nonStateBudget: 0 },
      { id: '4-6-4', code: '៦.៤', title: 'បន្ទប់កុំព្យូទ័រសម្រាប់សិស្សរៀន', unit: 'ចំនួន', currentN: '0', targetN1: '0', stateBudget: 400000, nonStateBudget: 0 },
      { id: '4-6-5', code: '៦.៥', title: 'សាលារៀនមានទីលានកីឡារួមមាន តារាងបាល់ទាត់ បាល់ទាត់ បាល់បោះ វាយសី...', unit: '%', currentN: '2', targetN1: '3', stateBudget: 100000, nonStateBudget: 0 },
    ],
  },
  {
    id: 'std-5',
    code: 'ស្តង់ដាទី៥',
    title: 'គណនេយ្យភាពរបស់សាលារៀន',
    subtitle: '៣ សូចនាករគន្លឹះ និង ៦ សូចនាកររង',
    defaultBudget: 1000000,
    rows: [
      { id: '5-1', code: '១', title: 'ថវិកាសាធារណៈ', unit: '', currentN: '', targetN1: '', stateBudget: 400000, nonStateBudget: 0, isCategoryHeader: true },
      { id: '5-1-1', code: '១.១', title: 'ការជួបប្រជុំមាតាបិតាសិស្ស', unit: 'លើក', currentN: '2', targetN1: '4', stateBudget: 400000, nonStateBudget: 0 },

      { id: '5-2', code: '២', title: 'ការផ្សព្វផ្សាយព័ត៌មានជាសាធារណៈ', unit: '', currentN: '', targetN1: '', stateBudget: 200000, nonStateBudget: 0, isCategoryHeader: true },
      { id: '5-2-1', code: '២.១', title: 'លទ្ធផលសិក្សា និងព័ត៌មាននានាត្រូវបានអនុម័តដោយ គ.គ.ស. និងផ្សព្វផ្សាយសាធារណៈ', unit: 'លើក', currentN: '2', targetN1: '4', stateBudget: 200000, nonStateBudget: 0 },

      { id: '5-3', code: '៣', title: 'ការទទួលបានការគាំទ្រពីថ្នាក់ជាតិ', unit: '', currentN: '', targetN1: '', stateBudget: 400000, nonStateBudget: 0, isCategoryHeader: true },
      { id: '5-3-1', code: '៣.១', title: 'នាយករងសាលា និងនាយកបានទទួលបានការប្រឹក្សាអនុវត្តដោយសាលារៀនគំរូ ពីនាយកសាលាដទៃ ឬមកពីថ្នាក់លើ', unit: 'លើក', currentN: '4', targetN1: '6', stateBudget: 100000, nonStateBudget: 0 },
      { id: '5-3-2', code: '៣.២', title: 'លទ្ធផលនៃការអនុវត្តស្តង់ដារសាលារៀនគំរូតាមឆ្នាំ', unit: 'លើក', currentN: '1', targetN1: '1', stateBudget: 100000, nonStateBudget: 0 },
      { id: '5-3-3', code: '៣.៣', title: 'ភាគរយគ្រូបង្រៀនបានទទួលបានប្រឹក្សាការអនុវត្តបច្ចេកទេសជំនាញថ្នាក់ដំបូង និង/ឬវិធីសាស្ត្របង្រៀនភាសាខ្មែរ និងគណិតវិទ្យា', unit: '%', currentN: '50', targetN1: '60', stateBudget: 100000, nonStateBudget: 0 },
      { id: '5-3-4', code: '៣.៤', title: 'ភាគរយគ្រូបង្រៀនបំពេញសុសកិច្ចសិក្សាទៅសាលាដទៃ ក្នុងមួយឆ្នាំ', unit: '%', currentN: '30', targetN1: '35', stateBudget: 100000, nonStateBudget: 0 },
    ],
  },
];
