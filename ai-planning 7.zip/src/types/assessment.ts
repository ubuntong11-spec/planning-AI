export type EvidenceType = 
  | 'report'           // របាយការណ៍
  | 'photo'            // រូបភាពសកម្មភាព
  | 'official_letter'  // លិខិតបទដ្ឋាន / លិខិតបង្គាប់ការ
  | 'attendance'       // បញ្ជីវត្តមាន
  | 'agreement'        // កិច្ចព្រមព្រៀង
  | 'minutes'          // កំណត់ហេតុប្រជុំ
  | 'tracking_book'    // សៀវភៅតាមដាន
  | 'curriculum_plan'  // កិច្ចតែងការ / ផែនការ
  | 'other';           // ផ្សេងៗ

export interface EvidenceItem {
  id: string;
  type: EvidenceType;
  title: string;          // ឈ្មោះឯកសារ
  fileName: string;       // ឈ្មោះ file
  fileData?: string;      // Base64 data URL for preview/download
  fileType?: string;      // MIME type (image/jpeg, application/pdf, etc.)
  fileSize?: number;      // Size in bytes
  uploadedAt: string;     // Date string
}

export interface AssessmentIndicator {
  id: string;
  code: string;                  // e.g. '១.១'
  title: string;                 // សូចនាករស្តង់ដារ
  meansOfVerification: string[]; // មធ្យោបាយផ្ទៀងផ្ទាត់
  evidences: EvidenceItem[];     // ភស្តុតាង
  score?: number;                // ពិន្ទុ 1 - 5
  comment?: string;              // ចំណាំបន្ថែម
}

export interface AssessmentSubCategory {
  id: string;
  code: string;                  // e.g. '១', '២'
  title: string;                 // e.g. 'ការប្រមូលកុមារចូលរៀន'
  indicators: AssessmentIndicator[];
}

export interface AssessmentStandard {
  id: string;
  standardNumber: number;        // 1 to 5
  code: string;                  // e.g. 'ស្តង់ដារទី១'
  title: string;                 // e.g. 'លទ្ធផលសិក្សារបស់សិស្ស'
  categories: AssessmentSubCategory[];
}

export interface AssessmentGeneralInfo {
  province: string;              // រាជធានី ខេត្ត
  district: string;              // ក្រុង ស្រុក ខណ្ឌ
  commune: string;               // ឃុំ សង្កាត់
  schoolName: string;            // សាលាបឋមសិក្សា
  schoolCode: string;            // លេខកូដសាលារៀន
  principalName: string;         // ឈ្មោះនាយក
  principalPhone: string;        // លេខទូរសព្ទនាយក
  assessmentDate: string;        // ថ្ងៃខែឆ្នាំពិនិត្យ និងវាយតម្លៃ
  evaluatorName: string;         // អ្នកត្រួតពិនិត្យ និងវាយតម្លៃ
  evaluatorPhone: string;        // លេខទូរសព្ទអ្នកត្រួតពិនិត្យ
}

export interface AssessmentResults {
  strengths: string;             // ចំណុចខ្លាំង
  weaknesses: string;            // ចំណុចខ្វះខាត
  recommendations: string;       // អនុសាសន៍
}

export interface SchoolAssessmentData {
  generalInfo: AssessmentGeneralInfo;
  standards: AssessmentStandard[];
  results: AssessmentResults;
  lastUpdated?: string;
}
