import { StandardCategory } from '../data/standardFourData';
import { ChapterFiveStandardGroup } from '../data/standardFiveActionsData';

export interface PlanItem {
  id: string;
  title: string;
  content: string;
}

export interface PlanSubsection {
  id: string;
  code: string;
  title: string;
  content: string;
  items?: PlanItem[];
}

export interface PlanSection {
  id: string;
  code: string;
  title: string;
  content: string;
  subsections?: PlanSubsection[];
}

export type ActivityStatus = 'completed' | 'in_progress' | 'pending';

export interface ActionMatrixItem {
  id: string;
  activity: string;
  indicator: string;
  timeline: string;
  budget: string;
  budgetSource: string;
  responsiblePerson: string;
  status?: ActivityStatus;
  progressPercentage?: number;
  notes?: string;
  completedDate?: string;
}

export interface SchoolContextProfile {
  summary: string;
  strengths: string;
  challenges: string;
  uniqueEnvironment?: string;
  opportunities?: string;
  fileName?: string;
  lastUpdated?: string;
}

export interface ExecutiveSummaryData {
  documentTitle: string;
  executiveOverview: string;
  keyStrengths: string[];
  criticalChallenges: string[];
  strategicPriorities: string[];
  expectedOutcomes: string[];
  budgetSummary: {
    totalBudgetRiel: string;
    stateBudgetRiel: string;
    communityAndPartnerRiel: string;
    resourceNote: string;
  };
  closingStatement: string;
  focusStyle?: 'standard' | 'budget_commune' | 'concise';
  generatedAt?: string;
}

export interface PlanData {
  id: string;
  title: string;
  subtitle: string;
  schoolName: string;
  academicYear: string;
  location: string;
  schoolType: string;
  preparedBy: string;
  approvedBy: string;
  createdDate: string;
  sections: PlanSection[];
  actionMatrix: ActionMatrixItem[];
  standardTargets?: StandardCategory[];
  chapterFiveActions?: ChapterFiveStandardGroup[];
  schoolProfile?: SchoolContextProfile;
  schoolContextProfile?: SchoolContextProfile;
  executiveSummary?: ExecutiveSummaryData;
  userId?: string;
  updatedAt?: string;
}

export interface PlanGeneratorParams {
  schoolName: string;
  academicYear: string;
  location: string;
  schoolType: string;
  priorities: string;
  challenges: string;
  targetGoals: string;
  schoolContextProfile?: SchoolContextProfile;
}
