export interface BspStandardItem {
  id: string;
  code: string;
  title: string;
  expectedOutcome: string;
  keyActivities: string;
  // 3-year budgets (in Riels)
  year1Budget: number; // Year N (feeder into AOP)
  year2Budget: number; // Year N+1
  year3Budget: number; // Year N+2
  // Funding source distribution (%)
  stateShare: number; // e.g. 50%
  communeShare: number; // e.g. 30% (CIP / មូលនិធិឃុំ-សង្កាត់)
  communityShare: number; // e.g. 20% (ការចូលរួមរបស់សហគមន៍/មាតាបិតា)
  partnerShare: number; // e.g. 0%
  communeProjectName?: string; // e.g. គម្រោងសាងសង់របង ឬ បន្ទប់ទឹកស្នើក្នុង CIP
  communityProjectName?: string; // e.g. កម្មវិធីអាហារូបករណ៍ ឬ សៀវភៅបណ្ណាល័យ
  responsiblePerson: string;
  status: 'planned' | 'approved' | 'commune_submitted' | 'funded';
}

export interface BspStandardGroup {
  id: string;
  standardNumber: number;
  standardCode: string; // e.g. 'ស្តង់ដាទី១'
  standardTitle: string; // e.g. 'លទ្ធផលសិក្សារបស់សិស្ស'
  priorityObjective: string;
  items: BspStandardItem[];
}

export interface CommuneInvestmentAsk {
  id: string;
  title: string;
  standardCode: string;
  targetBeneficiaries: string; // e.g. 'សិស្សានុសិស្ស ៤៥០ នាក់'
  requestedYear: string; // e.g. '២០២៥ (ឆ្នាំទី១)'
  estimatedCost: number; // in Riels
  communeContribution: number; // in Riels
  schoolCommunityContribution: number; // in Riels
  urgency: 'high' | 'medium' | 'normal';
  status: 'draft' | 'proposed_to_commune' | 'approved_in_cip' | 'in_progress';
  communeFeedback?: string;
}

export interface StandardBudgetSummaryItem {
  id: string;
  standardNumber: number;
  standardCode: string;
  standardTitle: string;
  budgetNminus1: number; // ឆ្នាំមុន (N-1)
  budgetN: number;        // ឆ្នាំបច្ចុប្បន្ន (N)
  budgetNplus1: number;   // ឆ្នាំគ្រោង (N+1)
  budgetNplus2: number;   // ឆ្នាំគ្រោង (N+2)
  budgetNplus3: number;   // ឆ្នាំគ្រោង (N+3)
  stateSharePercent: number;
  communeSharePercent: number;
  communitySharePercent: number;
}

export interface BudgetRequirementPlan {
  studentCount: number;
  perStudentRateRiel: number; // e.g. 16,400 Riels per student
  standardsSummary: StandardBudgetSummaryItem[];
  communeCipAskTotal: number;
  communityContributionTotal: number;
}

export interface ThreeYearBspPlan {
  id: string;
  schoolName: string;
  startYear: number; // e.g. 2025
  academicYearsLabel: string; // e.g. '២០២៥ - ២០២៧'
  year1Label: string; // 'ឆ្នាំទី១ (២០២៥)'
  year2Label: string; // 'ឆ្នាំទី២ (២០២៦)'
  year3Label: string; // 'ឆ្នាំទី៣ (២០២៧)'
  visionStatement: string;
  goalsSummary: string;
  standardGroups: BspStandardGroup[];
  communeAsks: CommuneInvestmentAsk[];
  budgetRequirement?: BudgetRequirementPlan;
  updatedAt: string;
}
